# Routing Information

## Auth Routes

The following routes are defined for authentication in the `AuthJwt` component:

- **Login Page**

  - Path: `/auth/jwt/login`
  - Component: `JwtLoginPage`
  - Guard: `GuestGuard`

- **Register Page**

  - Path: `/auth/jwt/register`
  - Component: `JwtRegisterPage`
  - Guard: `GuestGuard`

- **OTP Verification Page**

  - Path: `/auth/jwt/verify-otp`
  - Component: `JwtOtpPage`
  - Guard: `GuestGuard`

- **Partner Registration Page**
  - Path: `/auth/jwt/partner-registration`
  - Component: `JwtPartnerRegistrationPage`
  - Guard: `GuestGuard`

## Example Usage

Here is an example of how the routes are defined in the `AuthJwt` component:

```jsx
import { lazy, Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { GuestGuard } from 'src/middleware/auth/guard';
import { SplashScreen } from '@components/mui-components/loading-screen';

const JwtLoginPage = lazy(() => import('src/modules/auth/extras/LoginPage'));
const JwtRegisterPage = lazy(() => import('src/modules/auth/extras/RegisterPage'));
const JwtOtpPage = lazy(() => import('src/modules/auth/extras/otp'));
const JwtPartnerRegistrationPage = lazy(
  () => import('src/modules/auth/partner-registration/PartnerRegistration')
);

const AuthJwt = {
  path: 'jwt',
  element: (
    <Suspense fallback={<SplashScreen />}>
      <Outlet />
    </Suspense>
  ),
  children: [
    {
      path: 'login',
      element: (
        <GuestGuard>
          <JwtLoginPage />
        </GuestGuard>
      ),
    },
    {
      path: 'register',
      element: (
        <GuestGuard>
          <JwtRegisterPage />
        </GuestGuard>
      ),
    },
    {
      path: 'verify-otp',
      element: (
        <GuestGuard>
          <JwtOtpPage />
        </GuestGuard>
      ),
    },
    {
      path: 'partner-registration',
      element: (
        <GuestGuard>
          <JwtPartnerRegistrationPage />
        </GuestGuard>
      ),
    },
  ],
};

export const AuthRoutes = [
  {
    path: 'auth',
    children: [AuthJwt],
  },
];
```

export const BaseRequest = {
  url: '',
  queryParams: {},
  bodyParams: {},
};

import { DefaultEntityRoles } from 'src/global/ValueTypes/DefaultEntityRoles';

export const EntityUser = {
  firstName: '',
  middleName: '',
  lastName: '',
  joiningDate: '',
  lasModifiedOn: '',
  entityRole: '',
  entityCode: '',
  email: '',
  uid: '',
  isMobileVerified: false,
  isEmailVerified: false,
  isAadhaarVerified: false,
  isPanVerified: false,
};

export const ApplicantUser = {
  ...EntityUser,
  entityRole: DefaultEntityRoles.APPLICANT,
};

export const PartnerUser = {
  ...EntityUser,
  businessName: '',
  businessType: '',
  businessLocation: '',
  businessContact: '',
  businessEmail: '',
  entityRole: DefaultEntityRoles.PARTNER,
};

export const ClientUser = {
  ...EntityUser,
  businessName: '',
  businessType: '',
  businessLocation: '',
  businessContact: '',
  businessEmail: '',
  entityRole: DefaultEntityRoles.CLIENT,
};

export const SalesUser = {
  ...EntityUser,
  businessEmail: '',
  entityRole: DefaultEntityRoles.SALES,
};

export const StaffUser = {
  ...EntityUser,
  businessEmail: '',
  entityRole: DefaultEntityRoles.STAFF,
};

export const SupportUser = {
  ...EntityUser,
  businessEmail: '',
  entityRole: DefaultEntityRoles.SUPPORT,
};

export const AdminUser = {
  ...EntityUser,
  businessName: '',
  businessType: '',
  businessLocation: '',
  businessContact: '',
  businessEmail: '',
  entityRole: DefaultEntityRoles.ADMIN,
};

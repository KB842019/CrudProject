export const LoanDocumentModel = {
  documentId: '',
  documentType: '',
  documentNumber: '',
  documentName: '',
  documentFile: '',
  documentFileUrl: '',
  documentStatus: '',
  documentRemarks: '',
  documentCategory: '',
};

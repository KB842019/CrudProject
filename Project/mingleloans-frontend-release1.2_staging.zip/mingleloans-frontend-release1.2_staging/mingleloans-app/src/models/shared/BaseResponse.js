export const BaseResponse = {
  httpStatusCode: 0,
  responseCode: '',
  message: {},
  data: {},
};

import { BaseRequest } from 'src/models/shared/BaseRequest';
import { AUTH_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

export const EntityAccountAppSignIn = {
  EntityAccountAppSignInRequest: {
    ...BaseRequest,
    url: AUTH_ENDPOINTS.EntityAccountAppSignInApi,
    queryParams: {},
    bodyParams: {},
  },
};

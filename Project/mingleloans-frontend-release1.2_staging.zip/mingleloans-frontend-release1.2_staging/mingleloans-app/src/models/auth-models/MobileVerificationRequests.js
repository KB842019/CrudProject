import { BaseRequest } from 'src/models/shared/BaseRequest';
import { AUTH_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

export const MobileVerification = {
  MobileVerificationRequest: {
    ...BaseRequest,
    url: AUTH_ENDPOINTS.MobileVerificationApi,
    queryParams: {},
    bodyParams: { mobileno: '' },
  },
  OtpVerificationRequest: {
    ...BaseRequest,
    url: AUTH_ENDPOINTS.OtpVerificationApi,
    queryParams: {},
    bodyParams: { mobileno: '', otp: '' },
  },
};

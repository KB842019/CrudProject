export const Permission = {
  allowRead: false,
  allowAdd: false,
  allowUpdate: false,
  allowDelete: false,
  allowPatch: false,
  allowImport: false,
  allowExport: false,
};

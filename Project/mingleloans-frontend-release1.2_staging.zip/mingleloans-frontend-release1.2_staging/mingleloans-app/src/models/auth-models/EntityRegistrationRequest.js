import { BaseRequest } from 'src/models/shared/BaseRequest';
import { AUTH_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

export const EntityRegistration = {
  ApplicantRegistrationRequest: {
    ...BaseRequest,
    url: AUTH_ENDPOINTS.EntityAccountRegistrationApi,
    queryParams: {},
    bodyParams: {
      identityUid: '',
      identityProvider: 0,
      entitytype: '',
      firstName: '',
      lastName: '',
      email: '',
      mobileno: '',
    },
  },
};

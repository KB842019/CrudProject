/* eslint-disable import/no-unresolved */
import { BaseRequest } from 'src/models/shared/BaseRequest';
import { AUTH_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

export const EntityAccountVerification = {
  EntityAccountVerificationRequest: {
    ...BaseRequest,
    url: AUTH_ENDPOINTS.EntityAccountVerificationApi, // 'entityaccount/{{entitytype}}/verify',
    queryParams: {},
    bodyParams: { email: '', mobileno: '' },
  },
};

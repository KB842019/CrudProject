import { BaseRequest } from 'src/models/shared/BaseRequest';
import { LOAN_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';
import { LoanDocumentModel } from 'src/models/shared/LoanDocumentModel';

const businessLoanModel = {
  personalInfo: {
    firstName: '',
    middleName: '',
    lastName: '',
    dob: '',
    email: '',
    contactNumber: '',
    pan: '',
    aadhaarNumber: '',
  },
  addresses: [
    {
      addressLine: '',
      city: '',
      state: '',
      pinCode: '',
      isPermanentAddress: false,
      isCommunicationAddress: false,
    },
    {
      addressLine: '',
      city: '',
      state: '',
      pinCode: '',
      isPermanentAddress: false,
      isCommunicationAddress: false,
    },
  ],
  businessDetails: {
    businessGst: '',
    industryType: '',
    annualTurnOver: '',
    netProfit: '',
    totalAssets: '',
    businessType: '',
    businessName: '',
    businessPan: '',
    businessWebsite: '',
    businessEmail: '',
    businessContactNumber: '',

    businessAddress: '',
    businessCity: '',
    businessState: '',
    businessPinCode: '',
    businessConstitution: '',
    businessActivity: '',
    businessAge: '',
  },
  businessAddress: [
    {
      addressLine: '',
      city: '',
      state: '',
      pinCode: '',
      isPermanentAddress: false,
      isCommunicationAddress: false,
    },
    {
      addressLine: '',
      city: '',
      state: '',
      pinCode: '',
      isPermanentAddress: false,
      isCommunicationAddress: false,
    },
  ],

  businessLoanDetail: {
    loanPurpose: '',
    loanAmount: '',
    tenure: '',
  },
  LoanDocuments: [
    {
      ...LoanDocumentModel,
    },
  ],
};

export const BusinessLoanRequest = {
  NewBusinessLoanRequest: {
    ...BaseRequest,
    url: LOAN_ENDPOINTS.businessLoanApi,
    queryParams: {},
    bodyParams: { ...businessLoanModel },
  },
  BusinessLoanPreviewRequest: {
    ...BaseRequest,
    url: LOAN_ENDPOINTS.businessLoanApi,
    queryParams: {},
    bodyParams: { ...businessLoanModel },
  },
};

export default class BusinessLoan {
  constructor(
    gstIn,
    businessPan,
    businessName,
    businessType,
    industryType,
    annualTurnOver,
    netProfit,
    totalAssets
  ) {
    this.gstin = gstIn;
    this.businessPan = businessPan;
    this.businessName = businessName;
    this.businessType = businessType;
    this.industryType = industryType;
    this.annualTurnOver = annualTurnOver;
    this.netProfit = netProfit;
    this.totalAssets = totalAssets;
  }
}

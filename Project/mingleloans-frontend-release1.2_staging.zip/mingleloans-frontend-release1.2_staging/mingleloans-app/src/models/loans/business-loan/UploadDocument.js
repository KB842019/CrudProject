
export class BusinessUploadDocumentData{
  constructor(panCard, aadhaarCard, businessRegistrationCertificate,financialStatements,lastYearBankStatement){
      this.panCard = panCard;
      this.aadhaarCard = aadhaarCard;
      this.businessRegistrationCertificate = businessRegistrationCertificate;
      this.financialStatements = financialStatements;
      this.lastYearBankStatement = lastYearBankStatement;
  }
}
export default class BusinessLoanDetail {
  constructor(loanPurpose, loanAmount, tenure) {
    this.loanPurpose = loanPurpose;
    this.loanAmount = loanAmount;
    this.tenure = tenure;
  }
}

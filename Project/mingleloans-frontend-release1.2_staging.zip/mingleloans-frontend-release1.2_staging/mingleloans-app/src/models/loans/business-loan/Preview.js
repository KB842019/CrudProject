export class BusinessPreview {
  constructor(businessdata,loandata,personaldata,uploaddocumentdata){
    this.businessdata = businessdata;
    this.loandata = loandata;
    this.personaldata = personaldata;
    this.uploaddocumentdata = uploaddocumentdata;
  }
}
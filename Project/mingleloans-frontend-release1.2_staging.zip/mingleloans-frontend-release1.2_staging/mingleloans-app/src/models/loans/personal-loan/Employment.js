  export class PersonalEmployementData{
    constructor(companyName, takeHomeSalary, netSalary, currentObligation, degree,designation,withdrawalType,currentExperience,totalExperience,pfStatus){
        this.companyName = companyName;
        this.takeHomeSalary = takeHomeSalary;
        this.netSalary = netSalary;
        this.currentObligation = currentObligation;
        this.degree = degree;
        this.designation = designation;
        this.withdrawalType = withdrawalType;
        this.currentExperience = currentExperience;
        this.totalExperience = totalExperience;
        this.pfStatus = pfStatus;
    }
  }
   export class PersonalUploadDocumentData{
    constructor(panCard, aadhaarCard, salarySlip,bankStatement){
        this.panCard = panCard;
        this.aadhaarCard = aadhaarCard;
        this.salarySlip = salarySlip;
        this.bankStatement = bankStatement;
    }
  }
export class PersonalPreview {
    constructor(personalInfo,employmentInfo,loanInfo,documentUpload){
      this.personalInfo = personalInfo;
      this.employmentInfo = employmentInfo;
      this.loanInfo = loanInfo;
      this.documentUpload = documentUpload;
    }
  }
  export class PersonalLoanData{
    constructor(loanPurpose, loanAmount, tenure){
        this.loanPurpose = loanPurpose;
        this.loanAmount = loanAmount;
        this.tenure = tenure;
    }
  }
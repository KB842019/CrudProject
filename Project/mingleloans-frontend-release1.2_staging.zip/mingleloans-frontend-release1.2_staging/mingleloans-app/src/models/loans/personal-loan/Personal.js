  export class PersonalDetailData{
    constructor(firstName, middleName, lastName, email,contactNumber, pan,aadhaarNumber,permanentAddress,paCity,paState,paPinCode,communicationAddress,caCity,caState,caPinCode){
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.email = email;
        this.contactNumber = contactNumber;
        this.pan = pan;
        this.aadhaarNumber = aadhaarNumber;
        this.permanentAddress = permanentAddress;
        this.paCity = paCity;
        this.paState = paState;
        this.paPinCode = paPinCode;
        this.communicationAddress = communicationAddress;
        this.caCity = caCity;
        this.caState = caState;
        this.caPinCode = caPinCode;
    }
  }
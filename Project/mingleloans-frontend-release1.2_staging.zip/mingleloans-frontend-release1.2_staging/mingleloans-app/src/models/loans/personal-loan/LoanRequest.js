export const PersonalLoan = {
  PersonalLoanGetRequest: {
    url: '/api/loans/personal-loan',
  },
  PersonalLoanPutRequest: {
    url: '/api/loans/personal-loan/update',
    bodyParams: {
      loanAmount: null,
      tenure: null,
      interestRate: null,
      emi: null,
      applicantId: null,
      status: null,
    },
  },
};

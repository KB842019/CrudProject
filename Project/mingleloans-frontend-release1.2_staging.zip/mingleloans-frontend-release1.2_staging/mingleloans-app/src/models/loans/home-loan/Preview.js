export class HomePreview {
    constructor(personalInfo,loanInfo,documentUpload,employmentInfo,propertyInfo){
      this.personalInfo = personalInfo;
      this.loanInfo = loanInfo;
      this.documentUpload = documentUpload;
      this.employmentInfo = employmentInfo;
      this.propertyInfo = propertyInfo;
    }
  }
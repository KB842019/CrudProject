export class HomeLoanInfo{
  constructor(loanAmount,loanPurpose,tenure,roi,emiCalculated){
      this.loanAmount=loanAmount;
      this.loanPurpose=loanPurpose;
      this.tenure=tenure;
      this.roi=roi;
      this.emiCalculated=emiCalculated;

  }
}

export class HomeEmployment{
    constructor(occupation,companyName,companyAddress,designation,officeEmail,degree,currentExperience,totalExperience,withdrawalType,takeHomeSalary,currentObligation,netSalary,pfStatus,gst){
        this.occupation=occupation;
        this.companyName=companyName;
        this.companyAddress=companyAddress;
        this.designation=designation;
        this.officeEmail=officeEmail;
        this.degree=degree;
        this.currentExperience=currentExperience;
        this.totalExperience=totalExperience;
        this.withdrawalType=withdrawalType;
        this.takeHomeSalary=takeHomeSalary;
        this.currentObligation=currentObligation;
        this.netSalary=netSalary;
        this.pfStatus=pfStatus;
        this.gst=gst;

    }
}
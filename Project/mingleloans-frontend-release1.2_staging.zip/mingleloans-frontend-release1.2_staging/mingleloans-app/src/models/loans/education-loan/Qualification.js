export class EducationQualification{
    constructor(highestQualification,lastInstitutionName,institutionAppliedName,institutionAppliedAddress,courseAppliedFor,courseDuration,courseStartDate,courseEndDate){
        this.highestQualification=highestQualification;
        this.lastInstitutionName=lastInstitutionName;
        this.institutionAppliedName=institutionAppliedName;
        this.institutionAppliedAddress=institutionAppliedAddress;
        this.courseAppliedFor=courseAppliedFor;
        this.courseDuration=courseDuration;
        this.courseStartDate=courseStartDate;
        this.courseEndDate=courseEndDate;
        
    }
}
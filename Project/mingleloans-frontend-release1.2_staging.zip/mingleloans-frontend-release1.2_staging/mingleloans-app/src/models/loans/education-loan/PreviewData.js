export class EducationPreview {
    constructor(personalInfo,loanInfo,documentUpload,employmentInfo,qualifications){
      this.personalInfo = personalInfo;
      this.loanInfo = loanInfo;
      this.documentUpload = documentUpload;
      this.employmentInfo = employmentInfo;
      this.qualifications = qualifications;
    }
  }
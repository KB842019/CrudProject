export class EducationLoanInfo{
    constructor(loanAmount,downPayment,tenure,roi,emiCalculated){
        this.loanAmount=loanAmount;
        this.downPayment=downPayment;
        this.tenure=tenure;
        this.roi=roi;
        this.emiCalculated=emiCalculated;

    }
}

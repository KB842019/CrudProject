export class EducationUploadDocument{
    constructor(panCard,aadhaarCard,businessRegistrationCertificate,financialStatements,lastYearBankStatement,latestSalarySlip,educationDocument){
        this.panCard=panCard;
        this.aadhaarCard=aadhaarCard;
        this.businessRegistrationCertificate=businessRegistrationCertificate;
        this.financialStatements=financialStatements;
        this.lastYearBankStatement=lastYearBankStatement;
        this.latestSalarySlip=latestSalarySlip;
        this.educationDocument=educationDocument;


    }
}
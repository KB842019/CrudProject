export class MortgagePropertyDetails{
    constructor(propertyType,propertyOwnership,propertySize,propertyValue,propertyAddress,sellerName,sellerContact,sellerEmail){
        this.propertyType=propertyType;
        this.propertyOwnership=propertyOwnership;
        this.propertySize=propertySize;
        this.propertyValue=propertyValue;
        this.propertyAddress=propertyAddress;
        this.sellerName=sellerName;
        this.sellerContact=sellerContact;
        this.sellerEmail=sellerEmail;

    }
}
export class MortgageUploadDocument{
  constructor(panCard,aadhaarCard,businessRegistrationCertificate,financialStatements,lastYearBankStatement,latestSalarySlip,propertyDocument){
      this.panCard=panCard;
      this.aadhaarCard=aadhaarCard;
      this.businessRegistrationCertificate=businessRegistrationCertificate;
      this.financialStatements=financialStatements;
      this.lastYearBankStatement=lastYearBankStatement;
      this.latestSalarySlip=latestSalarySlip;
      this.propertyDocument=propertyDocument;


  }
}
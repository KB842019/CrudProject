export class MortgageLoanInfo{
    constructor(loanType,loanPurpose,loanAmount,tenure,roi,emiCalculated){
        this.loanType = loanType;
        this.loanPurpose = loanPurpose;
        this.loanAmount = loanAmount;
        this.tenure = tenure;
        this.roi = roi;
        this.emiCalculated = emiCalculated;
        

    }
}
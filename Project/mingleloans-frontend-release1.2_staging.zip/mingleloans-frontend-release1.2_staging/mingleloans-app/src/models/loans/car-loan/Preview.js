export class CarPreview {
    constructor(personalInfo,loanInfo,documentUpload,employmentInfo,carInfo){
      this.personalInfo = personalInfo;
      this.loanInfo = loanInfo;
      this.documentUpload = documentUpload;
      this.employmentInfo = employmentInfo;
      this.carInfo = carInfo;
    }
  }
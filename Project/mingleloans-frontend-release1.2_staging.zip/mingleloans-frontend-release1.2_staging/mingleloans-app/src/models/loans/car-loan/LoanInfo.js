  export class CarLoanData{
    constructor(downPayment, loanAmount, tenure){
        this.downPayment = downPayment;
        this.loanAmount = loanAmount;
        this.tenure = tenure;
    }
  }
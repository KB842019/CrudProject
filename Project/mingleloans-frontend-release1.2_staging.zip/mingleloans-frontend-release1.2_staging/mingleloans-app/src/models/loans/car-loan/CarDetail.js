 
  export class CarDetailData{
    constructor(carCompany, carModel, exShowroomPrice, onRoadPrice){
        this.carCompany = carCompany;
        this.carModel = carModel;
        this.exShowroomPrice = exShowroomPrice;
        this.onRoadPrice = onRoadPrice;
    }
  }
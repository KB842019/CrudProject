import { BaseRequest } from 'src/models/shared/BaseRequest';
import { SHARED_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

export const EntityProfile = {
  EntityProfileGetRequest: {
    ...BaseRequest,
    url: SHARED_ENDPOINTS.EntityProfileApi,
    queryParams: {},
    bodyParams: {},
  },

  EntityProfilePutRequest: {
    ...BaseRequest,
    url: SHARED_ENDPOINTS.EntityProfileApi,
    queryParams: {},
    bodyParams: {},
  },
};

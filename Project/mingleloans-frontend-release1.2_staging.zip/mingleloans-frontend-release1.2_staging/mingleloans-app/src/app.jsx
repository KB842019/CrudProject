import 'src/global.css';

// ----------------------------------------------------------------------
// import { useContext } from 'react';

import ProgressBar from '@components/mui-components/progress-bar';
import { MotionLazy } from '@components/mui-components/animate/motion-lazy';
import { SettingsDrawer, SettingsProvider } from '@components/mui-components/settings';

import Router from 'src/routes/Router';

import { useScrollToTop } from 'src/utils/hooks/use-scroll-to-top';

import ThemeProvider from 'src/theme';
import { AuthProvider } from 'src/middleware/auth/context';
// import { AuthProvider } from 'react-auth-kit';
// import BrowserInfo from './components/BrowserInfo';

// ----------------------------------------------------------------------

export default function App() {
  useScrollToTop();

  return (
    <AuthProvider>
      <SettingsProvider
        defaultSettings={{
          themeMode: 'light', // 'light' | 'dark'
          themeDirection: 'ltr', //  'rtl' | 'ltr'
          themeContrast: 'default', // 'default' | 'bold'
          themeLayout: 'vertical', // 'vertical' | 'horizontal' | 'mini'
          themeColorPresets: 'cyan', // 'default' | 'cyan' | 'purple' | 'blue' | 'orange' | 'red'
          themeStretch: false,
        }}
      >
        <ThemeProvider>
          <MotionLazy>
            <SettingsDrawer />
            <ProgressBar />
            <Router />
            {/* <BrowserInfo /> */}
          </MotionLazy>
        </ThemeProvider>
      </SettingsProvider>
    </AuthProvider>
  );
}

// Hide Console
// console.log = () => {};

/* eslint-disable import/no-unresolved */
import React from 'react';
import TeamIllustration from '@images/shared/Team.png';

import { useTheme } from '@mui/material/styles';
import { Box, Grid, Typography } from '@mui/material';

import { howWeBenefitYou } from 'src/assets/data/SiteHomePageFeatures';

const OurRole = () => {
  const theme = useTheme();

  return (
    <>
      <Typography textAlign="center">
        <Typography
          component="p"
          sx={{
            display: 'inline-block',
            marginX: 'auto',
            backgroundColor: '#333333',
            color: '#FFFFFF',
            fontSize: '2rem',
            fontWeight: '800',
            padding: '1rem 2rem',
            borderRadius: '0 1.8rem 0 1.8rem',
          }}
        >
          Our Role as an Intermediary
        </Typography>
      </Typography>

      <Box
        sx={{
          maxWidth: '1240px',
          marginX: 'auto',
          paddingX: '1rem',
          paddingY: '2rem',
          gap: 8,
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'column', // Default to column for mobile view
          [theme.breakpoints.up('md')]: {
            flexDirection: 'row', // Change to row for medium and larger screens
          },
        }}
      >
        <Grid item sm={6} data-aos="fade-right" data-aos-duration="1200">
          <Box component="img" width="100%" src={TeamIllustration} />
        </Grid>

        <Grid item sm={6} data-aos="fade-left" data-aos-duration="1200">
          <Typography
            sx={{
              fontSize: '1.2rem',
              fontWeight: 'semiBold',
              textAlign: { xs: 'justify', md: 'left' },
            }}
          >
            As an intermediary, MingleLoans operates at the intersection of customer needs and
            financial institution offerings. Our role is to understand your financial profile,
            assess your requirements, and then match you with the most suitable loan products from a
            range of banks and NBFCs. We are not limited to the products of a single financial
            institution, which gives us the flexibility to shop around and find the best deals for
            you.
          </Typography>
        </Grid>
      </Box>

      <Box>
        <Typography textAlign="center">
          <Typography
            component="p"
            sx={{
              display: 'inline-block',
              marginX: 'auto',
              color: '#000000',
              fontSize: '2rem',
              fontWeight: '700',
              textDecoration: 'underline',
            }}
          >
            How our intermediary services benefit you
          </Typography>
        </Typography>

        <Box
          container
          sx={{
            maxWidth: '1048px',
            marginX: 'auto',
            display: 'flex',
            flexDirection: { xs: 'column', sm: 'row' },
            flexWrap: 'wrap',
            paddingX: '1.4rem',
            paddingY: '1.4rem',
            justifyContent: 'space-between',
            marginTop: '2rem',
            gap: '3rem',
          }}
        >
          {howWeBenefitYou?.map((element, idx) => (
            <Grid
              key={idx}
              sm={12}
              md={4}
              sx={{
                width: { xs: 'column', sm: 'calc(50% - 2rem)' },
                backgroundColor: '#F6F5F5',
                padding: '2rem',
                borderRadius: '0 2.2rem 0 2.2rem',
                boxShadow: 3,
              }}
              data-aos={element?.animation}
              data-aos-duration={element?.duration}
            >
              <Typography
                component="p"
                textAlign="left"
                sx={{
                  marginTop: '-3.2rem',
                  textAlign: 'center',
                }}
              >
                <Typography
                  variant="h5"
                  sx={{
                    display: 'inline-block',
                    backgroundColor: '#9F0000',
                    color: '#ffffff',
                    fontWeight: '700',
                    padding: '0.8rem 1.5rem',
                    borderRadius: '0 1.6rem 0 1.6rem',
                    border: '2px solid #ffffff',
                  }}
                >
                  {element?.title}
                </Typography>
              </Typography>
              <Typography
                sx={{
                  textAlign: { xs: 'justify', md: 'left' },
                  fontSize: '1.1rem',
                  marginTop: '1rem',
                }}
              >
                {element?.desc}
              </Typography>
            </Grid>
          ))}
        </Box>
      </Box>
    </>
  );
};

export default OurRole;

/* eslint-disable import/no-unresolved */
import React from 'react';
import whoWeAreIllustration from '@images/shared/whoweare 1.png';

import { useTheme } from '@mui/material/styles';
import { Box, Grid, Typography } from '@mui/material';

const WhoWeAre = () => {
  const theme = useTheme();

  return (
    <Box
      sx={{
        maxWidth: '1240px',
        marginX: 'auto',
        paddingX: '1rem',
        paddingY: '2rem',
        gap: 8,
      }}
    >
      <Typography textAlign="center">
        <Typography
          component="p"
          sx={{
            display: 'inline-block',
            marginX: 'auto',
            backgroundColor: '#FEB618',
            color: '#000000',
            fontSize: '2rem',
            fontWeight: '800',
            padding: '1rem 2rem',
            borderRadius: '0 1.8rem 0 1.8rem',
          }}
        >
          Who We Are?
        </Typography>
      </Typography>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'column', // Default to column for mobile view
          [theme.breakpoints.up('md')]: {
            flexDirection: 'row', // Change to row for medium and larger screens
          },
          paddingY: '2rem',
          paddingX: '1rem',
          gap: 8,
        }}
      >
        <Grid item sm={6} data-aos="fade-right" data-aos-duration="1200">
          <Typography
            sx={{
              textAlign: { xs: 'justify', md: 'left' },
              fontSize: { xs: '1.4rem', md: '1.1rem' },
              fontWeight: 'semiBold',
              color: '#ffffff',
            }}
          >
            MingleLoans was founded on the belief that everyone deserves access to fair and
            transparent financial services. Whether you’re a salaried professional, a business
            owner, or self-employed, our goal is to help you unlock the financial opportunities you
            need to achieve your dreams. We understand that navigating the world of loans can be
            overwhelming, which is why we’re here to guide you every step of the way.
          </Typography>
          <Typography
            sx={{
              textAlign: { xs: 'justify', md: 'left' },
              fontSize: { xs: '1.4rem', md: '1.1rem' },
              fontWeight: 'semiBold',
              marginTop: '2rem',
              color: '#ffffff',
            }}
          >
            At MingleLoans, we specialize in offering a diverse array of loan options, including
            Personal Loans, Business Loans, Home Loans, Overdraft Facilities, Mortgage Loans,
            Education Loans, and more. What sets us apart is our ability to act as a trusted
            intermediary between you, the customer, and various banks and NBFCs (Non-Banking
            Financial Companies). This unique position allows us to negotiate the best terms on your
            behalf, ensuring that you receive competitive interest rates and flexible repayment
            options.
          </Typography>
        </Grid>

        <Grid item sm={6} data-aos="fade-right" data-aos-duration="1000">
          <Box component="img" width="100%" src={whoWeAreIllustration} />
        </Grid>
      </Box>
    </Box>
  );
};

export default WhoWeAre;

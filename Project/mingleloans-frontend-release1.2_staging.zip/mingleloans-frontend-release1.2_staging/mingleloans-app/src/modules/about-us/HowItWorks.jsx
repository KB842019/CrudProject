/* eslint-disable import/no-unresolved */
import React from 'react';

import { Box, Grid, Typography } from '@mui/material';

import { howItWorks } from 'src/assets/data/SiteHomePageFeatures';

const HowItWorks = () => (
  <Box
    sx={{
      maxWidth: '1048px',
      marginX: 'auto',
    }}
  >
    <Typography textAlign="center">
      <Typography
        component="p"
        sx={{
          display: 'inline-block',
          marginX: 'auto',
          color: '#000000',
          fontSize: '2rem',
          fontWeight: '700',
          textDecoration: 'underline',
        }}
      >
        How It Works?
      </Typography>
      <Typography
        component="p"
        sx={{
          marginX: 'auto',
          color: '#000000',
          paddingY: '2rem',
          fontSize: '1.2rem',
        }}
      >
        The process of securing a loan through MingleLoans is designed to be simple, transparent,
        and efficient
      </Typography>
    </Typography>

    <Box
      sx={{
        display: 'flex',
        flexDirection: { xs: 'column', sm: 'row' },
        flexWrap: 'wrap',
        paddingX: '1.4rem',
        paddingY: '2.4rem',
        justifyContent: 'space-between',
        marginTop: '2rem',
        gap: '3rem',
      }}
    >
      {howItWorks?.map((element, idx) => (
        <Grid
          key={idx}
          sm={12}
          md={4}
          sx={{
            width: { xs: 'column', sm: 'calc(50% - 2rem)' },
            backgroundColor: '#ffffff',
            padding: '2rem',
            borderRadius: '0 2.2rem 0 2.2rem',
          }}
          data-aos={element?.animation}
          data-aos-duration={element?.duration}
        >
          <Typography
            component="p"
            sx={{
              marginTop: '-3.2rem',
              textAlign: 'center',
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <Typography
              sx={{
                position: 'relative',
                width: '70px',
                fontSize: '2rem',
                fontWeight: '900',
                backgroundColor: '#FEB618',
                color: '133C7A',
                padding: '5px',
                marginRight: '-2rem',
                borderRadius: '50%',
                border: ' 2px solid #ffffff',
              }}
            >
              {element?.number}
            </Typography>
            <Typography
              variant="h5"
              sx={{
                width: '100%',
                maxWidth: '24rem',
                // display: 'inline-block',
                backgroundColor: '#133C7A',
                color: '#ffffff',
                fontWeight: '700',
                padding: '0.8rem 2rem',
                borderRadius: '1rem',
                border: '2px solid #ffffff',
              }}
            >
              {element?.title}
            </Typography>
          </Typography>
          <Typography
            sx={{
              textAlign: 'justify',
              fontSize: '1.1rem',
              lineHeight: '1.2rem',
              marginTop: '1rem',
              paddingX: '2rem',
            }}
          >
            {element?.desc}
          </Typography>
        </Grid>
      ))}
    </Box>
  </Box>
);

export default HowItWorks;

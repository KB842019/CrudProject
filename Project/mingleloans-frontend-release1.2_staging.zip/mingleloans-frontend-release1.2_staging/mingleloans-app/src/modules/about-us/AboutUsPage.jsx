/* eslint-disable import/no-unresolved */
import { Helmet } from 'react-helmet-async';
import AboutUsView from '@modules/about-us/AboutUsView';

// ----------------------------------------------------------------------

export default function AboutUsPage() {
  return (
    <>
      <Helmet>
        <title> MingleLoans : About us </title>
      </Helmet>

      <AboutUsView title="About us" />
    </>
  );
}

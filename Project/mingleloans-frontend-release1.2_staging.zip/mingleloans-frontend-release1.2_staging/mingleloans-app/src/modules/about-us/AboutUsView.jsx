/* eslint-disable import/no-unresolved */
import WhyIllustration from '@images/shared/why 1.png';
import AboutUsIllustration from '@images/shared/About_us.png';

import { useTheme } from '@mui/material/styles';
import { Box, Grid, Typography } from '@mui/material';

import MainLayout from 'src/components/page-layouts/main';

import OurRole from './OurRole';
import WhoWeAre from './WhoWeAre';
import HowItWorks from './HowItWorks';

export default function AboutUsView() {
  const theme = useTheme();
  return (
    <MainLayout>
      <Box
        sx={{
          overflow: 'hidden',
          position: 'relative',
          bgcolor: 'background.default',
        }}
      >
        <Box sx={{ position: 'relative' }}>
          <Box
            sx={{
              maxWidth: '1240px',
              marginX: 'auto',
              paddingX: '1rem',
              paddingTop: '2rem',
              gap: 8,
              display: 'flex',
              flexDirection: 'column', // Default to column for mobile view
              [theme.breakpoints.up('md')]: {
                flexDirection: 'row', // Change to row for medium and larger screens
              },
            }}
          >
            <Grid item sm={6}>
              <Box component="img" width="100%" src={AboutUsIllustration} sx={{}} />
            </Grid>

            <Grid item sm={6} textAlign="center">
              <Typography component="p">
                <Typography
                  variant="h3"
                  sx={{
                    position: 'relative',
                    display: 'inline-block',
                    marginX: 'auto',
                    marginBottom: '-0.8rem',
                    backgroundColor: '#FEB618',
                    color: '#133C7A',
                    fontSize: '2rem',
                    fontWeight: '800',
                    padding: '0.8rem 2rem',
                    borderRadius: '0 1.8rem 0 1.8rem',
                  }}
                >
                  About MingleLoans
                </Typography>
              </Typography>
              <Typography component="p">
                <Typography
                  variant="h3"
                  sx={{
                    display: 'inline-block',
                    marginX: 'auto',
                    backgroundColor: '#133C7A',
                    color: '#FFFFFF',
                    fontSize: '1.6rem',
                    fontWeight: '300',
                    padding: '1rem 2rem',
                    borderRadius: '0 1.8rem 0 1.8rem',
                  }}
                >
                  Your Trusted Financial Intermediary
                </Typography>
              </Typography>

              <Typography
                component="p"
                sx={{
                  paddingY: '2rem',
                  fontSize: '1.5rem',
                  fontWeight: '600',
                  textAlign: 'justify',
                }}
              >
                Welcome to MingleLoans, where we bridge the gap between customers and financial
                institutions, offering tailored loan solutions that meet your unique financial
                needs. As an intermediary, MingleLoans plays a crucial role in simplifying the loan
                process, ensuring that every customer receives the most suitable financial products
                with the best possible terms. Our mission is to provide a seamless, efficient, and
                customer-centric experience that makes accessing loans easy and stress-free.
              </Typography>
            </Grid>
          </Box>

          <Box
            sx={{
              backgroundColor: '#2E8ACA',
              marginTop: '3rem',
            }}
          >
            <WhoWeAre />
          </Box>

          <Box
            sx={{
              backgroundColor: '#FFDE4D',
              padding: '3rem 1rem',
            }}
          >
            <OurRole />
          </Box>

          <Box
            sx={{
              backgroundColor: '#ffffff',
              paddingY: '3rem',
            }}
          >
            <HowItWorks />
          </Box>

          <Box
            sx={{
              backgroundColor: '#9F0000',
              paddingY: '3rem',
            }}
          >
            <Box
              sx={{
                maxWidth: '1048px',
                marginX: 'auto',
                paddingX: '1rem',
              }}
            >
              <Typography textAlign="center">
                <Typography
                  component="p"
                  sx={{
                    display: 'inline-block',
                    marginX: 'auto',
                    color: '#ffffff',
                    fontSize: '1.5rem',
                    fontWeight: '600',
                  }}
                >
                  Why Choose MingleLoans?
                </Typography>
                <Typography
                  component="p"
                  sx={{
                    marginX: 'auto',
                    color: '#ffffff',
                    paddingY: '2rem',
                    fontSize: '1.2rem',
                  }}
                >
                  There are several reasons why MingleLoans has become a trusted name in the
                  financial services industry
                </Typography>
              </Typography>

              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'start',
                  flexDirection: { xs: 'column', sm: 'row' },
                  gap: '2rem',
                }}
              >
                <Box
                  sx={{
                    maxWidth: '550px',
                    display: 'flex',
                    alignItems: 'start',
                    flexDirection: 'column',
                    gap: '2rem',
                  }}
                >
                  <Box>
                    <Box component="img" src={WhyIllustration} />
                  </Box>

                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '2rem',
                    }}
                  >
                    <Box
                      sx={{
                        maxWidth: '550px',
                        backgroundColor: '#ffffff',
                        padding: '1rem 2.6rem 3rem 2.6rem',
                        borderRadius: '1.2rem',
                      }}
                      // data-aos="fade-up"
                      // data-aos-duration="1000"
                    >
                      <Typography
                        sx={{
                          fontSize: '1.5rem',
                          fontWeight: '700',
                          color: '#9F0000',
                          textDecoration: 'underline',
                        }}
                      >
                        Personalized Service
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: '1.2rem',
                          color: '#000000',
                          marginTop: '0.8rem',
                          lineHeight: '1.4rem',
                        }}
                      >
                        At MingleLoans, we believe in providing personalized service to each and
                        every customer. We take the time to understand your unique needs and tailor
                        our services to meet them.
                      </Typography>
                    </Box>
                    <Box
                      sx={{
                        maxWidth: '550px',
                        backgroundColor: '#ffffff',
                        padding: '1rem 2.6rem 3rem 2.6rem',
                        borderRadius: '1.2rem',
                      }}
                      // data-aos="fade-up"
                      // data-aos-duration="1000"
                    >
                      <Typography
                        sx={{
                          fontSize: '1.5rem',
                          fontWeight: '700',
                          color: '#9F0000',
                          textDecoration: 'underline',
                        }}
                      >
                        Customer Satisfaction
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: '1.2rem',
                          color: '#000000',
                          marginTop: '0.8rem',
                          lineHeight: '1.4rem',
                        }}
                      >
                        Customer satisfaction is our top priority. We strive to exceed your
                        expectations at every stage of the loan process, ensuring that you have a
                        positive experience from start to finish.
                      </Typography>
                    </Box>
                  </Box>
                </Box>

                <Box
                  sx={{
                    maxWidth: '550px',
                    display: 'flex',
                    alignItems: 'start',
                    flexDirection: 'column',
                    gap: '2rem',
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '2rem',
                    }}
                  >
                    <Box
                      sx={{
                        maxWidth: '550px',
                        backgroundColor: '#ffffff',
                        padding: '1rem 2.6rem 3rem 2.6rem',
                        borderRadius: '1.2rem',
                      }}
                      // data-aos="fade-up"
                      // data-aos-duration="1000"
                    >
                      <Typography
                        sx={{
                          fontSize: '1.5rem',
                          fontWeight: '700',
                          color: '#9F0000',
                          textDecoration: 'underline',
                        }}
                      >
                        Comprehensive Loan Options
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: '1.2rem',
                          color: '#000000',
                          marginTop: '0.8rem',
                          lineHeight: '1.4rem',
                        }}
                      >
                        We offer a wide range of loan products to meet the diverse needs of our
                        customers. Whether you’re looking for a personal loan, a business loan, or a
                        mortgage, MingleLoans has you covered.
                      </Typography>
                    </Box>
                    <Box
                      sx={{
                        maxWidth: '550px',
                        backgroundColor: '#ffffff',
                        padding: '1rem 2.6rem 3rem 2.6rem',
                        borderRadius: '1.2rem',
                      }}
                      // data-aos="fade-up"
                      // data-aos-duration="1000"
                    >
                      <Typography
                        sx={{
                          fontSize: '1.5rem',
                          fontWeight: '700',
                          color: '#9F0000',
                          textDecoration: 'underline',
                        }}
                      >
                        Expertise and Experience
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: '1.2rem',
                          color: '#000000',
                          marginTop: '0.8rem',
                          lineHeight: '1.4rem',
                        }}
                      >
                        Our team of financial experts has years of experience in the industry. We
                        have the knowledge and skills needed to navigate the complexities of the
                        loan market and secure the best deals for our customers.
                      </Typography>
                    </Box>
                    <Box
                      sx={{
                        maxWidth: '550px',
                        backgroundColor: '#ffffff',
                        padding: '1rem 2.6rem 3rem 2.6rem',
                        borderRadius: '1.2rem',
                      }}
                      // data-aos="fade-up"
                      // data-aos-duration="1000"
                    >
                      <Typography
                        sx={{
                          fontSize: '1.5rem',
                          fontWeight: '700',
                          color: '#9F0000',
                          textDecoration: 'underline',
                        }}
                      >
                        Transparent and Trustworthy
                      </Typography>
                      <Typography
                        sx={{
                          fontSize: '1.2rem',
                          color: '#000000',
                          marginTop: '0.8rem',
                          lineHeight: '1.4rem',
                        }}
                      >
                        Transparency is at the core of our business. We believe in providing clear,
                        honest information to our customers, so you can make informed decisions
                        about your financial future.
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            </Box>
          </Box>

          <Box
            sx={{
              maxWidth: '1048px',
              marginX: 'auto',
              padding: '1.2rem 0',
            }}
          >
            <Typography
              textAlign="center"
              sx={{
                paddingX: '1rem',
              }}
            >
              <Typography
                component="p"
                sx={{
                  display: 'inline-block',
                  marginX: 'auto',
                  color: '#000000',
                  fontSize: '1.8rem',
                  fontWeight: '700',
                }}
              >
                Join the MingleLoans Family
              </Typography>
              <Typography
                component="p"
                sx={{
                  marginX: 'auto',
                  color: '#000000',
                  padding: '1rem 0 2rem 0',
                  fontSize: '1.2rem',
                  fontWeight: '500',
                  textAlign: { xs: 'justify', sm: 'left' },
                }}
              >
                At MingleLoans, we’re more than just a financial intermediary—we’re your partner in
                achieving your financial goals. Whether you’re looking to buy a new home, expand
                your business, or manage your debts, we’re here to help you every step of the way.
                Join the MingleLoans family today and discover how we can make your financial dreams
                a reality.
              </Typography>
            </Typography>
          </Box>
        </Box>
      </Box>
    </MainLayout>
  );
}

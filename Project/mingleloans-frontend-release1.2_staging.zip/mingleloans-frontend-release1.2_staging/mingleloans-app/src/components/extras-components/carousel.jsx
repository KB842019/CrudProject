// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
import React from "react";
import Slider from "react-slick";

import HomeAdvertisement from "./home-advertisement";

// import PropTypes from 'prop-types';

export default function SimpleSlider() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  return (
    <div className="slider-container">
      <Slider {...settings}>
        {/* <div>
          <h3>1</h3>
        </div>
        <div>
          <h3>2</h3>
        </div>
        <div>
          <h3>3</h3>
        </div>
        <div>
          <h3>4</h3>
        </div>
        <div>
          <h3>5</h3>
        </div>
        <div>
          <h3>6</h3>
        </div> */}
        {/* {elements} */}
        <HomeAdvertisement />
      </Slider>
    </div>
  );
}

// SimpleSlider.propTypes = {
//   elements: PropTypes.arrayOf(PropTypes.element)
// };
import * as Yup from 'yup';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// eslint-disable-next-line import/no-unresolved
import FormProvider, { RHFTextField } from '@components/mui-components/hook-form';

import Typography from '@mui/material/Typography';
import { Grid, FormControl, LoadingButton } from '@mui/material';

// ----------------------------------------------------------------------

export default function SwaggerApiView() {
  const [errorMsg, setErrorMsg] = useState('');

  const apiRequestSchema = Yup.object().shape({
    requestUrl: Yup.string().required('API Endpoint is required.'),
    queryString: Yup.string(),
    body: Yup.string(),
  });

  const methods = useForm({
    resolver: yupResolver(apiRequestSchema),
  });

  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
    // watch, setValue,
    // register,
  } = methods;

  console.log(errorMsg);

  const onSubmit = handleSubmit(async (data) => {
    try {
      console.log('Call API');
      console.log(data);
    } catch (error) {
      console.error(error);
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });

  return (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Typography mt={1} mb={2}>
          Test API
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="apiUrl" label="API Url" />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="queryString" label="Query String" />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="aadhaarNumber" label="Request Body" />
          </Grid>

          <Grid item xs={12} sm={6} md={6}>
            <LoadingButton type="submit" variant="contained" loading={isSubmitting}>
              Submit
            </LoadingButton>
          </Grid>

          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="response" label="API Response" disabled />
          </Grid>
        </Grid>
      </FormControl>
    </FormProvider>
  );
}

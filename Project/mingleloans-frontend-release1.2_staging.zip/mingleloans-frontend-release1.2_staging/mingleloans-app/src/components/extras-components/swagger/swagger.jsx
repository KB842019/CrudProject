import { Helmet } from 'react-helmet-async';

import ComingSoonPage from '../../page-components/coming-soon/view';

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
      <Helmet>
        <title>Dashboard: Swagger</title>
      </Helmet>
      <ComingSoonPage />
    </>
  );
}

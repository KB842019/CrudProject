import { Helmet } from 'react-helmet-async';

import FourView from 'src/components/extras-components/four/view';

// ----------------NOT USED------------------------------------------------------

export default function Four() {
  return (
    <>
      <Helmet>
        <title> Dashboard: Profile</title>
      </Helmet>

      <FourView />
    </>
  );
}

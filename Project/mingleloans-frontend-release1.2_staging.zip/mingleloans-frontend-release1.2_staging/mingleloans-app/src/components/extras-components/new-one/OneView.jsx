/* eslint-disable import/no-unresolved */
import { useState } from 'react';

import { GridMenuIcon } from '@mui/x-data-grid';
import {
  Grid,
  Card,
  AppBar,
  Button,
  Dialog,
  Toolbar,
  IconButton,
  Typography,
  CardContent,
  DialogTitle,
  DialogContent,
} from '@mui/material';

import notifications from 'src/assets/dummy/Notification.json';

// import PieChart from 'src/components/chart-components/PieChart';

export default function OneView() {
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedMessage, setSelectedMessage] = useState('');

  const handleClick = (message) => {
    setSelectedMessage(message);
    setOpenDialog(true);
  };

  const handleClose = () => {
    setOpenDialog(false);
    setSelectedMessage('');
  };

  return (
    <>
      <Grid container direction="column" justifyContent="center">
        <Grid item xs={12}>
          <Grid mt={3} display="flex" justifyContent="center" alignItems="center">
            <AppBar
              color="success"
              position="static"
              sx={{
                height: '60px',
                borderRadius: '10px',
                width: '98.5%',
                maxWidth: '100%',
                marginLeft: '12px',
              }}
            >
              <Toolbar>
                <IconButton
                  size="large"
                  edge="start"
                  color="inherit"
                  aria-label="menu"
                  sx={{ mr: 2 }}
                />
                <Typography variant="h4" component="div" sx={{ flexGrow: 1 }}>
                  Dashboard
                </Typography>
                <Button color="inherit">
                  <GridMenuIcon />
                </Button>
              </Toolbar>
            </AppBar>
          </Grid>

          <Grid container spacing={2} sx={{ justifyContent: 'center', width: '100%', margin: 0 }}>
            <Grid item xs={12} md={6}>
              <Card
                sx={{
                  height: '300px',
                  backgroundColor: 'lightblue',
                  borderRadius: 2,
                  boxShadow: 3,
                  width: '100%',
                }}
              >
                <CardContent>
                  <Typography variant="h5" color="black" gutterBottom>
                    Important Notifications
                  </Typography>
                  <Grid sx={{ overflowY: 'auto', maxHeight: '220px' }}>
                    {notifications.map((notification) => (
                      <Grid
                        key={notification.id}
                        sx={{
                          marginBottom: 2,
                          paddingBottom: 1,
                          borderBottom: '1px solid #8E33FF',
                        }}
                      >
                        <Grid display="flex" justifyContent="space-between">
                          <Typography variant="subtitle1" fontWeight="600" color="cornflowerblue">
                            {notification.title}
                          </Typography>
                          <Typography variant="body2" color="white" sx={{ fontSize: '0.8rem' }}>
                            {new Date(notification.timestamp).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </Typography>
                        </Grid>
                        <Typography
                          variant="body2"
                          color="white"
                          sx={{
                            cursor: 'pointer',
                            transition: 'all 0.3s ease',
                          }}
                          onClick={() => handleClick(notification.message)}
                        >
                          {notification.message}
                        </Typography>
                      </Grid>
                    ))}
                  </Grid>
                </CardContent>
              </Card>
            </Grid>

            {/* Pie Chart in Second Card */}
            <Grid item xs={12} md={6}>
              <Card
                sx={{
                  height: '300px',
                  backgroundColor: '#CAFDF5',
                  borderRadius: 2,
                  boxShadow: 3,
                  width: '100%',
                }}
              >
                <CardContent>
                  <Typography variant="h6" color="#003768" fontWeight="600" gutterBottom>
                    Sales Leads
                  </Typography>
                  {/* <PieChart /> */}
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card
                sx={{
                  height: '300px',
                  backgroundColor: '#D3FCD2',
                  borderRadius: 2,
                  boxShadow: 3,
                  width: '100%',
                }}
              >
                <CardContent>
                  <Typography variant="h6" color="orange" fontWeight="600" gutterBottom>
                    Sales
                  </Typography>
                </CardContent>
              </Card>
            </Grid>

            <Grid item xs={12} md={6}>
              <Card
                sx={{
                  height: '300px',
                  backgroundColor: '#FFE9D5',
                  borderRadius: 2,
                  boxShadow: 3,
                  width: '100%',
                }}
              >
                <CardContent>
                  <Typography variant="h6" color="brown" fontWeight="600" gutterBottom>
                    Tasks
                  </Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        </Grid>
      </Grid>

      <Dialog open={openDialog} onClose={handleClose}>
        <DialogTitle>Notification Message</DialogTitle>
        <DialogContent>
          <Typography mb={2} variant="body1">
            {selectedMessage}
          </Typography>
        </DialogContent>
      </Dialog>
    </>
  );
}

/* eslint-disable import/no-unresolved */
// import Box from '@mui/material/Box';
// import { alpha } from '@mui/material/styles';
// import Container from '@mui/material/Container';
// import Typography from '@mui/material/Typography';

// import { useSettingsContext } from 'src/components/settings';

// // ----------------------------------------------------------------------

// export default function OneView() {
//   const settings = useSettingsContext();

//   return (
//     <Container maxWidth={settings.themeStretch ? false : 'xl'}>
//       <Typography variant="h4"> Dashboard </Typography>

//       <Box
//         sx={{
//           mt: 5,
//           width: 1,
//           height: 320,
//           borderRadius: 2,
//           bgcolor: (theme) => alpha(theme.palette.grey[500], 0.04),
//           border: (theme) => `dashed 1px ${theme.palette.divider}`,
//         }}
//         display='flex'
//         flexDirection='column'
//         justifyContent='center'
//         alignItems='center'
//       >
//         <Typography variant='h2'>Hello User!</Typography>
//         <Typography variant='h4'>Welcome to Mingle Loans</Typography>
//       </Box>
//     </Container>
//   );
// }

import { Link } from 'react-router-dom';
import { SeoIllustration } from '@assets/illustrations';
import { useSettingsContext } from '@components/mui-components/settings';

import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Unstable_Grid2';

import AppWelcome from './app-welcome';

// ----------------------------------------------------------------------

export default function OneView() {
  const settings = useSettingsContext();

  return (
    <Container sx={{marginTop:'20px'}} maxWidth={settings.themeStretch ? false : 'xl'}>
      <Grid container spacing={3}>
        <Grid xs={12} md={12}>
          <AppWelcome
            title={`Dashboard `}
            description="Efficiently manage and monitor all aspects of loan processing from application to approval through this comprehensive dashboard. Designed for clarity and ease of use, it offers real-time insights to optimize decision-making and improve customer satisfaction."
            img={<SeoIllustration />}
            action={
              <Link to="/individual/my-applications">
                <Button variant="contained" color="primary">
                  Go Now
                </Button>
              </Link>
            }
          />
        </Grid>
      </Grid>
    </Container>
  );
}

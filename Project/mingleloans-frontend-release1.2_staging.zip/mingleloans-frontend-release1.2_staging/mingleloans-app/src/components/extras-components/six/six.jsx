import { Helmet } from 'react-helmet-async';

import SixView from 'src/components/extras-components/six/view';

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
      <Helmet>
        <title> Dashboard: Loan Process</title>
      </Helmet>

      <SixView />
    </>
  );
}

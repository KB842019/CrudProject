import { Helmet } from 'react-helmet-async';

import SampleView from 'src/components/extras-components/sample/view';

// ----------------------------------------------------------------------

export default function Page() {
  return (
    <>
      <Helmet>
        <title>Dashboard: Sample</title>
      </Helmet>
      <SampleView />
    </>
  );
}

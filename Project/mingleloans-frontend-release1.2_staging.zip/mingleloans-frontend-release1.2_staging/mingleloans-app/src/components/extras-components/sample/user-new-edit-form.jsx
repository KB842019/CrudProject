/* eslint-disable import/no-unresolved */
import * as Yup from 'yup';
import moment from 'moment';
import Label from '@components/mui-components/label';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { useMemo, useEffect, useCallback } from 'react';
import { useSnackbar } from '@components/mui-components/snackbar';
import FormProvider, { RHFTextField, RHFUploadAvatar } from '@components/mui-components/hook-form';

import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Switch from '@mui/material/Switch';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import LoadingButton from '@mui/lab/LoadingButton';
import FormControlLabel from '@mui/material/FormControlLabel';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { Select, MenuItem, InputLabel, FormControl } from '@mui/material';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';

import { useRouter } from 'src/routes/hooks';
import { ModuleRoutes } from 'src/routes/ModuleRoutes';

import { fData } from 'src/utils/format-number';

import useSampleStore from 'src/store/sample-store/SampleStore';

// ----------------------------------------------------------------------

export default function UserNewEditForm() {
  const router = useRouter();
  const {
    selectedCustomer,
    addCustomer,
    customerList,
    setSelectedCustomer,
    updateCustomer,
    viewBool,
    setViewBool,
  } = useSampleStore((state) => state);
  const { enqueueSnackbar } = useSnackbar();

  const NewUserSchema = Yup.object().shape({
    firstName: Yup.string().required('First Name is required'),
    lastName: Yup.string().required('Last Name is required'),
    dob: Yup.string(),
    // contactNumber: Yup.string()
    //   .matches(/^[6789]\d{9}$/, 'Invalid mobile number')
    //   .required('Mobile number is required'),
    avatarUrl: Yup.mixed().nullable().required('Avatar is required'),
    isVerified: Yup.boolean(),
    gender: Yup.string().required('Gender is required'),
    tierLevel: Yup.string().required('Tier Level is required'),
    address: Yup.string().required('Address is required'),
  });

  const defaultValues = useMemo(
    () => ({
      firstName: selectedCustomer?.firstName || '',
      lastName: selectedCustomer?.lastName || '',
      dob: selectedCustomer?.dob,
      avatarUrl: selectedCustomer?.avatarUrl || null,
      // contactNumber: selectedCustomer?.contactNumber || '',
      pin: selectedCustomer?.pin || 12345,
      staffId: selectedCustomer?.staffId || `CUS00${customerList.length + 1}`,
      tierLevel: selectedCustomer?.tierLevel || '',
      gender: selectedCustomer?.gender || '',
      address: selectedCustomer?.address || '',
    }),
    [selectedCustomer, customerList]
  );

  const methods = useForm({
    resolver: yupResolver(NewUserSchema),
    defaultValues,
  });

  const {
    reset,
    watch,
    control,
    setValue,
    handleSubmit,
    register,
    formState: { isSubmitting },
  } = methods;

  const values = watch();

  const onSubmit = handleSubmit(async (data) => {
    console.log('User Details:', data);
    try {
      await new Promise((resolve) => setTimeout(resolve, 500));
      reset();
      enqueueSnackbar(selectedCustomer ? 'Update success!' : 'Create success!');
      const staffId = `CUS00${customerList.length + 1}`;
      const newData = {
        ...data,
        id: +customerList.length + 1,
        staffId,
        status: 'active',
        dob: moment(data.dob).format('MM-DD-YYYY'),
        pin: 12345,
      };
      if (selectedCustomer) updateCustomer(selectedCustomer?.id, newData);
      else addCustomer(newData);
      setSelectedCustomer(null);
      router.push(ModuleRoutes.customer.index);
    } catch (error) {
      console.error(error);
    }
  });

  const handleDrop = useCallback(
    (acceptedFiles) => {
      const file = acceptedFiles[0];

      const newFile = Object.assign(file, {
        preview: URL.createObjectURL(file),
      });

      if (file) {
        setValue('avatarUrl', newFile, { shouldValidate: true });
      }
    },
    [setValue]
  );

  useEffect(
    () => () => {
      setViewBool(false);
      setSelectedCustomer(null);
    },
    [setViewBool, setSelectedCustomer]
  );

  return (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <Grid container spacing={3}>
        <Grid xs={12} md={4}>
          <Card sx={{ pt: 10, pb: 5, px: 3 }}>
            {selectedCustomer && (
              <Label
                color={
                  (values.status === 'active' && 'success') ||
                  (values.status === 'suspended' && 'error') ||
                  'warning'
                }
                sx={{ position: 'absolute', top: 24, right: 24 }}
              >
                {values.status}
              </Label>
            )}

            <Box sx={{ mb: 5 }}>
              <RHFUploadAvatar
                name="avatarUrl"
                maxSize={3145728}
                onDrop={handleDrop}
                disabled={viewBool}
                helperText={
                  <Typography
                    variant="caption"
                    sx={{
                      mt: 3,
                      mx: 'auto',
                      display: 'block',
                      textAlign: 'center',
                      color: 'text.disabled',
                    }}
                  >
                    Allowed *.jpeg, *.jpg, *.png, *.gif
                    <br /> max size of {fData(3145728)}
                  </Typography>
                }
              />
            </Box>

            {selectedCustomer && (
              <FormControlLabel
                labelPlacement="start"
                control={
                  <Controller
                    name="status"
                    control={control}
                    disabled={viewBool}
                    render={({ field }) => (
                      <Switch
                        {...field}
                        checked={field.value !== 'active'}
                        onChange={(event) =>
                          field.onChange(event.target.checked ? 'suspended' : 'active')
                        }
                      />
                    )}
                  />
                }
                label={
                  <>
                    <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
                      Suspended
                    </Typography>
                    <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                      Apply disable account
                    </Typography>
                  </>
                }
                sx={{ mx: 0, mb: 3, width: 1, justifyContent: 'space-between' }}
              />
            )}
          </Card>
        </Grid>

        <Grid xs={12} md={8}>
          <Card sx={{ p: 3 }}>
            <Box
              rowGap={3}
              columnGap={2}
              display="grid"
              gridTemplateColumns={{
                xs: 'repeat(1, 1fr)',
                sm: 'repeat(2, 1fr)',
              }}
            >
              <RHFTextField
                name="staffId"
                label="Staff ID"
                disabled
                defaultValue={`CUS00${customerList.length + 1}`}
              />
              <RHFTextField name="pin" label="PIN" disabled defaultValue={12345} />
              <RHFTextField name="firstName" label="First Name" disabled={viewBool} />
              <RHFTextField name="lastName" label="Last Name" disabled={viewBool} />
              <FormControl fullWidth>
                <InputLabel id="gender">Gender</InputLabel>
                <Select
                  fullWidth
                  labelId="gender"
                  id="gender"
                  autoWidth
                  name="gender"
                  label="Gender"
                  xs={12}
                  sm={6}
                  md={4}
                  required
                  disabled={viewBool}
                  defaultValue={selectedCustomer?.gender}
                  {...register('gender')}
                >
                  <MenuItem value="">
                    <em>Select Gender</em>
                  </MenuItem>
                  <MenuItem value="Male">Male</MenuItem>
                  <MenuItem value="Female">Female</MenuItem>
                  <MenuItem value="Others">Others</MenuItem>
                </Select>
              </FormControl>

              <FormControl fullWidth>
                <InputLabel id="tierLevel">Tier Level </InputLabel>
                <Select
                  fullWidth
                  labelId="tierLevel"
                  id="tierLevel"
                  autoWidth
                  name="tierLevel"
                  label="tierLevel"
                  xs={12}
                  sm={6}
                  md={4}
                  required
                  disabled={viewBool}
                  defaultValue={selectedCustomer?.tierLevel}
                  {...register('tierLevel')}
                >
                  <MenuItem value="">
                    <em>Tier level</em>
                  </MenuItem>
                  <MenuItem value="Bronze">Bronze</MenuItem>
                  <MenuItem value="Silver">Silver</MenuItem>
                  <MenuItem value="Golden">Golden</MenuItem>
                  <MenuItem value="Platinum">Platinum</MenuItem>
                </Select>
              </FormControl>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DesktopDatePicker
                  label="Date of birth"
                  name="dob"
                  defaultValue={new Date(selectedCustomer?.dob)}
                  minDate={new Date('1950-01-01')}
                  onChange={(newValue) => {
                    console.log(newValue);
                    setValue('dob', newValue);
                  }}
                  disabled={viewBool}
                  slotProps={{
                    textField: {
                      fullWidth: true,
                      // margin: 'normal',
                    },
                  }}
                />
              </LocalizationProvider>
              <RHFTextField name="address" label="Address" disabled={viewBool} />
            </Box>

            <Stack alignItems="flex-end" sx={{ mt: 3 }}>
              {!viewBool && (
                <LoadingButton type="submit" variant="contained" loading={isSubmitting}>
                  {!selectedCustomer ? 'Create' : 'Save Changes'}
                </LoadingButton>
              )}
            </Stack>
          </Card>
        </Grid>
      </Grid>
    </FormProvider>
  );
}

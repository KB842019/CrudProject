import { useSettingsContext } from '@components/mui-components/settings';
import CustomBreadcrumbs from '@components/mui-components/custom-breadcrumbs';

import Container from '@mui/material/Container';

import { ModuleRoutes } from 'src/routes/ModuleRoutes';

import UserNewEditForm from './user-new-edit-form';

// ----------------------------------------------------------------------

export default function CustomerCreateView() {
  const settings = useSettingsContext();

  return (
    <Container maxWidth={settings.themeStretch ? false : 'lg'}>
      <CustomBreadcrumbs
        heading="Create a new customer"
        links={[
          {
            name: 'Customers',
            href: ModuleRoutes.customer.addCustomer,
          },
          { name: 'New Customer' },
        ]}
        sx={{
          mb: { xs: 3, md: 5 },
        }}
      />

      <UserNewEditForm />
    </Container>
  );
}

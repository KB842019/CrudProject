import Chart from 'react-apexcharts';
import React, { useState } from 'react';

// eslint-disable-next-line import/no-unresolved
import barChartData from 'src/assets/data/dummy-data/BarData.json';

const BarChart = () => {
  const [chartConfig] = useState({
    options: barChartData.options,
    series: barChartData.series,
  });

  return (
    <div style={{ marginBottom: '20px' }}>
      {/* <h2>Monthly Sales Bar Chart</h2> */}
      <Chart
        options={chartConfig.options}
        series={chartConfig.series}
        type="bar"
        width="500"
        height="250"
      />
    </div>
  );
};

export default BarChart;

/* eslint-disable perfectionist/sort-imports */
import 'src/utils/highlight';

import PropTypes from 'prop-types';
import { lazy, Suspense } from 'react';

import { alpha } from '@mui/material/styles';
import Skeleton from '@mui/material/Skeleton';

import { StyledEditor } from './styles';
import Toolbar, { formats } from './toolbar';

const ReactQuill = lazy(() => import('react-quill'));

// ----------------------------------------------------------------------

export default function Editor({
  id = 'minimal-quill',
  error,
  simple = false,
  helperText,
  sx,
  ...other
}) {
  const modules = {
    toolbar: {
      container: `#${id}`,
    },
    history: {
      delay: 500,
      maxStack: 100,
      userOnly: true,
    },
    syntax: true,
    clipboard: {
      matchVisual: false,
    },
  };

  return (
    <>
      <StyledEditor
        sx={{
          ...(error && {
            border: (theme) => `solid 1px ${theme.palette.error.main}`,
            '& .ql-editor': {
              bgcolor: (theme) => alpha(theme.palette.error.main, 0.08),
            },
          }),
          ...sx,
        }}
      >
        <Toolbar id={id} simple={simple} />
        <Suspense fallback={
          <Skeleton
            sx={{
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              height: 1,
              borderRadius: 1,
              position: 'absolute'
            }}
          />
        }>
          <ReactQuill
            modules={modules}
            formats={formats}
            placeholder="Write something awesome..."
            {...other}
          /></Suspense>
      </StyledEditor>

      {helperText && helperText}
    </>
  );
}

Editor.propTypes = {
  error: PropTypes.bool,
  helperText: PropTypes.object,
  id: PropTypes.string,
  simple: PropTypes.bool,
  sx: PropTypes.object,
};

import React from 'react';
import PropTypes from 'prop-types';
import { Controller, useFormContext } from 'react-hook-form';

import { styled } from '@mui/material/styles';
import { Box, Typography } from '@mui/material';

import Iconify from '../iconify';

const Input = styled('input')({
  display: 'none',
});

export default function RHFFileUpload({ name, label, multiple, showIcon, ...other }) {
  const { control } = useFormContext();

  const handleDeleteFile = (onChange) => {
    onChange(multiple ? [] : null);
  };

  const handlePreviewFile = (file) => {
    const fileURL = URL.createObjectURL(file);
    window.open(fileURL);
  };

  const renderFileName = (value) => {
    if (multiple) {
      return value.length > 0 ? `${value.length} files selected` : label;
    }
    return value ? value.name : label;
  };

  return (
    <Controller
      name={name}
      control={control}
      defaultValue={multiple ? [] : null}
      render={({ field: { onChange, onBlur, value, ref }, fieldState: { error } }) => (
        <>
          <Box>
            <Input
              accept=".pdf,.jpg,.jpeg,.png"
              id={name}
              multiple={multiple}
              type="file"
              onChange={(event) => {
                const files = event?.target?.files;
                onChange(multiple ? Array.from(files) : files[0]);
              }}
              onBlur={onBlur}
              ref={ref}
              {...other}
            />
            <label
              htmlFor={name}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                background: 'white',
                borderRadius: '5px',
                padding: '18px 20px',
                boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
              }}
            >
              <Typography
                sx={{
                  flexGrow: 1, 
                  wordBreak: 'break-all',
                  paddingRight: 1,
                }}
              >
                {renderFileName(value)}
              </Typography>
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 1, 
                }}
              >
                {value && value.length > 0 && showIcon && (
                  <>
                    <Iconify
                      icon="eva:eye-fill"
                      width={30}
                      sx={{ color: 'green', cursor: 'pointer' }}
                      onClick={(event) => {
                        event.stopPropagation();
                        handlePreviewFile(multiple ? value[0] : value);
                      }}
                    />
                    <Iconify
                      icon="eva:trash-2-fill"
                      width={30}
                      sx={{ color: 'crimson', cursor: 'pointer' }}
                      onClick={(event) => {
                        event.stopPropagation();
                        handleDeleteFile(onChange);
                      }}
                    />
                  </>
                )}
                {!multiple && value && showIcon && (
                  <>
                    <Iconify
                      icon="eva:eye-fill"
                      width={30}
                      sx={{ color: 'green', cursor: 'pointer' }}
                      onClick={(event) => {
                        event.stopPropagation();
                        handlePreviewFile(value);
                      }}
                    />
                    <Iconify
                      icon="eva:trash-2-fill"
                      width={30}
                      sx={{ color: 'crimson', cursor: 'pointer' }}
                      onClick={(event) => {
                        event.stopPropagation();
                        handleDeleteFile(onChange);
                      }}
                    />
                  </>
                )}
              </Box>
            </label>
          </Box>

          {error && <p style={{ color: 'red' }}>{error.message}</p>}
        </>
      )}
    />
  );
}

RHFFileUpload.propTypes = {
  name: PropTypes.string.isRequired,
  accept: PropTypes.string,
  multiple: PropTypes.bool,
  label: PropTypes.string,
  showIcon: PropTypes.bool,
};

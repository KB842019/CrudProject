// src/components/BrowserInfo.js
import React, { useState, useEffect } from 'react';

import { getBrowserInfo } from '../../utils/browser';

const BrowserInfo = () => {
  const [browserInfo, setBrowserInfo] = useState({ browserName: '', browserVersion: '' });

  useEffect(() => {
    const info = getBrowserInfo();
    setBrowserInfo(info);
  }, []);

  return (
    <div>
      <h1>Browser Information</h1>
      <p>Browser Name: {browserInfo.browserName}</p>
      <p>Browser Version: {browserInfo.browserVersion}</p>
    </div>
  );
};

export default BrowserInfo;

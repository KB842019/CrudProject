/* eslint-disable import/no-unresolved */
import React from 'react';

import { Button } from '@mui/material';

import { useRouter } from 'src/routes/hooks';

import { useAuthContext } from 'src/middleware/auth/hooks';

const LogoutButton = () => {
  const router = useRouter();
  const { sendLogoutRequest } = useAuthContext();

  const handleLogout = async () => {
    try {
      await sendLogoutRequest();
      router.replace('/');
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <Button color="warning" variant="contained" onClick={handleLogout}>
      Logout
    </Button>
  );
};

export default LogoutButton;

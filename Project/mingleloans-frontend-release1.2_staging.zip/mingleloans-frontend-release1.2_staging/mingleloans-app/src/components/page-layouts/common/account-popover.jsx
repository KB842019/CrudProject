import CustomPopover, { usePopover } from '@components/mui-components/custom-popover';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Avatar from '@mui/material/Avatar';
import Divider from '@mui/material/Divider';
// import { Person } from '@mui/icons-material';
import MenuItem from '@mui/material/MenuItem';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';

import { useRouter } from 'src/routes/hooks';
import { ModuleRoutes } from 'src/routes/ModuleRoutes';
import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import { RESPONSE_CODES } from 'src/global/ResponseCodes';
import { useAuthContext } from 'src/middleware/auth/hooks';
// ----------------------------------------------------------------------

const OPTIONS = [
  {
    label: 'Home',
    linkTo: DefaultRoutes.public_url.home,
  },
  {
    label: 'Profile',
    linkTo: ModuleRoutes.shared.profile,
  },
  {
    label: 'Settings',
    linkTo: ModuleRoutes.shared.account_settings,
  },
];

// ----------------------------------------------------------------------

export default function AccountPopover() {
  const router = useRouter();

  // useMockedUser();

  const { user, sendLogoutRequest } = useAuthContext();
  const popover = usePopover();

  const userData = JSON.parse(localStorage.getItem('user'));

  // Initialize a variable to hold the email
  let userEmail = '';

  // Check if the user object exists and has an email property
  if (userData && userData.email) {
    // Save the email into the variable
    userEmail = userData.email;
    console.log('User Email:', userEmail); // Use the email as needed
  } else {
    // console.log('No user data found in localStorage');
  }

  const handleLogout = async () => {
    try {
      const response = await sendLogoutRequest();

      if (response.responseCode === RESPONSE_CODES.general.Success.code) {
        router.push(DefaultRoutes.auth_url.login);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleClickItem = (path) => {
    popover.onClose();
    router.push(path);
  };

  return (
    <>
      <IconButton color="primary" onClick={popover.onOpen}>
        {/* <Person /> */}
        <Avatar
          src={user?.photoURL}
          alt={user?.firstName}
          sx={{
            width: 36,
            height: 36,
            border: (theme) => `solid 2px ${theme.palette.background.default}`,
          }}
        >
          {user?.firstName?.charAt(0).toUpperCase()}
        </Avatar>
      </IconButton>

      <CustomPopover open={popover.open} onClose={popover.onClose} sx={{ width: 200, p: 0 }}>
        <Box sx={{ p: 2, pb: 1.5 }}>
          <Typography variant="subtitle2" sx={{ fontSize: '14px' }} noWrap>
            Hi! {user?.firstName}
          </Typography>

          <Typography variant="body2" sx={{ color: 'text.secondary', fontSize: '13px' }} noWrap>
            Entity Code: {user?.entityCode}
          </Typography>
        </Box>

        <Divider sx={{ borderStyle: 'dashed' }} />

        <Stack sx={{ p: 1 }}>
          {OPTIONS.map((option) => (
            <MenuItem key={option.label} onClick={() => handleClickItem(option.linkTo)}>
              {option.label}
            </MenuItem>
          ))}
        </Stack>

        <Divider sx={{ borderStyle: 'dashed' }} />

        <MenuItem
          onClick={handleLogout}
          sx={{ m: 1, fontWeight: 'fontWeightBold', color: 'error.main' }}
        >
          Logout
        </MenuItem>
      </CustomPopover>
    </>
  );
}

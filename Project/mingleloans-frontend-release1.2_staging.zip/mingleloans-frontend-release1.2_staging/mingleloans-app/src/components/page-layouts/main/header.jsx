/* eslint-disable import/no-unresolved */
import Box from '@mui/material/Box';
// import Link from '@mui/material/Link';
import Stack from '@mui/material/Stack';
import AppBar from '@mui/material/AppBar';
import Button from '@mui/material/Button';
import Toolbar from '@mui/material/Toolbar';
import { useTheme } from '@mui/material/styles';
import Container from '@mui/material/Container';
// import Badge, { badgeClasses } from '@mui/material/Badge';

import Logo from '@components/page-components/logo';

import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import { useOffSetTop } from 'src/utils/hooks/use-off-set-top';
import { useResponsive } from 'src/utils/hooks/use-responsive';

import { bgBlur } from 'src/theme/css';
// import Label from '@components/mui-components/label';

import { HandshakeRounded } from '@mui/icons-material';

import NavMobile from './nav/mobile';
import NavDesktop from './nav/desktop';
import { HEADER } from '../config-layout';
import { navConfig } from './config-navigation';
import HeaderShadow from '../common/header-shadow';
import LoginButton from '../../page-components/navigations/LoginButton';

// ----------------------------------------------------------------------

export default function Header() {
  const theme = useTheme();

  const mdUp = useResponsive('up', 'md');

  const offsetTop = useOffSetTop(HEADER.H_DESKTOP);

  return (
    <AppBar>
      <Toolbar
        disableGutters
        sx={{
          borderBottom: '6px solid #FBA919',

          height: {
            xs: HEADER.H_MOBILE,
            md: 60,
          },
          transition: theme.transitions.create(['height'], {
            easing: theme.transitions.easing.easeInOut,
            duration: theme.transitions.duration.shorter,
          }),
          ...(offsetTop && {
            ...bgBlur({
              color: theme.palette.background.default,
            }),
            height: {
              xs: HEADER.H_DESKTOP_OFFSET,
            },
          }),
        }}
      >
        <Container
          sx={{
            height: 1,
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {/* <Badge
            sx={{
              [`& .${badgeClasses.badge}`]: {
                top: 8,
                right: -16,
              },
            }}
            badgeContent={
              <Link
                href={DefaultPaths.changelog}
                target="_blank"
                rel="noopener"
                underline="none"
                sx={{ ml: 1 }}
              >
                <Label color="info" sx={{ textTransform: 'unset', height: 22, px: 0.5 }}>
                  v5.7.0
                </Label>
              </Link>
            }
          >
          </Badge> */}
          <Logo />
          <Box sx={{ flexGrow: 1 }} />

          {mdUp && <NavDesktop data={navConfig} />}

          <Stack alignItems="center" direction={{ xs: 'row', md: 'row-reverse' }}>
            <Button
              sx={{
                mx: 1,
                display: 'flex',
                alignItems: 'center',
                gap: { xs: '0.2rem', sm: '0.4rem' },
                // paddingX: { xs: '0', sm: '2rem' },
                width: '100%',
                backgroundColor: '#2E8ACA !important',
                color: '#ffffff', // Set text color to white
                border: '2px solid transparent',
                '&:hover': {
                  backgroundColor: '#2E8ACA', // Keep the same background color on hover
                  borderColor: '#000000', // Set the border color to black on hover
                  color: '#ffffff', // Ensure text color remains white on hover
                },
              }}
              rel="noopener"
              href={DefaultRoutes.auth_url.partnerRegistration}
              variant="outlined"
            >
              <HandshakeRounded />
              Become a Partner
            </Button>

            <LoginButton />

            {!mdUp && <NavMobile data={navConfig} />}
          </Stack>
        </Container>
      </Toolbar>

      {offsetTop && <HeaderShadow />}
    </AppBar>
  );
}

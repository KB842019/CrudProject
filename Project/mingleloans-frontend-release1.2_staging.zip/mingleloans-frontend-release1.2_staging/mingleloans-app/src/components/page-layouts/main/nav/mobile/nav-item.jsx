/* eslint-disable import/no-unresolved */
import PropTypes from 'prop-types';
import { useState, forwardRef } from 'react';
import Iconify from '@components/mui-components/iconify';

import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import { Typography } from '@mui/material';
import { alpha, styled } from '@mui/material/styles';
import ListItemButton from '@mui/material/ListItemButton';

import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import { serviceDropDown } from 'src/assets/data/SiteHomePageFeatures';

// ----------------------------------------------------------------------

export const NavItem = forwardRef(
  ({ title, path, icon, open, active, hasChild, externalLink, onClick, ...other }, ref) => {
    const [showDiv, setShowDiv] = useState(false);

    const handleClick = (event) => {
      if (title === 'Services') {
        event.preventDefault(); // Prevent default link behavior
        // onClick(); // Execute the provided onClick function
        setShowDiv(!showDiv);
      }
    };

    const handleServicesClick = (name) => {
      if (name === 'Personal Loan') {
        window.location.href = DefaultRoutes.public_url.services.personalLoan; // '/personal-loan';
      } else if (name === 'Business Loan') {
        window.location.href = DefaultRoutes.public_url.services.businessLoan; // '/business-loan';
      } else if (name === 'Home Loan') {
        window.location.href = DefaultRoutes.public_url.services.homeLoan; // '/home-loan';
      } else if (name === 'Mortgage Loan') {
        window.location.href = DefaultRoutes.public_url.services.mortgageLoan; // '/mortgage-loan';
      } else if (name === 'Overdraft') {
        window.location.href = DefaultRoutes.public_url.services.overdraft; // '/overdraft';
      } else if (name === 'Balance Transfer') {
        window.location.href = DefaultRoutes.public_url.services.balanceTransfer; // '/balance-transfer';
      } else if (name === 'Expert Services') {
        window.location.href = DefaultRoutes.public_url.services.expertServices; // '/expert-services';
      }
    };
    const renderContent = (
      <StyledNavItem
        ref={ref}
        open={open}
        active={active}
        {...other}
        onClick={title === 'Services' ? handleClick : undefined}
      >
        <Box component="span" sx={{ mr: 2, display: 'inline-flex' }}>
          {icon}
        </Box>

        <Box component="span" sx={{ flexGrow: 1 }}>
          {title}
        </Box>

        {hasChild && (
          <Iconify
            width={16}
            icon={open ? 'eva:arrow-ios-downward-fill' : 'eva:arrow-ios-forward-fill'}
          />
        )}
      </StyledNavItem>
    );

    // if (hasChild) {
    //   return renderContent;
    // }

    if (externalLink)
      return (
        <Link href={path} target="_blank" rel="noopener" color="inherit" underline="none">
          {renderContent}
        </Link>
      );

    return (
      <Box sx={{ position: 'relative' }}>
        <Link
          onClick={renderContent === 'Services' ? handleClick : undefined}
          href={path}
          color="inherit"
          underline="none"
        >
          {renderContent}
        </Link>

        {showDiv && (
          <Box
            sx={{
              top: 40,
              left: -10,
              zIndex: '100000',
              width: '100%',
              background: '#eeeeee',
              paddingY: '1rem',
              boxShadow: 9,
              borderRadius: '10px',
            }}
          >
            {/* Content specific to "Services" */}
            <Box>
              {serviceDropDown?.map((element, index) => (
                <Typography
                  component="p"
                  sx={{
                    padding: '.8rem 1.8rem',
                    cursor: 'pointer',
                    fontSize: '1.1rem',
                    fontWeight: '500',
                    '&:not(:last-of-type)': {
                      borderBottom: '1px solid #cccccc',
                    },
                    '&:hover': {
                      backgroundColor: '#eeeeee !important',
                    },
                  }}
                  onClick={() => handleServicesClick(element?.title)}
                >
                  {element?.title}
                </Typography>
              ))}
            </Box>
          </Box>
        )}
      </Box>
    );
  }
);

NavItem.propTypes = {
  title: PropTypes.string,
  path: PropTypes.string,
  icon: PropTypes.element,
  open: PropTypes.bool,
  active: PropTypes.bool,
  subItem: PropTypes.bool,
  hasChild: PropTypes.bool,
  externalLink: PropTypes.bool,
};

// ----------------------------------------------------------------------

const StyledNavItem = styled(ListItemButton, {
  shouldForwardProp: (prop) => prop !== 'active',
})(({ open, active, theme }) => {
  const opened = open && !active;

  return {
    ...theme.typography.body2,
    color: theme.palette.text.secondary,
    fontWeight: theme.typography.fontWeightMedium,
    height: 48,
    ...(active && {
      color: theme.palette.primary.main,
      fontWeight: theme.typography.fontWeightSemiBold,
      backgroundColor: alpha(theme.palette.primary.main, 0.08),
      '&:hover': {
        backgroundColor: alpha(theme.palette.primary.main, 0.16),
      },
    }),
    ...(opened && {
      backgroundColor: theme.palette.action.hover,
    }),
  };
});

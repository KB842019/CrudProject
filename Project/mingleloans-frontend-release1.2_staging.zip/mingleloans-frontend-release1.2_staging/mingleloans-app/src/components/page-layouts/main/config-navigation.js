import { DefaultRoutes } from 'src/routes/DefaultRoutes';
// import Iconify from '@components/mui-components/iconify';

// ----------------------------------------------------------------------

export const navConfig = [
  {
    title: 'Home',
    icon: '',
    path: DefaultRoutes.public_url.home,
  },
  {
    title: 'About Us',
    icon: '',
    path: DefaultRoutes.public_url.aboutUs,
  },
  {
    title: 'Contact Us',
    icon: '',
    path: DefaultRoutes.public_url.contactUs,
  },
  {
    title: 'Services',
    icon: '',
    path: '',
    children: [
      {
        items: [
          { title: 'Expert Services', path: DefaultRoutes.public_url.services.expertServices },
          { title: 'Personal Loan', path: DefaultRoutes.public_url.services.personalLoan },
          { title: 'Business Loan', path: DefaultRoutes.public_url.services.businessLoan },
          { title: 'Home Loan', path: DefaultRoutes.public_url.services.homeLoan },
          { title: 'Mortgage Loan', path: DefaultRoutes.public_url.services.mortgageLoan },
          { title: 'OverDraft', path: DefaultRoutes.public_url.services.overdraft },
          { title: 'Balance Transfer', path: DefaultRoutes.public_url.services.balanceTransfer },
        ],
      },
    ],
  },
];

import React from 'react';

import { Box, Card, Grid, Typography } from '@mui/material';

import hl from 'src/assets/images/shared/loan-types/hl.svg';
import bl from 'src/assets/images/shared/loan-types/bl.svg';
import pl from 'src/assets/images/shared/loan-types/pl.svg';
import bt from 'src/assets/images/shared/loan-types/bt.svg';
import LoanChipData from 'src/assets/data/dummy-data/LoanChipData.json';
import mortgage from 'src/assets/images/shared/loan-types/mortgage.svg';
import overdraft from 'src/assets/images/shared/loan-types/overdraft.svg';

const LoanCardChip = () => {
  const loanImages = {
    hl,
    mortgage,
    bl,
    pl,
    bt,
    overdraft,
  };

  return (
    <Box
      sx={{
        paddingRight: { xs: '13px', sm: '20px', md: '24px', lg: '24px' },
        paddingLeft: { xs: '3px', sm: '10px', md: '10px', lg: '10px' },
      }}
    >
      <Grid container spacing={1}>
        {LoanChipData.map((loan, index) => {
          const loanImage = loanImages[loan.image.split('.')[0]];

          return (
            <Grid item xs={12} sm={6} md={4} lg={2} key={index}>
              <Card
                sx={{
                  borderRadius: '5px',
                  mb: 2,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
                  width: '100%',
                  height: '40px',
                }}
              >
                <Box
                  sx={{
                    width: '20px',
                    flex: 1,
                    backgroundColor: '#DAEBFE',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: '100%',
                  }}
                >
                  <img
                    src={loanImage}
                    alt={`${loan.loanType} loan`}
                    style={{
                      width: '20px',
                      height: '20px',
                      objectFit: 'contain',
                    }}
                  />
                </Box>

                <Box
                  sx={{
                    flex: 2,
                    display: 'flex',
                    alignItems: 'center',
                    paddingLeft: '5px',
                    height: '100%',
                    whiteSpace: 'nowrap',
                  }}
                >
                  <Typography
                    sx={{
                      fontWeight: 'bold',
                      textAlign: 'left',
                      fontSize: { xs: '14px', sm: '13px', md: '12px' },
                    }}
                  >
                    {loan.title}
                  </Typography>
                </Box>

                <Box
                  sx={{
                    flex: 1,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: '100%',
                  }}
                >
                  <Typography
                    sx={{
                      backgroundColor: '#63A3FA',
                      width: '30px',
                      height: '30px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: '50%',
                      fontWeight: 'bold',
                      color: 'white',
                      fontSize: { xs: '12px', sm: '11px', md: '10px' },
                    }}
                  >
                    {loan.value}
                  </Typography>
                </Box>
              </Card>
            </Grid>
          );
        })}
      </Grid>
    </Box>
  );
};

export default LoanCardChip;

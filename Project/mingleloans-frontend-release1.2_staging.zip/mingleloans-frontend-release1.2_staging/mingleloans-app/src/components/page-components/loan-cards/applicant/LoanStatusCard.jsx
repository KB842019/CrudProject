import React from 'react';

import { Box, Grid, Typography } from '@mui/material';

import draftIcon from 'src/assets/icons/statusIcons/draftIcon.svg';
import reviewIcon from 'src/assets/icons/statusIcons/reviewIcon.svg';
import pendingIcon from 'src/assets/icons/statusIcons/pendingIcon.svg';
import processIcon from 'src/assets/icons/statusIcons/processIcon.svg';
import approvedIcon from 'src/assets/icons/statusIcons/approvedIcon.svg';
import rejectedIcon from 'src/assets/icons/statusIcons/rejectedIcon.svg';
import LoanStatusData from 'src/assets/data/dummy-data/LoanStatusData.json';

const LoanStatusCard = () => {
  const iconMap = {
    draftIcon,
    reviewIcon,
    pendingIcon,
    processIcon,
    approvedIcon,
    rejectedIcon,
  };

  const statuses = LoanStatusData.map((status) => ({
    ...status,
    icon: iconMap[status.icon.split('.')[0]],
  }));

  const sortedStatuses = [...statuses].sort((a, b) => a.order - b.order);

  return (
    <Box
      sx={{
        paddingRight: { xs: '13px', sm: '23px', md: '24px', lg: '25px' },
        paddingLeft: { xs: '5px', sm: '10px', md: '10px', lg: '9px' },
      }}
    >
      <Grid container spacing={1}>
        {sortedStatuses.map((status, index) => (
          <Grid key={index} item xs={12} sm={6} md={4} lg={2}>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                borderRadius: '5px',
                p: 1,
                boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1), 0px -2px 4px rgba(0, 0, 0, 0.05)',
              }}
            >
              <Box>
                <Typography fontSize="20px" fontWeight="bold">
                  {status.count}
                </Typography>
                <Typography fontSize="14px" fontWeight="bold" color="textSecondary">
                  {status.label}
                </Typography>
              </Box>
              <Box
                component="img"
                src={status.icon}
                alt={`${status.label} icon`}
                sx={{ width: 32, height: 32 }}
              />
            </Box>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default LoanStatusCard;

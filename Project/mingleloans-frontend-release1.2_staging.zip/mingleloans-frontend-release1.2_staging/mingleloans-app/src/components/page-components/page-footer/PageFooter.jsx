/* eslint-disable import/no-unresolved */
import { useState } from 'react';
import { Link } from 'react-router-dom';

import { Box } from '@mui/material';
import Stack from '@mui/material/Stack';
import Dialog from '@mui/material/Dialog';
import { alpha } from '@mui/material/styles';
import Container from '@mui/material/Container';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';

import { RouterLink } from 'src/routes/components';
import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import { _socials } from 'src/_mock';
import { PrivacyPolicyData } from 'src/assets/privacy-and-policy/PrivacyPolicyData';
import { TermsAndConditionsData } from 'src/assets/terms-and-condition/TermsAndConditionsData';

import Iconify from 'src/components/iconify';
import FooterLogo from 'src/components/logo/FooterLogo';

// ----------------------------------------------------------------------

export default function PageFooter() {
  const date = new Date();
  const [openTerms, setOpenTerms] = useState(false);
  const [openPrivacyPolicy, setOpenPrivacyPolicy] = useState(false);

  const handleCardClick = (name) => {
    if (name === 'About Us') {
      window.location.href = '/about-us';
    } else if (name === 'Contact Us') {
      window.location.href = '/contact-us';
    } else if (name === 'Expert Services') {
      window.location.href = '/expert-services';
    }
  };

  const handleOpenTerms = () => {
    setOpenTerms(true);
  };

  const handleCloseTerms = () => {
    setOpenTerms(false);
  };

  const handleOpenPrivacyPolicy = () => {
    setOpenPrivacyPolicy(true);
  };

  const handleClosePrivacyPolicy = () => {
    setOpenPrivacyPolicy(false);
  };

  const LINKS = [
    {
      headline: 'MingleLoans',
      children: [
        { name: 'About Us', href: DefaultRoutes.public_url.aboutUs },
        { name: 'Contact Us', href: DefaultRoutes.public_url.contactUs },
        { name: 'Blogs', href: DefaultRoutes.public_url.contactUs },
        { name: 'Expert Services', href: DefaultRoutes.public_url.services.expertServices },
        // { name: 'FAQs', href: DefaultPaths.faqs },
      ],
    },
    {
      headline: 'Legal',
      children: [
        { name: 'Terms and Conditions', onClick: handleOpenTerms },
        { name: 'Privacy Policy', onClick: handleOpenPrivacyPolicy },
      ],
    },
    {
      headline: 'Contact',
      children: [
        {
          name: 'MINGLELOANS, 264, Udyog Vihar Phase 1, Udyog Vihar, Sector 20, Gurugram,',
        },
        {
          name: ' Pin 122016',
        },
        { name: 'www.mingleloans.com', href: '#' },
        { name: 'info@mingleloans.com', href: '#' },
        { name: 'support@mingleloans.com', href: '#' },
      ],
    },
  ];

  const mainFooter = (
    <Box
      component="footer"
      sx={{
        position: 'relative',
        backgroundColor: '#333333',
        // mt: 2,
        pb: 2,
      }}
    >
      {/* <Divider /> */}

      <Container
        sx={{
          pt: 0,
          textAlign: { xs: 'center', md: 'unset' },
        }}
      >
        <Box
          sx={{
            display: 'flex',
            flexDirection: { xs: 'column', md: 'row' },
            alignItems: 'center',
            gap: { xs: '2rem', md: '4rem' },
          }}
        >
          <Box
            sx={{
              textAlign: 'center',
            }}
          >
            <FooterLogo sx={{ mb: 0 }} />
            <Typography
              variant="body2"
              sx={{
                maxWidth: 500,
                mx: { xs: 'auto', md: 'unset' },
                color: '#ffffff',
                textAlign: 'justify',
              }}
            >
              At MingleLoans, we’re always happy to help you reduce your debt and achieve your
              financial goals. As one of the top loan providers in India, we’ve been assisting
              clients for over 20 years in obtaining instant loans. Our expertise allows us to make
              loan provision efficient and seamless.
            </Typography>

            <Stack
              direction="row"
              gap={1}
              justifyContent={{ xs: 'center', md: 'center' }}
              sx={{
                mt: 3,
                mb: { xs: 5, md: 0 },
              }}
            >
              {_socials.map((social) => (
                <IconButton
                  key={social.name}
                  sx={{
                    backgroundColor: '#ffffff',
                    '&:hover': {
                      bgcolor: alpha(social.color, 0.08),
                    },
                  }}
                >
                  <Iconify color={social.color} icon={social.icon} />
                </IconButton>
              ))}
            </Stack>
          </Box>

          <Box>
            <Stack
              spacing={1}
              sx={{
                flexDirection: 'row',
                flexWrap: { xs: 'wrap', md: 'nowrap' },
                gap: '2.5rem',
                paddingX: '2rem',
                marginTop: { xs: '0rem', md: '2rem' },
              }}
            >
              {LINKS.map((list) => (
                <Stack
                  key={list.headline}
                  spacing={1}
                  sx={{
                    textAlign: 'left',
                    width: { xs: 'calc(50% - 2rem)', sm: 'calc(33% - 2rem)', md: '100%' },
                    color: '#ffffff',
                  }}
                >
                  <Typography component="div" variant="overline" sx={{ fontSize: '1.2rem' }}>
                    {list.headline}
                  </Typography>

                  {list.children.map((link, index) => (
                    <Link
                      key={index}
                      component={link.onClick ? 'button' : RouterLink}
                      href={link.onClick ? '#' : link.href}
                      color="black"
                      variant="body2"
                      // onClick={link.onClick}
                      style={{ textDecoration: 'none', color: '#ffffff', fontWeight: 'bold' }}
                      onClick={() => handleCardClick(link?.name)}
                    >
                      {link.name}
                    </Link>
                  ))}
                </Stack>
              ))}
            </Stack>
          </Box>
        </Box>

        <Typography variant="body2" sx={{ mt: 4, textAlign: 'center', color: '#ffffff' }}>
          © {date.getFullYear()}. All rights reserved
        </Typography>
      </Container>

      {/* Terms and Conditions Dialog */}
      <Dialog open={openTerms} onClose={handleCloseTerms} fullWidth maxWidth="md">
        <DialogTitle>Terms and Conditions</DialogTitle>
        <DialogContent dividers>
          <DialogContentText>
            {TermsAndConditionsData.map((item, index) => (
              <Typography key={index} variant="body1" gutterBottom>
                <strong>{item.title}</strong>: {item.content}
              </Typography>
            ))}
          </DialogContentText>
        </DialogContent>
      </Dialog>

      {/* Privacy Policy Dialog */}
      <Dialog open={openPrivacyPolicy} onClose={handleClosePrivacyPolicy} fullWidth maxWidth="md">
        <DialogTitle>Privacy Policy</DialogTitle>
        <DialogContent dividers>
          <DialogContentText>
            {PrivacyPolicyData.map((item, index) => (
              <Typography key={index} variant="body1" gutterBottom>
                <strong>{item.title}</strong>: {item.content}
              </Typography>
            ))}
          </DialogContentText>
        </DialogContent>
      </Dialog>
    </Box>
  );

  return mainFooter;
}

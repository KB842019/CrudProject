import { usePathname } from 'src/routes/hooks';

import MainLayout from 'src/components/page-layouts/main';
// import CompactLayout from 'src/layouts/compact';

import ComingSoonView from 'src/components/page-components/coming-soon/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Coming Soon',
};

export default function ComingSoonPage() {
  const pathname = usePathname();
  if (pathname.includes('applicant')) return <ComingSoonView />;
  return (
    <MainLayout>
      <ComingSoonView />
    </MainLayout>
  );
}

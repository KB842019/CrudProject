import ComingSoonView from 'src/components/page-components/coming-soon/view';

// ----------------------------------------------------------------------

export const metadata = {
  title: 'Coming Soon',
};

export default function ComingSoonSmall() {
  return <ComingSoonView />;
}

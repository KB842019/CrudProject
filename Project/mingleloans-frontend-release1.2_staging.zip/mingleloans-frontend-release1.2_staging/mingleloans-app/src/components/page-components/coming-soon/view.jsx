import PropTypes from 'prop-types';
import { ComingSoonIllustration } from '@assets/illustrations';

import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

// ----------------------------------------------------------------------

export default function ComingSoonView() {
  return (
    <>
      <Typography variant="h3" sx={{ mb: 2, textAlign: 'center' }}>
        Coming Soon!
      </Typography>

      <Typography sx={{ color: 'text.secondary', textAlign: 'center' }}>
        We are currently working hard on this page!
      </Typography>

      <ComingSoonIllustration sx={{ my: 10, height: 240 }} />
    </>
  );
}

// ----------------------------------------------------------------------

function TimeBlock({ label, value }) {
  return (
    <div>
      <Box> {value} </Box>
      <Box sx={{ color: 'text.secondary', typography: 'body1' }}>{label}</Box>
    </div>
  );
}

TimeBlock.propTypes = {
  label: PropTypes.string,
  value: PropTypes.string,
};

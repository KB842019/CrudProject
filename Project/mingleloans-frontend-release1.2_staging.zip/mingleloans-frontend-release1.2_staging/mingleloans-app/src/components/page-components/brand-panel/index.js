export { default as BrandPanel } from 'src/components/page-components/brand-panel/BrandPanel';
export { default as ApplicantBrandPanel } from 'src/components/page-components/brand-panel/ApplicantBrandPanel';

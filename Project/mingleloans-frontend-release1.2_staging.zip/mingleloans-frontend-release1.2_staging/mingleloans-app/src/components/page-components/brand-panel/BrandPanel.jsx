/* eslint-disable import/no-unresolved */
import React from 'react';
import MinimizeLogo from '@components/page-components/logo/favicon1.svg';

import { Settings } from '@mui/icons-material';
import { Box, Grid, Tooltip, Typography } from '@mui/material';

import useBrandStore from 'src/store/brandpanel-store/useBrandStore';

const BrandPanel = () => {
  const { companyName, version, tagline } = useBrandStore();

  // Extract the first word of the company name
  const firstWord = companyName.split(' ')[0];

  return (
    <Grid
      container
      sx={{
        boxShadow: '0 -2px 6px rgba(0, 0, 0, 0.2)',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '5px 10px',
        backgroundColor: '#FAF8FD',
        position: 'relative',
      }}
    >
      <Box
        sx={{
          position: 'absolute',
          top: '0px',
          right: '5px',
        }}
      >
        <Settings sx={{ fontSize: '24px', color: '#6b7280', cursor: 'pointer' }} />
      </Box>

      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <img
          alt="Profile"
          src={MinimizeLogo}
          style={{
            height: '38px',
            width: '38px',
            borderRadius: '50%',
            boxShadow: '0px 0px 10px 2px white',
          }}
        />

        <Box
          sx={{
            marginLeft: '10px',
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'center',
          }}
        >
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
            }}
          >
            <Tooltip title={companyName} arrow>
              <Typography
                sx={{
                  fontWeight: 300,
                  fontSize: 'clamp(10px, 2vw, 14px)',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                  maxWidth: '200px',
                  cursor: 'pointer',
                }}
              >
                {firstWord} {/* Display only the first word */}
              </Typography>
            </Tooltip>
            <Box
              sx={{
                backgroundColor: 'rgb(119, 138, 237)',
                textAlign: 'center',
                // fontWeight: 'bold',
                fontSize: '10px',
                padding: '3px 3px',
                fontFamily: 'monospace',
                borderRadius: '5px',
                color: 'white',
              }}
            >
              ver {version}
            </Box>
          </Box>

          <Typography
            variant="body2"
            sx={{
              color: '#6b7280',
              fontSize: '12px',
              marginTop: '4px',
              lineHeight: 1,
            }}
          >
            {tagline}
          </Typography>
        </Box>
      </Box>
    </Grid>
  );
};

export default BrandPanel;

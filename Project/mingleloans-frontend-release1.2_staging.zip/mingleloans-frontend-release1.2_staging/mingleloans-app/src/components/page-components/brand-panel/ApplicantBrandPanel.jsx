import React from 'react';

import { Settings } from '@mui/icons-material';
import { Box, Grid, Typography } from '@mui/material';

import { useAuthContext } from 'src/middleware/auth/hooks';
import userImage from 'src/assets/images/shared/userImage.png';

const ApplicantBrandPanel = () => {
  const { user } = useAuthContext();

  return (
    <Grid
      container
      sx={{
        boxShadow: '0 -2px 6px rgba(0, 0, 0, 0.2)',
        alignItems: 'center',
        padding: '5px 8px',
        backgroundColor: '#FAF8FD',
      }}
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
          marginRight: '10px',
        }}
      >
        <img
          alt="Profile"
          src={userImage}
          style={{
            // {xs:'40px',sm:'33px',md:'33px',lg:'33px'},
            height: '28px',
            width: '28px',
            borderRadius: '50%',
            boxShadow: '0px 0px 10px 2px white',
          }}
        />
      </Box>

      <Grid
        sx={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          flex: 1,
          marginBottom: { xs: '8px', sm: '4px', md: '4px', lg: '4px' },
          position: 'relative',
          right: { xs: '8px', sm: '2px', md: '2px', lg: '2px' },
        }}
      >
        <Typography
          sx={{
            fontWeight: 500,
            fontSize: '12px',
            color: '#000',
            textAlign: 'left',
          }}
        >
          {`${user?.firstName} ${user?.lastName}`}
        </Typography>
        <Typography
          sx={{
            cursor: 'pointer',
            color: '#6b7280',
            fontSize: '11px',
            lineHeight: { xs: '0px', sm: '10px', md: '10px' },
            textAlign: 'left',
          }}
        >
          {user?.emailId}
        </Typography>
      </Grid>

      <Box>
        <Settings
          sx={{
            fontSize: '20px',
            color: '#6b7280',
            cursor: 'pointer',
          }}
        />
      </Box>
    </Grid>
  );
};

export default ApplicantBrandPanel;

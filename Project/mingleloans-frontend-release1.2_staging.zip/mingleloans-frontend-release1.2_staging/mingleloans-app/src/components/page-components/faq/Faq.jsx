/* eslint-disable import/no-extraneous-dependencies */
import React from 'react';
import ReadMoreArrow from '@images/shared/faqIcon.png';

import {
  Box,
  Container,
  Accordion,
  Typography,
  AccordionSummary,
  AccordionDetails,
} from '@mui/material';

const Faq = ({ data }) => {
  const [expanded, setExpanded] = React.useState(false);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };
  return (
    <Container>
      <Box
        sx={{
          marginX: 'auto',
          paddingX: '1rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Typography
          sx={{
            color: '#FFDE4D',
            backgroundColor: '#025464',
            paddingX: '2.4rem',
            paddingY: '1rem',
            borderBottomLeftRadius: '1.8rem',
            borderBottomRightRadius: '1.8rem',
            boxShadow: 3,
          }}
          variant="h4"
        >
          Frequently Asked Questions
        </Typography>
      </Box>

      <Box sx={{ maxWidth: '986px', marginX: 'auto', paddingTop: '2.5rem' }}>
        {data?.map((element, index) => (
          <Accordion
            key={index}
            sx={{
              backgroundColor: 'transparent !important',
              boxShadow: 'none !important',
              marginTop: '0.8rem',
              borderRadius: '2.5rem 2.5rem 1rem 1rem !important',
            }}
            expanded={expanded === `${element?.question}`}
            onChange={handleChange(`${element?.question}`)}
          >
            <AccordionSummary
              sx={{
                color: '#ffffff',
                backgroundColor: '#025464',
                padding: '0rem 0.8rem 0rem 1.5rem',
                margin: '0rem !important',
                borderRadius: '2.5rem !important',
                border: '2px solid #ffffff',
              }}
              aria-controls="panel1bh-content"
              id="panel1bh-header"
            >
              <Typography sx={{ fontSize: '1.2rem' }}>{element?.question}</Typography>
              <Typography
                component="img"
                sx={{
                  width: '40px',
                  rotate: expanded === `${element?.question}` ? '180deg' : '0deg',
                }}
                src={ReadMoreArrow}
              />
            </AccordionSummary>
            <AccordionDetails
              sx={{
                padding: '6px 1rem 0px !important',
                maxHeight: expanded === `${element?.question}` ? '1000px' : '0px', // Change maxHeight for transition
                overflow: 'hidden', // Hide content when collapsed
                transition: 'max-height 2s ease-in-out', // Smooth transition on height
              }}
            >
              <Typography
                sx={{
                  backgroundColor: '#ffffff',
                  color: '#000000',
                  padding: { xs: '0.4rem 1rem', sm: '1rem 1rem' },
                  borderRadius: '1.2rem',
                }}
              >
                {element?.answer}
              </Typography>
            </AccordionDetails>
          </Accordion>
        ))}
      </Box>
    </Container>
  );
};

export default Faq;

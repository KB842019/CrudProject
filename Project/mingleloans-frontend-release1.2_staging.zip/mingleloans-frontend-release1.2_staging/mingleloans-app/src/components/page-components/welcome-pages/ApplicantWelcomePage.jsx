import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import {
  Box,
  Grid,
  Card,
  Button,
  Container,
  Typography,
  CardActions,
  CardContent,
} from '@mui/material';

import { ModuleRoutes } from 'src/routes/ModuleRoutes';

import useAuthStore from 'src/store/auth-store/useAuthStore';
import supportImage from 'src/assets/images/shared/supportImage.png';
import ApplicantWelcomePageCardContent from 'src/assets/data/dummy-data/ApplicantWelcomeData.json';

import NonMenuNavBar from 'src/components/page-components/navigations/NonMenuNavBar';

const ApplicantWelcomePage = () => {
  const [expandedCard, setExpandedCard] = useState(null);
  const { user } = useAuthStore.getState();
  const navigate = useNavigate();

  const handleDashboardNavigation = () => {
    navigate(ModuleRoutes.shared.dashboard);
  };

  const toggleExpand = (index) => {
    setExpandedCard((prev) => (prev === index ? null : index));
  };

  return (
    <>
      <NonMenuNavBar />
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          backgroundColor: '#f5f5f5',
          minHeight: '100vh',
          overflow: 'hidden',
        }}
      >
        <Box sx={{ flexGrow: 1, py: 5, px: 2 }}>
          <Container>
            <Grid container justifyContent="center" alignItems="center">
              <Grid item xs={12} md={6} px={2} marginTop={{ xs: 4, sm: 5, md: 5, lg: 2 }}>
                <Typography
                  variant="h4"
                  fontWeight="bold"
                  color="primary"
                  gutterBottom
                  textAlign={{ xs: 'center', md: 'left', lg: 'left' }}
                  ml={{ xs: 2, md: 0, lg: 0 }}
                >
                  Hi {user.firstName.charAt(0).toUpperCase() + user.firstName.slice(1)}, Welcome 🎉
                </Typography>
                <Typography
                  variant="body1"
                  color="textSecondary"
                  gutterBottom
                  textAlign={{ xs: 'center', md: 'left', lg: 'left' }}
                  ml={{ xs: 2, md: 0, lg: 0 }}
                >
                  Your account has been successfully created. We&apos;re excited to have you on
                  board!
                </Typography>
                <Box
                  sx={{
                    mt: 4,
                    display: 'flex',
                    justifyContent: { xs: 'center', md: 'flex-start', lg: 'flex-start' },
                    gap: 2,
                    flexWrap: 'wrap',
                  }}
                >
                  <Button
                    variant="contained"
                    color="primary"
                    sx={{ borderRadius: '5px' }}
                    onClick={handleDashboardNavigation}
                  >
                    Take Me to My Dashboard
                  </Button>
                  <Button variant="outlined" color="primary" sx={{ borderRadius: '5px' }}>
                    Explore Our Services
                  </Button>
                </Box>
              </Grid>

              <Grid item xs={12} md={6} mt={5}>
                <Card
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    padding: 2,
                    backgroundColor: '#ffffff',
                    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                    borderRadius: '10px',
                    justifyContent: { xs: 'center', md: 'flex-start' },
                    flexDirection: { xs: 'column', md: 'row' },
                    gap: { xs: 2, md: 3 },
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      flexBasis: '40%',
                    }}
                  >
                    <img
                      src={supportImage}
                      alt="Card Illustration"
                      style={{ width: '180px', maxWidth: '200px' }}
                    />
                  </Box>
                  <Box sx={{ textAlign: { xs: 'center', md: 'left' }, flexBasis: '60%' }}>
                    <Typography variant="h6" fontWeight="bold" color="primary" gutterBottom>
                      Our Offerings
                    </Typography>
                    <Typography variant="body1" color="textSecondary" sx={{ mt: 1 }}>
                      At MingleLoans, we are committed to providing you with the most reliable and
                      efficient loan solutions. Our offerings are designed to cater to your unique
                      financial needs, ensuring you have access to the best loan options with the
                      highest level of support.
                    </Typography>
                  </Box>
                </Card>
              </Grid>
            </Grid>
          </Container>
        </Box>

        <Box sx={{ py: 4, backgroundColor: '#e9f5ff', pr: { xs: 2, sm: 4, md: 4, lg: 4 } }}>
          <Container sx={{ mt: 1 }}>
            <Typography color="primary" variant="h6" textAlign="center" gutterBottom>
              You may also be interested in knowing before proceeding
            </Typography>
            <Grid container spacing={2} justifyContent="center" sx={{ mt: 3 }}>
              {ApplicantWelcomePageCardContent.map((item, index) => (
                <Grid item xs={12} sm={6} md={6} lg={3} key={index}>
                  <Card
                    sx={{
                      height: '100%',
                      margin: '0 auto',
                      maxWidth: '100%',
                      textAlign: 'left',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
                      borderRadius: '10px',
                    }}
                  >
                    <CardContent>
                      <Typography gutterBottom variant="h5" component="div">
                        {item.title}
                      </Typography>
                      <Typography
                        variant="body2"
                        sx={{
                          color: 'text.secondary',
                          display: '-webkit-box',
                          WebkitBoxOrient: 'vertical',
                          overflow: 'hidden',
                          WebkitLineClamp: expandedCard === index ? 'unset' : 4,
                        }}
                      >
                        {item.description}
                      </Typography>
                    </CardContent>
                    <CardActions sx={{ justifyContent: 'flex-start', pl: 2 }}>
                      <Button
                        size="small"
                        sx={{ px: 2 }}
                        color="primary"
                        variant="outlined"
                        onClick={() => toggleExpand(index)}
                      >
                        {expandedCard === index ? 'Read Less' : 'Read More'}
                      </Button>
                    </CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Container>
        </Box>
      </Box>
    </>
  );
};

export default ApplicantWelcomePage;

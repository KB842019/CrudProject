import React from 'react';

import rules from 'src/assets/data/password-rules.json';

const ruleItems = (
  <ul className="text-xs text-gray-600 list-disc ml-6">
    {rules.do.map((item, index) => {
      if (typeof item === 'string') {
        return (
          <li key={index} className="mx-2">
            {item}
          </li>
        );
      }
      return (
        <li key={index} className="mx-2">
          {item.instruction}
          <ul className="list-disc mx-5">
            {item.details.map((detail, detailIndex) => (
              <li key={detailIndex}>{detail}</li>
            ))}
          </ul>
        </li>
      );
    })}
  </ul>
);

const PasswordRules = () => (
  <div className="lg:w-3/4 md:w-1/2 sm:w-full">
    <div className="bg-yellow-50 p-3 rounded-lg shadow-lg w-full mx-auto">
      <div className="flex items-center mb-2">
        <h2 className="text-xl font-bold text-gray-700">{rules.title}</h2>
      </div>
      <div className="w-full ml-2">
        <p className="font-semibold mb-1 text-green-700 underline">Do:</p>
        {ruleItems}
      </div>
      <div className="mt-2 space-x-2 ml-2">
        <p className="text-red-700 font-semibold mb-1 underline">Don’t:</p>
        <ul className="text-xs text-gray-600 list-disc list-inside">
          {rules.dont.map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  </div>
);

export default PasswordRules;

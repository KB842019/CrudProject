import PropTypes from 'prop-types';

import Button from '@mui/material/Button';
import { Person as PersonIcon } from '@mui/icons-material';

import { RouterLink } from 'src/routes/components';
import { ModuleRoutes } from 'src/routes/ModuleRoutes';
import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import SessionHandler from 'src/middleware/auth/handler/sessionHandler';

// ----------------------------------------------------------------------

export default function LoginButton({ sx }) {
  const isValidSession = SessionHandler.isValidSession();

  const redirectUrl = isValidSession ? ModuleRoutes.shared.dashboard : DefaultRoutes.auth_url.login;

  return (
    <Button
      component={RouterLink}
      href={redirectUrl}
      variant="outlined"
      sx={{
        mx: 1,
        // width: '50%',
        display: 'flex',
        alignItems: 'center',
        gap: { xs: '0.2rem', sm: '0.4rem' },
        paddingX: { xs: '0', sm: '2rem' },
        ...sx,
      }}
    >
      {isValidSession ? '' : <PersonIcon />} {isValidSession ? 'Dashboard' : 'Login'}
    </Button>
  );
}

LoginButton.propTypes = {
  sx: PropTypes.object,
};

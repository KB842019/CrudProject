import { useState } from 'react';
import PropTypes from 'prop-types';
import { useTheme } from '@emotion/react';

import { Search, Fullscreen } from '@mui/icons-material';
import { Stack, AppBar, Button, Toolbar, Typography, IconButton } from '@mui/material';

import { usePathname } from 'src/routes/hooks';

import { useOffSetTop } from 'src/utils/hooks/use-off-set-top';
import { useResponsive } from 'src/utils/hooks/use-responsive';

import { bgBlur } from 'src/theme/css';
import loanApplicationIcon from 'src/assets/icons/loanApplicationIcon.svg';

import SvgColor from 'src/components/mui-components/svg-color';
import { NAV, HEADER } from 'src/components/page-layouts/config-layout';
import { useSettingsContext } from 'src/components/mui-components/settings';
import AccountPopover from 'src/components/page-layouts/common/account-popover';
import NotificationsPopover from 'src/components/page-layouts/common/notifications-popover';

// ----------------------------------------------------------------------

export default function HeaderToolbar({ onOpenNav }) {
  const theme = useTheme();

  const settings = useSettingsContext();

  const isNavHorizontal = settings.themeLayout === 'horizontal';

  const isNavMini = settings.themeLayout === 'mini';

  const lgUp = useResponsive('up', 'lg');

  const offset = useOffSetTop(HEADER.H_DESKTOP);

  const offsetTop = offset && !isNavHorizontal;

  const [isFullscreen, setIsFullscreen] = useState(false);
  const pathname = usePathname();
  const baseTab = pathname?.split('/')?.slice(-1)[0];
  const displayName = baseTab.replace('apply-', '').split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');


  // Function to toggle fullscreen mode
  const handleFullscreenToggle = () => {
    if (!isFullscreen) {
      const requestFullscreen =
        document.documentElement.requestFullscreen ||
        document.documentElement.webkitRequestFullscreen ||
        document.documentElement.mozRequestFullScreen ||
        document.documentElement.msRequestFullscreen;

      if (requestFullscreen) {
        requestFullscreen.call(document.documentElement);
        setIsFullscreen(true);
      }
    } else {
      const exitFullscreen =
        document.exitFullscreen ||
        document.webkitExitFullscreen ||
        document.mozCancelFullScreen ||
        document.msExitFullscreen;

      if (exitFullscreen) {
        exitFullscreen.call(document);
        setIsFullscreen(false);
      }
    }
  };

  const headerCaptionTypography = (
    <Typography
      variant="h6"
      sx={{ marginLeft: '10px', flexGrow: 1, display: 'flex', alignItems: 'center', gap: 1 }}
    >
      <span>
        <img src={loanApplicationIcon} alt={displayName} style={{ height: '1.8rem' }} />
      </span>
      {displayName}
    </Typography>
  );

  return (
    <AppBar
      sx={{
        height: HEADER.H_MOBILE,
        zIndex: theme.zIndex.appBar + 1,
        ...bgBlur({
          color: theme.palette.background.default,
        }),
        transition: theme.transitions.create(['height'], {
          duration: theme.transitions.duration.shorter,
        }),
        ...(lgUp && {
          width: `calc(100% - ${NAV.W_VERTICAL + 1}px)`,
          height: HEADER.H_DESKTOP,
          ...(offsetTop && {
            height: HEADER.H_DESKTOP_OFFSET,
          }),
          ...(isNavHorizontal && {
            width: 1,
            bgcolor: 'background.default',
            height: HEADER.H_DESKTOP_OFFSET,
            borderBottom: `dashed 1px ${theme.palette.divider}`,
          }),
          ...(isNavMini && {
            width: `calc(100% - ${NAV.W_MINI + 1}px)`,
          }),
        }),
      }}
    >
      <Toolbar sx={{ boxShadow: '3px 0 8px -2px grey' }}>
        <Button
          onClick={onOpenNav}
          sx={{
            display: { xs: 'block', lg: 'none' },
            position: 'relative',
            left: '-20px',
          }}
        >
          <SvgColor src="/assets/icons/navbar/ic_menu_item.svg" />
        </Button>
        {headerCaptionTypography}
        <Stack
          flexGrow={1}
          direction="row"
          alignItems="center"
          justifyContent="flex-end"
          spacing={{ xs: 0.5, sm: 1 }}
        >
          <IconButton>
            <Search color="primary" />
          </IconButton>

          <IconButton onClick={handleFullscreenToggle}>
            <Fullscreen color="primary" />
          </IconButton>
          <NotificationsPopover />
          <AccountPopover />
        </Stack>
      </Toolbar>
    </AppBar>
  );
}

HeaderToolbar.propTypes = {
  onOpenNav: PropTypes.func,
};

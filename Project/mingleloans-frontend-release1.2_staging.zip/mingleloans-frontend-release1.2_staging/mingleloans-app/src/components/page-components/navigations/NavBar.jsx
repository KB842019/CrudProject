import React from 'react';
import Logo from '@components/page-components/logo';

import Toolbar from '@mui/material/Toolbar';
import { useTheme } from '@mui/material/styles';
import { Box, Stack, Button, AppBar, Container } from '@mui/material';
import { HandshakeRounded as HandshakeIcon } from '@mui/icons-material';

import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import { useResponsive } from 'src/utils/hooks/use-responsive';
import { useOffSetTop } from 'src/utils/hooks/use-off-set-top';

import { bgBlur } from 'src/theme/css';
import SessionHandler from 'src/middleware/auth/handler/sessionHandler';

import { HEADER } from 'src/components/page-layouts/config-layout';
import NavMobile from 'src/components/page-layouts/main/nav/mobile';
// eslint-disable-next-line import/no-unresolved
import NavDesktop from 'src/components/page-layouts/main/nav/desktop';
import HeaderShadow from 'src/components/page-layouts/common/header-shadow';
import { navConfig } from 'src/components/page-layouts/main/config-navigation';
import LoginButton from 'src/components/page-components/navigations/LoginButton';

const NavBar = () => {
  const theme = useTheme();

  const mdUp = useResponsive('up', 'md');
  const offsetTop = useOffSetTop(HEADER.H_DESKTOP);

  const isValidSession = SessionHandler.isValidSession();

  // Become a partner Button
  const partnerRegistrationButton = (
    <Button
      sx={{
        // mx: 1,
        display: 'flex',
        fontSize: '0.8rem',
        alignItems: 'center',
        gap: { xs: '0.2rem', sm: '0.4rem' },
        paddingX: { xs: '1rem', sm: '2rem' },
        width: '100%',
        textWrap: 'nowrap',
        backgroundColor: '#2E8ACA !important',
        color: '#ffffff', // Set text color to white
        border: '2px solid transparent',
        '&:hover': {
          backgroundColor: '#2E8ACA', // Keep the same background color on hover
          borderColor: '#000000', // Set the border color to black on hover
          color: '#ffffff', // Ensure text color remains white on hover
        },
      }}
      rel="noopener"
      href={DefaultRoutes.auth_url.partnerRegistration}
      variant="outlined"
    >
      <HandshakeIcon />
      Become a Partner
    </Button>
  );

  return (
    <AppBar>
      <Toolbar
        disableGutters
        sx={{
          // borderBottom: '6px solid #FBA919',

          backgroundColor: '#FFFFFF',
          height: {
            xs: HEADER.H_MOBILE,
            md: 60,
          },
          transition: theme.transitions.create(['height'], {
            easing: theme.transitions.easing.easeInOut,
            duration: theme.transitions.duration.shorter,
          }),
          ...(offsetTop && {
            ...bgBlur({
              color: theme.palette.background.default,
            }),
            height: {
              xs: HEADER.H_DESKTOP_OFFSET,
            },
          }),
        }}
      >
        <Container
          sx={{
            height: 1,
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <Logo />
          <Box sx={{ flexGrow: 1 }} />

          {mdUp && <NavDesktop data={navConfig} />}

          <Stack alignItems="center" direction={{ xs: 'row', md: 'row-reverse' }}>
            {isValidSession === false && partnerRegistrationButton}

            <LoginButton />

            {!mdUp && <NavMobile data={navConfig} />}
          </Stack>
        </Container>
      </Toolbar>

      {offsetTop && <HeaderShadow />}
    </AppBar>
  );
};

export default NavBar;

import React from 'react';
import Logo from '@components/page-components/logo';

import Toolbar from '@mui/material/Toolbar';
import { useTheme } from '@mui/material/styles';
import { Box, Stack, AppBar, Container } from '@mui/material';

import { useOffSetTop } from 'src/utils/hooks/use-off-set-top';

import { bgBlur } from 'src/theme/css';

import { HEADER } from 'src/components/page-layouts/config-layout';
import HeaderShadow from 'src/components/page-layouts/common/header-shadow';
import LogoutButton from 'src/components/page-layouts/common/logout-button';

const NonMenuNavBar = () => {
  const theme = useTheme();

  const offsetTop = useOffSetTop(HEADER.H_DESKTOP);

  return (
    <AppBar>
      <Toolbar
        disableGutters
        sx={{
          backgroundColor: '#FFFFFF',
          height: {
            xs: HEADER.H_MOBILE,
            md: 60,
          },
          transition: theme.transitions.create(['height'], {
            easing: theme.transitions.easing.easeInOut,
            duration: theme.transitions.duration.shorter,
          }),
          ...(offsetTop && {
            ...bgBlur({
              color: theme.palette.background.default,
            }),
            height: {
              xs: HEADER.H_DESKTOP_OFFSET,
            },
          }),
        }}
      >
        <Container
          sx={{
            height: 1,
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <Logo />
          <Box sx={{ flexGrow: 1 }} />

          <Stack alignItems="center" direction={{ xs: 'row', md: 'row-reverse' }}>
            <LogoutButton />
          </Stack>
        </Container>
      </Toolbar>

      {offsetTop && <HeaderShadow />}
    </AppBar>
  );
};

export default NonMenuNavBar;

import React from 'react';

import Toolbar from '@mui/material/Toolbar';
import { useTheme } from '@mui/material/styles';
import { HandshakeRounded } from '@mui/icons-material';
import { Box, Stack, Button, AppBar, Container } from '@mui/material';

import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import { useResponsive } from 'src/utils/hooks/use-responsive';
import { useOffSetTop } from 'src/utils/hooks/use-off-set-top';

import { bgBlur } from 'src/theme/css';

import Logo from 'src/components/page-components/logo';
import { HEADER } from 'src/components/page-layouts/config-layout';
import NavMobile from 'src/components/page-layouts/main/nav/mobile';
import NavDesktop from 'src/components/page-layouts/main/nav/desktop';
import HeaderShadow from 'src/components/page-layouts/common/header-shadow';
import { navConfig } from 'src/components/page-layouts/main/config-navigation';
import LoginButton from 'src/components/page-components/navigations/LoginButton';

const AuthMenuOptions = () => {
  const theme = useTheme();

  const mdUp = useResponsive('up', 'md');
  const offsetTop = useOffSetTop(HEADER.H_DESKTOP);
  return (
    <AppBar>
      <Toolbar
        disableGutters
        sx={{
          // borderBottom: '6px solid #FBA919',

          backgroundColor: '#FFFFFF',
          height: {
            xs: HEADER.H_MOBILE,
            md: 60,
          },
          transition: theme.transitions.create(['height'], {
            easing: theme.transitions.easing.easeInOut,
            duration: theme.transitions.duration.shorter,
          }),
          ...(offsetTop && {
            ...bgBlur({
              color: theme.palette.background.default,
            }),
            height: {
              xs: HEADER.H_DESKTOP_OFFSET,
            },
          }),
        }}
      >
        <Container
          sx={{
            height: 1,
            display: 'flex',
            alignItems: 'center',
          }}
        >
          {/* <Badge
          sx={{
            [`& .${badgeClasses.badge}`]: {
              top: 8,
              right: -16,
            },
          }}
          badgeContent={
            <Link
              href={paths.changelog}
              target="_blank"
              rel="noopener"
              underline="none"
              sx={{ ml: 1 }}
            >
              <Label color="info" sx={{ textTransform: 'unset', height: 22, px: 0.5 }}>
                v5.7.0
              </Label>
            </Link>
          }
        >
        </Badge> */}
          <Logo />
          <Box sx={{ flexGrow: 1 }} />

          {mdUp && <NavDesktop data={navConfig} />}

          <Stack alignItems="center" direction={{ xs: 'row', md: 'row-reverse' }}>
            <Button
              sx={{
                // mx: 1,
                display: 'flex',
                fontSize: '0.8rem',
                alignItems: 'center',
                gap: { xs: '0.2rem', sm: '0.4rem' },
                paddingX: { xs: '1rem', sm: '2rem' },
                width: '100%',
                textWrap: 'nowrap',
                backgroundColor: '#2E8ACA !important',
                color: '#ffffff', // Set text color to white
                border: '2px solid transparent',
                '&:hover': {
                  backgroundColor: '#2E8ACA', // Keep the same background color on hover
                  borderColor: '#000000', // Set the border color to black on hover
                  color: '#ffffff', // Ensure text color remains white on hover
                },
              }}
              rel="noopener"
              href={DefaultRoutes.auth_url.partnerRegistration}
              variant="outlined"
            >
              <HandshakeRounded />
              Become a Partner
            </Button>

            <LoginButton />

            {!mdUp && <NavMobile data={navConfig} />}
          </Stack>
        </Container>
      </Toolbar>

      {offsetTop && <HeaderShadow />}
    </AppBar>
  );
};

export default AuthMenuOptions;

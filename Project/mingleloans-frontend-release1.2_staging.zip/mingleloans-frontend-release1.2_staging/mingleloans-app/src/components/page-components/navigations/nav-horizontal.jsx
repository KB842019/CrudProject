import { memo } from 'react';
import Scrollbar from '@components/mui-components/scrollbar';
import { NavSectionHorizontal } from '@components/mui-components/nav-section';

import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import { useTheme } from '@mui/material/styles';

import { useMockedUser } from 'src/utils/hooks/use-mocked-user';

import { bgBlur } from 'src/theme/css';

import { useNavData } from './config-navigation';
import { HEADER } from '../../page-layouts/config-layout';
import HeaderShadow from '../../page-layouts/common/header-shadow';
// ----------------------------------------------------------------------

function NavHorizontal() {
  const theme = useTheme();

  const { user } = useMockedUser();

  const menuItems = useNavData();

  return (
    <AppBar
      component="div"
      sx={{
        backgroundColor: 'yellow',
        top: HEADER.H_DESKTOP_OFFSET,
      }}
    >
      <Toolbar
        sx={{
          ...bgBlur({
            color: theme.palette.background.default,
          }),
        }}
      >
        <Scrollbar
          sx={{
            '& .simplebar-content': {
              display: 'flex',
            },
          }}
        >
          <NavSectionHorizontal
            data={menuItems}
            slotProps={{
              currentRole: user?.role,
            }}
            sx={{
              ...theme.mixins.toolbar,
            }}
          />
        </Scrollbar>
      </Toolbar>

      <HeaderShadow />
    </AppBar>
  );
}

export default memo(NavHorizontal);

import SvgColor from '@components/mui-components/svg-color';
import { useMemo, useState, useEffect, useCallback } from 'react';

import { ModuleRoutes } from 'src/routes/ModuleRoutes';

import { useAuthContext } from 'src/middleware/auth/hooks';
import { EntityTypesEnum } from 'src/global/ValueTypes/EntityTypes';

const icon = (name, type = 'svg') => (
  <SvgColor src={`/assets/icons/navbar/${name}.${type}`} sx={{ width: 1, height: 1 }} />
);

const ICONS = {
  job: icon('ic_job'),
  blog: icon('ic_blog'),
  chat: icon('ic_chat'),
  mail: icon('ic_mail'),
  user: icon('ic_user'),
  file: icon('ic_file'),
  lock: icon('ic_lock'),
  tour: icon('ic_tour'),
  order: icon('ic_order'),
  label: icon('ic_label'),
  blank: icon('ic_blank'),
  kanban: icon('ic_kanban'),
  folder: icon('ic_folder'),
  banking: icon('ic_banking'),
  booking: icon('ic_booking'),
  invoice: icon('ic_invoice'),
  product: icon('ic_product'),
  calendar: icon('ic_calendar'),
  disabled: icon('ic_disabled'),
  external: icon('ic_external'),
  menuItem: icon('ic_menu_item'),
  ecommerce: icon('ic_ecommerce'),
  analytics: icon('ic_analytics'),
  dashboard: icon('ic_dashboard'),
  overdraft: icon('overdraft', 'png'),
  transfer: icon('transfer', 'png'),
};

const applicantMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my tickets',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise tickets',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
  {
    title: 'refer and earn',
    path: ModuleRoutes.shared.refer_n_earn,
    icon: ICONS.invoice,
  },
];

const partnerMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'staff management',
    path: ModuleRoutes.staff.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

const staffMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

const salesMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

const supportMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

const clientMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

const agentMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

const adminMenuItems = [
  {
    title: 'dashboard',
    path: ModuleRoutes.shared.dashboard,
    icon: ICONS.dashboard,
    module: 'dashboard',
    action: 'view',
  },
  {
    title: 'customer management',
    path: ModuleRoutes.customer.index,
    icon: ICONS.user,
  },
  {
    title: 'my applications',
    path: ModuleRoutes.loan_application.my_applications,
    icon: ICONS.lock,
  },
  {
    title: 'loan applications',
    path: ModuleRoutes.loan_application.index,
    icon: ICONS.user,
    children: [
      {
        title: 'home loan',
        path: ModuleRoutes.loan_application.home_loan,
        icon: ICONS.banking,
      },
      {
        title: 'personal loan',
        path: ModuleRoutes.loan_application.personal_loan,
        icon: ICONS.user,
      },
      {
        title: 'business loan',
        path: ModuleRoutes.loan_application.business_loan,
        icon: ICONS.job,
      },
      {
        title: 'mortgage loan',
        path: ModuleRoutes.loan_application.mortgage_loan,
        icon: ICONS.label,
      },
      {
        title: 'overdraft',
        path: ModuleRoutes.loan_application.overdraft,
        icon: ICONS.overdraft,
      },
      {
        title: 'balance transfer',
        path: ModuleRoutes.loan_application.balance_transfer,
        icon: ICONS.transfer,
      },
    ],
  },
  {
    title: 'support',
    path: ModuleRoutes.support.index,
    icon: ICONS.mail,
    children: [
      {
        title: 'my ticket',
        path: ModuleRoutes.support.my_tickets,
        icon: ICONS.user,
      },
      {
        title: 'raise ticket',
        path: ModuleRoutes.support.raise_ticket,
        icon: ICONS.job,
      },
    ],
  },
];

export function useNavData() {
  const { user } = useAuthContext();
  const [menuItems, setMenuItems] = useState(applicantMenuItems);

  const SetUpMenu = useCallback(() => {
    if (!user) {
      return;
    }

    if (user.entityType === EntityTypesEnum.APPLICANT) {
      setMenuItems(applicantMenuItems);
    }
    if (user.entityType === EntityTypesEnum.PARTNER) {
      setMenuItems(partnerMenuItems);
    }
    if (user.entityType === EntityTypesEnum.STAFF) {
      setMenuItems(staffMenuItems);
    }
    if (user.entityType === EntityTypesEnum.SALES) {
      setMenuItems(salesMenuItems);
    }
    if (user.entityType === EntityTypesEnum.SUPPORT) {
      setMenuItems(supportMenuItems);
    }
    if (user.entityType === EntityTypesEnum.CLIENT) {
      setMenuItems(clientMenuItems);
    }
    if (user.entityType === EntityTypesEnum.AGENT) {
      setMenuItems(agentMenuItems);
    }
    if (user.entityType === EntityTypesEnum.ADMIN) {
      setMenuItems(adminMenuItems);
    }

    // console.log(menuItems);a
  }, [user, setMenuItems]);

  useEffect(() => {
    SetUpMenu();
  }, [SetUpMenu]);

  const menu = useMemo(
    () => [
      {
        subheader: 'Modules',
        items: menuItems,
      },
    ],
    [menuItems]
  );

  return menu;
}

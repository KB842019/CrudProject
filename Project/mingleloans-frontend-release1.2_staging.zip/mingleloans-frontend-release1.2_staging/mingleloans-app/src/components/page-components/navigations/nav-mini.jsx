import { NavSectionMini } from '@components/mui-components/nav-section';
import MinimizeLogo from '@components/page-components/logo/MinimizeLogo';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';

import { hideScroll } from 'src/theme/css';
import { useAuthContext } from 'src/middleware/auth/hooks';

import { useNavData } from './config-navigation';
import { NAV } from '../../page-layouts/config-layout';
import NavToggleButton from './header-toolbar/nav-toggle-button';

// ----------------------------------------------------------------------

export default function NavMini() {
  const { user } = useAuthContext();

  const menuItems = useNavData();

  return (
    <Box
      sx={{
        flexShrink: { lg: 0 },
        width: { lg: NAV.W_MINI },
        backgroundColor: '#DAEBFE',
      }}
    >
      <NavToggleButton
        sx={{
          top: 19,
          left: NAV.W_MINI - 9,
        }}
      />

      <Stack
        sx={{
          pb: 2,
          height: 1,
          position: 'fixed',
          width: NAV.W_MINI,
          borderRight: (theme) => `dashed 1px ${theme.palette.divider}`,
          ...hideScroll.x,
        }}
      >
        <MinimizeLogo sx={{ mx: 'auto', my: 1 }} />
        <NavSectionMini
          data={menuItems}
          slotProps={{
            currentRole: user?.entityType,
          }}
        />
      </Stack>
    </Box>
  );
}

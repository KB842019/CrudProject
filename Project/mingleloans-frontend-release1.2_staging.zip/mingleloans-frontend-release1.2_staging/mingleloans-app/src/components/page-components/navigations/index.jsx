/* eslint-disable import/no-unresolved */
// import PropTypes from 'prop-types';
// import { useSettingsContext } from '@components/mui-components/settings';

import PropTypes from 'prop-types';

import { Box } from '@mui/material';

import { useBoolean } from 'src/utils/hooks/use-boolean';
import { useResponsive } from 'src/utils/hooks/use-responsive';

import NavMini from 'src/components/page-components/navigations/nav-mini';
import { useSettingsContext } from 'src/components/mui-components/settings';
import NavHorizontal from 'src/components/page-components/navigations/nav-horizontal';
import NavVertical from 'src/components/page-components/navigations/left-menu/nav-vertical';

import Main from './main';
import Header from './header-toolbar/HeaderToolbar';

// import Box from '@mui/material/Box';

// import { useBoolean } from 'src/utils/hooks/use-boolean';
// import { useResponsive } from 'src/utils/hooks/use-responsive';

// import Main from './main';
// import Header from './header';
// import NavMini from './nav-mini';
// import NavVertical from './nav-vertical';
// import NavHorizontal from './nav-horizontal';

// ----------------------------------------------------------------------

export default function DashboardLayout({ children }) {
  const settings = useSettingsContext();

  const lgUp = useResponsive('up', 'lg');

  const nav = useBoolean();

  const isHorizontal = settings.themeLayout === 'horizontal';

  const isMini = settings.themeLayout === 'mini';

  const renderNavMini = <NavMini />;

  const renderHorizontal = <NavHorizontal />;

  const renderNavVertical = <NavVertical openNav={nav.value} onCloseNav={nav.onFalse} />;

  if (isHorizontal) {
    return (
      <>
        <Header onOpenNav={nav.onTrue} />

        {lgUp ? renderHorizontal : renderNavVertical}

        <Main>{children}</Main>
      </>
    );
  }

  if (isMini) {
    return (
      <>
        <Header onOpenNav={nav.onTrue} />

        <Box
          sx={{
            minHeight: 1,
            display: 'flex',
            flexDirection: { xs: 'column', lg: 'row' },
          }}
        >
          {lgUp ? renderNavMini : renderNavVertical}

          <Main>{children}</Main>
        </Box>
      </>
    );
  }

  return (
    <>
      <Header onOpenNav={nav.onTrue} />

      <Box
        sx={{
          minHeight: 1,
          display: 'flex',
          flexDirection: { xs: 'column', lg: 'row' },
        }}
      >
        {renderNavVertical}

        <Main>{children}</Main>
      </Box>
    </>
  );
}

DashboardLayout.propTypes = {
  children: PropTypes.node,
};

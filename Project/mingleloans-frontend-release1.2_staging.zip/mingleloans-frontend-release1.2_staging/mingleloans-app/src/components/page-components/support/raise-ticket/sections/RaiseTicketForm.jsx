import { useState } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';

import AttachFileIcon from '@mui/icons-material/AttachFile';
import { Box, Grid, Link, Button, Select, MenuItem, Typography, FormControl } from '@mui/material';

import { useAuthContext } from 'src/middleware/auth/hooks';

import FormProvider, { RHFTextField } from 'src/components/mui-components/hook-form';

import { validationSchema, RaiseTiceketServices } from '../RaiseTiceketServices';

const fieldStyle = {
  '& .MuiInputBase-root': {
    height: '35px',
  },
};

const selectStyle = {
  height: '35px',
  '& .MuiSelect-select': {
    height: '35px',
    display: 'flex',
    alignItems: 'center',
  },
};

const RaiseTicketForm = () => {
  const [fileName, setFileName] = useState('');
  const { user } = useAuthContext();

  const fullName = `${user?.firstName || ''} ${user?.lastName || ''}`;

  const methods = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      fullName,
      email: user?.emailId || '',
      description: '',
      category: '',
      subject: '',
    },
  });

  const handleClick = async (e) => {
    e.preventDefault();
    alert(1);
    const formData = methods.getValues();
    // alert(`Form data: ${JSON.stringify(formData)}`);
    const apiResponse = await RaiseTiceketServices(formData);
    alert(apiResponse);
    // if (apiResponse.success) {
    //   alert(apiResponse.message);
    // } else {
    //   alert(`Error: ${apiResponse.message}`);
    // }
  };
  const {
    setValue,
    control,
    formState: { isSubmitting },
  } = methods;

  const onFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setValue('attachment', file);
      setFileName(file.name);
    }
  };

  return (
    <FormProvider methods={methods} onSubmit={handleClick}>
      <Box
        component="form"
        sx={{
          width: '70%',
          margin: 'auto',
          mt: 5,
          backgroundColor: 'white',
          pt: 2,
          pb: 2,
          borderRadius: 2,
          boxShadow: 10,
        }}
      >
        <Grid container spacing={2} width="auto" pr={2}>
          <Grid item xs={12} sm={6} md={6}>
            <Typography variant="subtitle2" mb={0.5}>
              Full Name
            </Typography>
            <RHFTextField
              name="fullName"
              value={fullName}
              placeholder="Enter your full name"
              required
              sx={fieldStyle}
              disabled
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" mb={0.5}>
              Email Address
            </Typography>
            <RHFTextField
              name="email"
              type="email"
              placeholder="Enter your email"
              required
              sx={fieldStyle}
              disabled
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" mb={0.5}>
              Category
            </Typography>
            <FormControl fullWidth required>
              <Controller
                name="category"
                control={control}
                defaultValue=""
                render={({ field }) => (
                  <Select {...field} sx={selectStyle}>
                    <MenuItem value="General">General</MenuItem>
                    <MenuItem value="Technical">Technical</MenuItem>
                    <MenuItem value="Billing">Billing</MenuItem>
                  </Select>
                )}
              />
            </FormControl>
          </Grid>

          <Grid item xs={12} sm={6}>
            <Typography variant="subtitle2" mb={0.5}>
              Select Subject
            </Typography>
            <FormControl fullWidth required>
              <Controller
                name="subject"
                control={control}
                defaultValue=""
                render={({ field }) => (
                  <Select {...field} sx={selectStyle}>
                    <MenuItem value="Issue with product">Issue with product</MenuItem>
                    <MenuItem value="Account issue">Account issue</MenuItem>
                    <MenuItem value="Payment problem">Payment problem</MenuItem>
                  </Select>
                )}
              />
            </FormControl>
          </Grid>

          <Grid item xs={12}>
            <Typography variant="subtitle2" mb={0.5}>
              Describe your problem
            </Typography>
            <RHFTextField name="description" multiline rows={2} required />
          </Grid>

          <Grid item xs={12}>
            <Link
              component="label"
              variant="body2"
              sx={{
                cursor: 'pointer',
                color: 'primary.main',
                textDecoration: 'underline',
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <AttachFileIcon fontSize="small" />
              Attach File
              <input type="file" hidden onChange={onFileChange} />
            </Link>
            {fileName && <Typography variant="body2">Selected File: {fileName}</Typography>}
          </Grid>

          <Grid item xs={12} display="flex" justifyContent="flex-end">
            <Button type="submit" variant="contained" color="primary" disabled={isSubmitting}>
              Create Ticket
            </Button>
          </Grid>
        </Grid>
      </Box>
    </FormProvider>
  );
};

export default RaiseTicketForm;

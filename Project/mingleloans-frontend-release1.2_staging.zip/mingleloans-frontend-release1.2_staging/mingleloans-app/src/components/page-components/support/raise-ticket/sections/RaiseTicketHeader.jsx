/* eslint-disable arrow-body-style */
import { Box, Link, Typography } from '@mui/material';

const RaiseTicketHeader = () => {
  return (
    <Box>
      <Typography variant="h5" fontWeight="bold" >
        Raise Ticket
      </Typography>

      <Typography variant="body1" color="text.secondary" sx={{ mt: 1 }}>
        Welcome to our support request page. Please complete the following support request form to
        contact our support team. You will receive a response within 48 hours. For urgent matters,
        please call us at <Link href="tel:919876543214">91-9876543214</Link> or email us at{' '}
        <Link href="mailto:support@mingleloans.com">support@mingleloans.com</Link>.
      </Typography>
    </Box>
  );
};

export default RaiseTicketHeader;

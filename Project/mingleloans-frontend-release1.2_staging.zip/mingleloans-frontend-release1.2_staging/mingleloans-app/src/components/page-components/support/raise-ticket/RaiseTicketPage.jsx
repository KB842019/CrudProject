import { Container } from '@mui/material';

import { useSettingsContext } from 'src/components/mui-components/settings';
import RaiseTicketForm from 'src/components/page-components/support/raise-ticket/sections/RaiseTicketForm';
import RaiseTicketHeader from 'src/components/page-components/support/raise-ticket/sections/RaiseTicketHeader';

const RaiseTicketPage = () => {
  const settings = useSettingsContext();
  return (
    <Container maxWidth={settings.themeStretch ? false : 'xl'}>
        <RaiseTicketHeader />
        <RaiseTicketForm />
    </Container>
  );
};

export default RaiseTicketPage;

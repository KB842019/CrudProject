import * as Yup from 'yup';

import { RESPONSE_CODES } from 'src/global/ResponseCodes';
import { postTicket } from 'src/middleware/support/RaiseTicketService';

export const validationSchema = Yup.object().shape({
  fullName: Yup.string().required('Full Name is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  category: Yup.string().required('Category is required'),
  subject: Yup.string().required('Subject is required'),
  description: Yup.string().required('Description is required'),
});

export const RaiseTiceketServices = async (ticketData) => {
  try {
    const response = await postTicket(ticketData);
    if (response?.responseCode === RESPONSE_CODES.general.Success.code) {
      return { success: true, message: 'Ticket created successfully', data: response.data };
    }
    return { success: false, message: 'Failed to create ticket', data: null };
  } catch (error) {
    return { success: false, message: error.message || 'Unexpected error occurred', data: null };
  }
};

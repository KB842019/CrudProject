import { Helmet } from 'react-helmet-async';

export default function PageTitle(props) {
  const { title } = props;

  return (
    <Helmet>
      <title>{title ? `MingleLoans: ${title}` : 'MingleLoans'}</title>
    </Helmet>
  );
}

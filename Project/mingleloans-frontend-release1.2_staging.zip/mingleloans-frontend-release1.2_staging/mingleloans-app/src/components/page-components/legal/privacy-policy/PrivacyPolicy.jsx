export const PrivacyPolicy = () => {
  <h3>Coming soon</h3>;
};

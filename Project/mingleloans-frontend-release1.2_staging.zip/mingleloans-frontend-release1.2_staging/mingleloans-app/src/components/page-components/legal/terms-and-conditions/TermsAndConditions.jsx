export const TermsAndConditions = () => {
  <h3>Coming soon</h3>;
};

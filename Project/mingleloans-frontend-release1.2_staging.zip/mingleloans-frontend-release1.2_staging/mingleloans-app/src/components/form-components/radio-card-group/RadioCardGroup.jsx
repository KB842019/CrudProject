import React from 'react';
import PropTypes from 'prop-types';

import { useTheme } from '@mui/material/styles';
import {
  Grid,
  Card,
  Radio,
  CardMedia,
  Typography,
  CardContent,
  useMediaQuery,
  CardActionArea,
  FormControlLabel,
} from '@mui/material';

export default function RadioCardGroup({
  register,
  heading,
  cards,
  setSelectedValue,
  selectedValue,
}) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };

  return (
    <>
      <Typography variant="h5">{heading}</Typography>
      <Grid container spacing={2} mt={2} mb={3}>
        {cards.map((card, i) => (
          <Grid key={i} item xs={12} sm={12} md={6}>
            <Card
              key={card.value}
              variant="outlined"
              sx={{
                display: 'flex',
                borderColor:
                  selectedValue === card.value ? theme.palette.primary.main : 'rgba(0, 0, 0, 0.23)',
                borderWidth: selectedValue === card.value ? 2 : 1,
                boxShadow: selectedValue === card.value ? 3 : 1,
              }}
            >
              <CardActionArea
                onClick={() => setSelectedValue(card.value)}
                sx={{ display: 'flex', flexDirection: isMobile ? 'column' : 'row' }}
              >
                <CardMedia
                  component="img"
                  sx={{ width: 150, padding: 1 }}
                  image={card.image}
                  alt={card.title}
                />
                <Grid sx={{ display: 'flex', flexDirection: 'column' }}>
                  <CardContent sx={{ flex: '1 0 auto' }}>
                    <FormControlLabel
                      control={
                        <Radio
                          checked={selectedValue === card.value}
                          onChange={handleChange}
                          value={card.value}
                          name="radio-button-demo"
                          aria-label={card.title}
                          {...register}
                          sx={{
                            position: 'absolute',
                            top: '-9999px',
                            left: '-9999px', // Hiding the radio button offscreen
                          }}
                        />
                      }
                      label={
                        <>
                          <Typography
                            variant="h5"
                            component="div"
                            sx={{
                              textTransform: 'capitalize',
                              textAlign: isMobile ? 'center' : 'left',
                              whiteSpace: 'nowrap',
                            }}
                          >
                            {card.title}
                          </Typography>
                          <Typography
                            variant="body2"
                            color="text.secondary"
                            sx={{ textAlign: isMobile ? 'center' : 'left' }}
                          >
                            {card.description}
                          </Typography>
                        </>
                      }
                      labelPlacement="bottom"
                    />
                  </CardContent>
                </Grid>
              </CardActionArea>
            </Card>
          </Grid>
        ))}
      </Grid>
    </>
  );
}

RadioCardGroup.prototype = {
  heading: PropTypes.string,
  cards: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string,
      title: PropTypes.string,
      description: PropTypes.string,
    })
  ),
  setSelectedValue: PropTypes.func,
  selectedValue: PropTypes.bool,
  register: PropTypes.func,
};
import React, { useState } from 'react';

import TextField from '@mui/material/TextField';

const NumericInputWithSpace = ({ handleValueChange, ...props }) => {
  const [value, setValue] = useState('');
  const [formattedValue, setFormattedValue] = useState('');

  const handleInputChange = (e) => {
    let inputValue = e.target.value;

    // NEED TO CHECK THIS REGEX => if (!/^\d?$/.test(inputValue)) return;

    // Remove all non-numeric characters
    inputValue = inputValue.replace(/\D/g, '');

    // Limit to 6 digits
    inputValue = inputValue.slice(0, 11);

    // Format with a space after every digit
    setFormattedValue(inputValue.split('').join(' '));

    // Pass the raw value (without spaces) to the parent
    if (inputValue) {
      handleValueChange(inputValue);
    }
  };

  const handleFocus = () => {
    // Remove the space on focus
    setValue(value.trim());
  };

  const handleBlur = () => {
    // Add the space back on blur if there is a valid value
    if (value) {
      setValue(`${value} `);
    }
  };

  return (
    <TextField
      {...props} // Spread additional props
      value={formattedValue}
      onChange={handleInputChange}
      onFocus={handleFocus}
      onBlur={handleBlur}
      inputProps={{
        maxLength: 11, // 6 digits + 5 space
        ...props.inputProps, // Allow additional inputProps to be passed
      }}
    />
  );
};

export default NumericInputWithSpace;

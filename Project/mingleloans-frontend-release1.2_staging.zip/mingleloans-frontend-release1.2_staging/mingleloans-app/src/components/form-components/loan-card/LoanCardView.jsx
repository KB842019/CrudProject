import React from 'react'

import carloan from './Images/carloan.jpg'
import homeloan from './Images/homeloan.jpg'
import goldloan from './Images/goldloan.jpg'
import LoanDetailsCard from './LoanCardDetails'
import mortgageloan from './Images/mortgageloan.jpg'
import personalloan from './Images/personalloan.jpg'
import educationloan from './Images/educationloan.jpg'

const loanData = [
    {
      loanType: "Home",
      loanApplicationNumber: "7289885356",
      status: "Approved",
      loanTenure:"15 Years",
      createdOn:'08-Nov-2024',
      backgroundColor: "#f0f8ff", // Light blue background color
      imageUrl: homeloan, // Replace with a real image URL
    },
   
    {
        loanType: "Car",
        loanApplicationNumber: "7289885343",
        status: "Reject",
        loanTenure:"20 Years",
        createdOn:'11-May-2024',
        backgroundColor: "#ffe4e1", // Light pink background color
        imageUrl: carloan, // Replace with a real image URL
      },
      {
        loanType: "Education",
        loanApplicationNumber: "7283545356",
        status: "Closed",
        loanTenure:"10 Years",
        createdOn:'08-Jan-2024',
        backgroundColor: "#ffe4e1", // Light pink background color
        imageUrl:educationloan, // Replace with a real image URL
      },
      {
        loanType: "Gold",
        loanApplicationNumber: "7213485356",
        status: "Draft",
        loanTenure:"5 Years",
        createdOn:'01-Jul-2024',
        backgroundColor: "#ffe4e1", // Light pink background color
        imageUrl: goldloan, // Replace with a real image URL
      },
      {
        loanType: "Mortgage",
        loanApplicationNumber: "7289885908",
        status: "In-Review",
        loanTenure:"5 Years",
        createdOn:'01-Aug-2024',
        backgroundColor: "#ffe4e1", // Light pink background color
        imageUrl: mortgageloan, // Replace with a real image URL
      },
      {
        loanType: "Personal",
        loanApplicationNumber: "76549885356",
        status: "Draft",
        loanTenure:"15 Years",
        createdOn:'28-Mar-2024',
        backgroundColor: "#ffe4e1", // Light pink background color
        imageUrl:personalloan, // Replace with a real image URL
      },

    // Add more loan objects if needed
  ];

const LoanCardView = () => (
    <div className='flex justify-between flex-wrap'>
       {loanData.map((loan, index) => (
        <LoanDetailsCard
          key={index}
          loanType={loan.loanType}
          loanApplicationNumber={loan.loanApplicationNumber}
          status={loan.status}
          loanTenure={loan.loanTenure}
          createdOn={loan.createdOn}
          backgroundColor={loan.backgroundColor}
          imageUrl={loan.imageUrl}
        />
      ))}
    </div>
  )

export default LoanCardView
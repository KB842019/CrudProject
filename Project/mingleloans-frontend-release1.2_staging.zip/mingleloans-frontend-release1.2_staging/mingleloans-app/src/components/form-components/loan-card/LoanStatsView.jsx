import React from 'react';

import { Box, Grid } from '@mui/material';

import LoanCard from './LoanCard';

const loanStat = [
  { id: '1', title: 'Home Loan', value: '20', loanType: 'HomeLoan' },
  { id: '2', title: 'Car Loan', value: '11', loanType: 'CarLoan' },
  { id: '3', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '4', title: 'Home Loan', value: '20', loanType: 'HomeLoan' },
  { id: '5', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '6', title: 'Car Loan', value: '11', loanType: 'CarLoan' },
  { id: '7', title: 'Car Loan', value: '11', loanType: 'CarLoan' },
  { id: '8', title: 'Home Loan', value: '10', loanType: 'HomeLoan' },
  { id: '9', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '10', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '11', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '12', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '13', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '14', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '15', title: 'Personal Loan', value: '13', loanType: 'PersonalLoan' },
  { id: '16', title: 'Personal Loan', value: '13', loanType: 'BusinessLoan' },
  { id: '17', title: 'Personal Loan', value: '13', loanType: 'EducationLoan' },
  { id: '18', title: 'Personal Loan', value: '13', loanType: 'MortgageLoan' },
];

const calculateCounts = (data) =>
  data.reduce((acc, item) => {
    acc[item.loanType] = (acc[item.loanType] || 0) + 1;
    return acc;
  }, {});

const LoanStatsView = () => {
  const counts = calculateCounts(loanStat);

  return (
    <Box
      sx={
        {
          // padding: 2,
          // paddingLeft: '0px',
          //  marginTop:'20px'
        }
      }
    >
      <Grid container spacing={2}>
        {Object.entries(counts).map(([loanType, count]) => (
          <Grid item xs={12} sm={6} md={4} lg={2} key={loanType}>
            <LoanCard
              title={loanType.replace(/Loan/, ' Loan')}
              value={count}
              background={
                (loanType === 'HomeLoan' && 'cornflowerblue') ||
                (loanType === 'CarLoan' && 'lightcoral') ||
                'lightgreen'
              }
            />
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default LoanStatsView;

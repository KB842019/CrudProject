/* eslint-disable import/no-unresolved */
import React from 'react';

import { Box, Card, Link, Grid, Typography } from '@mui/material';

import bgg from 'src/assets/images/shared/bgg.png';
import bl from 'src/assets/images/shared/loan-types/bl.svg';
import hl from 'src/assets/images/shared/loan-types/hl.svg';
import bt from 'src/assets/images/shared/loan-types/bt.svg';
import pl from 'src/assets/images/shared/loan-types/pl.svg';
import LoanCardData from 'src/assets/data/dummy-data/LoanCardData.json';
import mortgage from 'src/assets/images/shared/cardimages/mortgage.svg';
import overdraft from 'src/assets/images/shared/cardimages/overdraft.svg';

const iconMapper = {
  HomeIcon: <img src={hl} alt="Home" style={{ width: '24px', height: '24px' }} />,
  BusinessIcon: <img src={bl} alt="Business" style={{ width: '24px', height: '24px' }} />,
  PersonalIcon: <img src={pl} alt="Personal" style={{ width: '24px', height: '24px' }} />,
  MortgageIcon: <img src={mortgage} alt="Mortgage" style={{ width: '24px', height: '24px' }} />,
  OverDraft: <img src={overdraft} alt="Overdraft" style={{ width: '24px', height: '24px' }} />,
  BalanceTransfer: (
    <img src={bt} alt="Balance Transfer" style={{ width: '24px', height: '24px' }} />
  ),
};

const IndividualLoanCard = () => (
  <Box sx={{ paddingRight: { xs: '20px', sm: '30px', md: '30px' }, paddingLeft: { xs: '5px' } }}>
    <Grid container spacing={2}>
      {LoanCardData.map((card, index) => (
        <Grid item xs={12} sm={6} md={4} lg={4} key={index}>
          <Card
            sx={{
              width: '100%',
              boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
              borderRadius: '8px',
              backgroundImage: `url(${bgg})`,
              backgroundSize: 'cover',
              backgroundRepeat: 'no-repeat',
              color: '#ffffff',
              display: 'flex',
              flexDirection: 'column',
            }}
          >
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '8px',
                height: '50px',
              }}
            >
              <Typography
                variant="h6"
                sx={{ fontWeight: 'bold', ml: '9px', mt: '35px', color: '#1976D2' }}
              >
                {card.loanType}
              </Typography>
              <Box
                sx={{
                  mt: '40px',
                  mr: '10px',
                  backgroundColor: 'white',
                  borderRadius: '50%',
                  padding: '8px',
                  boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.2)',
                }}
              >
                {iconMapper[card.iconType] || null}
              </Box>
            </Box>

            <Grid container spacing={0.5} mt={1} padding="0 15px" paddingBottom="10px">
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  Loan ID:
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  {card.loanId}
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  Loan Amount:
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  ₹{card.amount}
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  Interest Rate:
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  {card.interestRate}%
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  Term:
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  {card.term} Months
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  Monthly Payment:
                </Typography>
              </Grid>
              <Grid item xs={4} sm={6} md={6}>
                <Typography variant="body2" sx={{ color: '#757575' }}>
                  ₹{card.monthlyPayment}
                </Typography>
              </Grid>
            </Grid>

            <Box
              sx={{
                backgroundColor: '#f5f5f5',
                padding: '8px 16px',
                display: 'flex',
                justifyContent: 'flex-end',
              }}
            >
              <Link
                href="#"
                sx={{
                  marginRight: '16px',
                  color: '#1976D2',
                  textDecoration: 'underline',
                }}
              >
                View
              </Link>
              <Link
                href="#"
                sx={{
                  marginRight: '16px',
                  color: '#1976D2',
                  textDecoration: 'underline',
                }}
              >
                Print
              </Link>
              <Link
                href="#"
                sx={{
                  marginRight: '16px',
                  color: '#1976D2',
                  textDecoration: 'underline',
                }}
              >
                Edit
              </Link>
              <Link href="#" sx={{ color: '#1976D2', textDecoration: 'underline', mr: '3px' }}>
                Discard
              </Link>
            </Box>
          </Card>
        </Grid>
      ))}
    </Grid>
  </Box>
);

export default IndividualLoanCard;

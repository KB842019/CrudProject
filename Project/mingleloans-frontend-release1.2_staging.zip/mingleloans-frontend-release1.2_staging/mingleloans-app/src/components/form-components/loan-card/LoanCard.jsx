import { Box, Card, Typography, CardContent } from '@mui/material';

const LoanCard = ({ title, value, background }) => (
  <Card
    sx={{
      margin: '10px auto',
      padding: 2,
      position: 'relative',
      overflow: 'hidden',
      paddingBottom:'0px',
      color: 'white',
      border: '1px solid rgba(255, 255, 255, 0.3)',
      boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.5)',
      height: { xs: '120px', sm: '130px', md: '120px' },
      backgroundColor: background || 'cornflowerblue',
      width: { xs: '90%', sm: '200px', md: '150px' },
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
    <Box
      sx={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.3)',
        zIndex: 1,
      }}
    />
    <CardContent
      sx={{
        zIndex: 2,
        position: 'relative',
        display: 'flex',
        flexDirection: { xs: 'column', md: 'column' },
        alignItems: 'center',
        justifyContent: 'center',
        padding: '8px',
        textAlign: 'center',
      }}
    >
      <Typography
        sx={{
          color: 'white',
          fontWeight: 'bold',
          fontSize: { xs: '14px', sm: '16px', md: '13px' },
          marginBottom: 0,
          paddingBottom: 0,
          order:'2',
          textAlign:'center',
        }}
      >
        {title}
      </Typography>
      <Box
        sx={{
          width: { xs: 35, sm: 45, md: 40 },
          height: { xs: 35, sm: 45, md: 40 },
          borderRadius: '50%',
          backgroundColor: 'white',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom:'10px',
          boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.2)',
        }}
      >
        <Typography
          sx={{
            color: 'black',
            fontSize: { xs: '14px', sm: '16px', md: '18px' },
            fontWeight: 'bold',
            marginBottom: 0,
            order:'1',
            paddingBottom: 0,
          }}
        >
          {value}
        </Typography>
      </Box>
    </CardContent>
  </Card>
);

export default LoanCard;

import {
    Box,
    Card,
    Grid,
    Button,
    Divider,
    useTheme,
    Typography,
    CardActions,
    CardContent,
    useMediaQuery,
  } from '@mui/material';
  
  const LoanDetailsCard = ({
    loanType,
    loanApplicationNumber,
    status,
    createdOn,
    loanTenure,
    backgroundColor,
    imageUrl,
  }) => {
    const theme = useTheme();
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));
  
    return (
      <Card
        sx={{
          margin: '10px auto',
          padding: 2,
          position: 'relative',
          overflow: 'hidden',
          background: `url(${imageUrl}) no-repeat center center`,
          backgroundSize: 'cover',
          color: 'white',
          border: '1px solid rgba(255, 255, 255, 0.3)',
          boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.5)',
          backgroundColor: backgroundColor || 'transparent',
          width: isSmallScreen ? '90%' : '300px', // Adjust width for mobile screens
          maxWidth: '100%', // Ensure card does not exceed container width
          height: isSmallScreen ? 'auto' : '240px', // Auto height for smaller screens
        }}
      >
        <Box
          sx={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0, 0, 0, 0.4)',
            zIndex: 1,
          }}
        />
  
        <Typography
          variant={isSmallScreen ? 'h6' : 'h5'}
          gutterBottom
          sx={{
            zIndex: 2,
            position: 'relative',
            textShadow: '2px 2px 4px rgba(0, 0, 0, 0.7)',
            textAlign: 'center',
          }}
        >
          {loanType} Loan
          <Divider sx={{ color: 'white', margin: '4px 0' }} />
        </Typography>
  
        <CardContent sx={{ zIndex: 2, position: 'relative', padding: '8px 12px' }}>
          <Grid container spacing={0.5}>
            <Grid item xs={12}>
              <Typography variant="h6" sx={{ lineHeight: 1.2 }}>{loanApplicationNumber}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Status:</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ lineHeight: 1.2 }}>{status}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Loan Tenure:</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ lineHeight: 1.2 }}>{loanTenure}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="subtitle2">Created On:</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ lineHeight: 1.2 }}>{createdOn}</Typography>
            </Grid>
          </Grid>
        </CardContent>
  
        <CardActions sx={{ zIndex: 2, position: 'relative' }}>
          <Box sx={{ flexGrow: 1 }} />
          {status === 'Draft' ? (
            <Button variant="contained" color="primary">
              Edit
            </Button>
          ) : (
            <Button variant="contained" color="primary">
              View
            </Button>
          )}
        </CardActions>
      </Card>
    );
  };
  
  export default LoanDetailsCard;
  
// SearchComponent.js
import React from 'react';

import { TextField } from '@mui/material';

const GridSearch = ({ searchValue, handleChange }) => (
 
    <TextField
      type="search"
      label="Search"
      onChange={handleChange}
      value={searchValue}
    /> 
  );

export default GridSearch;

/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable no-nested-ternary */
import axios from 'axios';
import { useState, useEffect } from 'react';

import {
  Table,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
  Typography,
  TableContainer,
  CircularProgress, // Material UI loader
} from '@mui/material';

import GridSearch from './search/GridSearch';
import GridPagination from './pagination/GridPagination';

const CustomGrid = () => {
  const [formData, setFormData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [searchValue, setSearchValue] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowPerPage] = useState(5);
  const [order, setOrder] = useState('ASC');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true); // Start loading
    axios
      .get('https://dummyjson.com/products')
      .then((response) => {
        setFormData(response.data.products);
        setFilteredData(response.data.products);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
        setLoading(false);
      });
  }, []);

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);

  const handlePrevious = () => {
    if (page > 0) {
      setPage(page - 1);
    }
  };

  const handleNext = () => {
    if (page < totalPages - 1) {
      setPage(page + 1);
    }
  };

  const handleChange = (e) => {
    const value = e.target.value.toLowerCase();
    setSearchValue(value);

    if (value === '') {
      setFilteredData(formData);
    } else {
      const result = formData.filter(
        (item) =>
          item.category.toLowerCase().includes(value) || item.title.toLowerCase().includes(value)
      );
      setFilteredData(result);
    }
    setPage(0);
  };

  const handleRowsPerPageChange = (event) => {
    setRowPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const sorting = (cols) => {
    const sorted = [...filteredData].sort((a, b) =>
      order === 'ASC'
        ? a[cols].toLowerCase() > b[cols].toLowerCase()
          ? 1
          : -1
        : a[cols].toLowerCase() < b[cols].toLowerCase()
          ? 1
          : -1
    );
    setFilteredData(sorted);
    setOrder(order === 'ASC' ? 'DESC' : 'ASC');
  };

  const handleCategoryClick = (category) => {
    setSelectedCategory(category);

    if (category === 'All') {
      setFilteredData(formData);
    } else {
      const filtered = formData.filter((item) => item.category === category);
      setFilteredData(filtered);
    }
    setPage(0);
  };

  const uniqueCategories = Array.from(new Set(formData.map((item) => item.category)));

  return (
    <>
      <div
        className="container
        m-auto mt-4"
      >
        <ul className="flex items-center gap-3">
          <li
            className={`text-blue-500 cursor-pointer ${selectedCategory === 'All' ? 'font-bold' : ''}`}
            onClick={() => handleCategoryClick('All')}
          >
            All <span className="text-gray-500">({formData.length})</span>
          </li>
          {uniqueCategories.map((category) => (
            <li
              key={category}
              className={`text-blue-500 cursor-pointer ${selectedCategory === category ? 'font-bold' : ''}`}
              onClick={() => handleCategoryClick(category)}
            >
              {category.toUpperCase()}{' '}
              <span className="text-gray-500">
                ({formData.filter((item) => item.category === category).length})
              </span>
            </li>
          ))}
        </ul>
      </div>

      <div className="container mx-auto p-4">
        <GridSearch searchValue={searchValue} handleChange={handleChange} />

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <CircularProgress />
          </div>
        ) : (
          <>
            <TableContainer className="mt-4 rounded-lg shadow-lg overflow-hidden border border-gray-300 max-w-screen mx-auto">
              <Table className="min-w-full">
                <TableHead>
                  <TableRow>
                    <TableCell className="cursor-pointer" onClick={() => sorting('category')}>
                      Category ↑↓
                    </TableCell>
                    <TableCell className="cursor-pointer" onClick={() => sorting('title')}>
                      Title ↑↓
                    </TableCell>
                    <TableCell>Brand</TableCell>
                    <TableCell>Price</TableCell>
                    <TableCell>Stock</TableCell>
                    <TableCell>Rating</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredData
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((item) => (
                      <TableRow key={item.id} className="hover:bg-gray-50 transition duration-300">
                        <TableCell className="border-b border-gray-300 p-4">
                          {item.category}
                        </TableCell>
                        <TableCell className="border-b border-gray-300 p-4">{item.title}</TableCell>
                        <TableCell className="border-b border-gray-300 p-4">{item.brand}</TableCell>
                        <TableCell className="border-b border-gray-300 p-4">
                          ${item.price}
                        </TableCell>
                        <TableCell className="border-b border-gray-300 p-4">{item.stock}</TableCell>
                        <TableCell className="border-b border-gray-300 p-4">
                          {item.rating}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>

            {filteredData.length === 0 ? (
              <Typography className="text-red-500">No Match Found</Typography>
            ) : null}

            <GridPagination
              page={page}
              totalPages={totalPages}
              rowsPerPage={rowsPerPage}
              handleRowsPerPageChange={handleRowsPerPageChange}
              handleNext={handleNext}
              handlePrevious={handlePrevious}
            />
          </>
        )}
      </div>
    </>
  );
};

export default CustomGrid;

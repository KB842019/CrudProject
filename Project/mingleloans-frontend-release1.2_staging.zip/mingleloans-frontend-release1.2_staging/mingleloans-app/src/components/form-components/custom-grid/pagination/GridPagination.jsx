// PaginationComponent.js
import React from 'react';

import { Box, Button, Select, MenuItem, Typography } from '@mui/material';

const GridPagination = ({
  page,
  totalPages,
  rowsPerPage,
  handleRowsPerPageChange,
  handleNext,
  handlePrevious,
}) => (
  <Box p={2} display="flex" justifyContent="space-between" alignItems="center">
    <Typography variant="body1">
      Showing {page + 1} of {totalPages}
    </Typography>

    <Box display="flex" alignItems="center" gap={2}>
      <Typography variant="body2">Show</Typography>
      <Select size="small" value={rowsPerPage} onChange={handleRowsPerPageChange}>
        <MenuItem value={5}>5</MenuItem>
        <MenuItem value={10}>10</MenuItem>
        <MenuItem value={15}>15</MenuItem>
        <MenuItem value={20}>20</MenuItem>
      </Select>
    </Box>

    <Box display="flex" gap={2}>
      <Button onClick={handlePrevious} disabled={page === 0}>
        Previous
      </Button>
      <span className="mt-2 font-bold bg-slate-300 px-4 py-2 rounded flex justify-center items-center">
        {page + 1}
      </span>
      <Button onClick={handleNext} disabled={page >= totalPages - 1}>
        Next
      </Button>
    </Box>
  </Box>
);

export default GridPagination;

import React, { useState, useEffect } from 'react';

import { applyPadding } from 'src/utils/stringUtils';

const ReverseTimer = ({ minutes, onZeroTimeLeft }) => {
  // Convert minutes in secods
  const [remainingTimeInSecs, setTime] = useState(minutes * 60);

  // Timer to update the time
  useEffect(() => {
    // Start the interval to decrease time every second
    const timer = setInterval(() => {
      setTime((prevTime) => {
        // Stop the timer if remaining time reaches 0
        if (prevTime <= 0) {
          clearInterval(timer); // Stop the timer
          onZeroTimeLeft();

          return 0; // Ensure the time stays at 0
        }
        return prevTime - 1; // Decrement the time
      });
    }, 1000);

    return () => clearInterval(timer); // Cleanup interval on unmount or reset
  }, [onZeroTimeLeft]);

  // Format the time for display purpose
  const getFormattedTime = (time) => {
    const mins = Math.floor(time / 60);
    const secs = time % 60;
    return `${applyPadding(mins)}:${applyPadding(secs)} mins left`;
  };

  return <>{getFormattedTime(remainingTimeInSecs)}</>;
};

export default ReverseTimer;

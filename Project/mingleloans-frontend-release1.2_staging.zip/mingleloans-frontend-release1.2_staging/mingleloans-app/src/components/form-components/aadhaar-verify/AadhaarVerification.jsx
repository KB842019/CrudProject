
/* eslint-disable import/no-unresolved */
import * as Yup from 'yup';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
// import Iconify from '@components/mui-components/iconify/iconify';
import React, { useRef, useMemo, useState, useEffect } from 'react';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import { LoadingButton } from '@mui/lab';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Link, Button, Dialog, DialogTitle, DialogActions, DialogContent } from '@mui/material';

import aadhaar from 'src/assets/images/shared/aadhaar.png';
import useApplyLoanStore from 'src/store/loan-store/LoanStore';
// import LockIcon from '@mui/icons-material/Lock';
// import WarningIcon from '@mui/icons-material/Warning';

export default function AadhaarVerification() {
  const { setPersonalInfo, setIsAadhaarVefified } = useApplyLoanStore((state) => state);
  const [showOTP, setShowOTP] = useState(false);
  const [timer, setTimer] = useState(600);
  const [openDialog, setOpenDialog] = useState(false);
  const [otpError, setOtpError] = useState('');
  const [otpEmptyError, setOtpEmptyError] = useState('');
  const otpRefs = useRef([]);

  const aadhaarFormSchema = Yup.object().shape({
    aadhaarNumber: Yup.string()
      .required('Aadhaar number is required')
      .matches(/^\d{12}$/, 'Aadhaar number must be 12 digits'),
    authorization: Yup.boolean().oneOf([true], 'You must authorize MingleLoans.com'),
  });

  const defaultValues = useMemo(
    () => ({
      aadhaarNumber: '',
      authorization: false,
      otp: Array(6).fill(''),
    }),
    []
  );

  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: yupResolver(aadhaarFormSchema),
    defaultValues,
  });

  useEffect(() => {
    let interval;
    if (showOTP) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [showOTP]);

  useEffect(() => {
    if (timer === 0) {
      reset(defaultValues);
      setShowOTP(false);
      setTimer(600); // Reset timer to 10 minutes
    }
  }, [timer, reset, defaultValues]);

  const onSubmit = async (formData) => {
    try {
      setShowOTP(true); // Show OTP input fields
    } catch (error) {
      console.error(error);
    }
  };

  const verifyOTP = async (formData) => {
    try {
      const enteredOTP = formData.otp.join('');
      const demoOTP = '123456'; // Demo OTP for verification

      if (formData.otp.some((otp) => otp === '')) {
        setOtpEmptyError('Please enter the OTP');
      } else if (enteredOTP !== demoOTP) {
        setOtpEmptyError('');
        setOtpError('Incorrect OTP entered');
      } else {
        // console.log('wvjsde');
        setOtpEmptyError('');
        setOtpError('');
        setPersonalInfo(formData);
        setIsAadhaarVefified(true);
        // handleNext();
      }
    } catch (error) {
      console.error('Error verifying OTP:', error);
    }
  };

  const handleFormSubmit = async (formData) => {
    if (showOTP) {
      await verifyOTP(formData);
    } else {
      await onSubmit(formData);
    }
  };

  const handleOtpChange = (e, index) => {
    const { value } = e.target;
    if (/^\d$/.test(value)) {
      setOtpError('');
      otpRefs.current[index].value = value;
      if (index < 5) {
        otpRefs.current[index + 1]?.focus();
      } else {
        otpRefs.current[index].blur();
      }
    } else if (value.length > 1) {
      setOtpError('Each OTP box can only contain one digit');
    } else if (value === '' && index > 0) {
      setOtpError('');
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleKeyDown = (e, index) => {
    if (e.key === 'Backspace' && index > 0 && e.target.value.length === 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  const handleDialogOpen = () => {
    setOpenDialog(true);
  };

  const handleDialogClose = () => {
    setOpenDialog(false);
  };

  return (
    <Box
      sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', paddingTop: '30px' }}
    >
      <Stack
        // spacing={2}
        sx={{
          width: '100%',
          maxWidth: 450,
          padding: 3,
          border: '1px solid #dddddd',
          borderRadius: 2,
          boxShadow: '0 8px 16px rgba(0, 0, 0, 0.2)',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Stack direction="column" alignItems="center" spacing={1}>
          {/* <Iconify icon="eva:email-outline" width={80} /> */}
          <Typography variant="h6" sx={{ textDecoration: 'underline' }}>
            Aadhaar Card Verification
          </Typography>
          <img src={aadhaar} width={140} alt="Aadhaar Card Verification" />
        </Stack>
        <Box sx={{ height: 30 }} />
        <form onSubmit={handleSubmit(handleFormSubmit)} style={{ width: '100%' }}>
          <Stack alignItems="center">
            <TextField
              {...register('aadhaarNumber')}
              label="Enter Your Aadhaar Number"
              fullWidth
              variant="outlined"
              margin="normal"
              error={!!errors.aadhaarNumber}
              helperText={errors.aadhaarNumber?.message}
            />

            {showOTP && (
              <Stack spacing={1} alignItems="center">
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    width: '100%',
                    justifyContent: 'space-between',
                  }}
                >
                  <Typography variant="body1" left={0}>
                    Enter OTP
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Time remaining: {Math.floor(timer / 60)}:
                    {timer % 60 < 10 ? `0${timer % 60}` : timer % 60}
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', gap: 2.7 }}>
                  {Array.from({ length: 6 }).map((_, index) => (
                    <Controller
                      key={index}
                      name={`otp.${index}`}
                      control={control}
                      render={({ field }) => (
                        <TextField
                          {...field}
                          inputProps={{
                            maxLength: 1,
                            pattern: '[0-9]*',
                            style: { textAlign: 'center' },
                          }}
                          onChange={(e) => {
                            field.onChange(e);
                            handleOtpChange(e, index);
                          }}
                          onKeyDown={(e) => handleKeyDown(e, index)}
                          inputRef={(el) => {
                            otpRefs.current[index] = el;
                          }}
                          sx={{ width: 48, border: '.5px solid grey', borderRadius: '10px' }}
                          type="text"
                        />
                      )}
                    />
                  ))}
                </Box>
                {otpError && <Typography color="error">{otpError}</Typography>}
                {otpEmptyError && <Typography color="error">{otpEmptyError}</Typography>}
              </Stack>
            )}
            <FormControlLabel
              control={<Checkbox {...register('authorization')} color="primary" />}
              label={
                <>
                  I authorize{' '}
                  <Link component="button" onClick={handleDialogOpen}>
                    MingleLoans.com
                  </Link>{' '}
                  to get my Aadhaar details
                </>
              }
            />
            {errors.authorization && (
              <Typography color="error">{errors.authorization.message}</Typography>
            )}
            <LoadingButton
              fullWidth
              color="primary"
              variant="contained"
              type="submit"
              disabled={isSubmitting}
              sx={{ height: 45 }}
            >
              {showOTP ? 'Verify OTP' : 'Send request'}
            </LoadingButton>
          </Stack>
        </form>
        <Box />

        <Stack direction="row" alignItems="center" spacing={1} sx={{ marginTop: '5px' }}>
          {/* <Stack direction="column" alignItems="center"></Stack> */}
          <Stack direction="column" alignItems="center">
            <Typography variant="caption" textAlign="center">
              <span style={{ marginRight: '2px' }}>⚠️</span> Disclaimer: We need your Aadhaar
              details to process your loan as per government rules. Your details are safe with us.
            </Typography>
          </Stack>
        </Stack>
      </Stack>

      <Dialog open={openDialog} onClose={handleDialogClose}>
        <DialogTitle>Purpose of Aadhaar Verification</DialogTitle>
        <DialogContent>
          <Typography variant="body1" gutterBottom>
            To provide you with superior service and comply with regulatory requirements,
            MingleLoans, as an intermediary for banks and NBFCs, needs to verify your Aadhaar
            details. Please review the following consent form carefully and indicate your agreement.
          </Typography>
          <Typography variant="h6" gutterBottom>
            Consent for Aadhaar Verification
          </Typography>
          <Typography variant="body2" gutterBottom>
            <strong>Usage of Aadhaar Information:</strong>
            <ul>
              <li>
                Your Aadhaar number will be utilized to verify your identity as part of the
                MingleLoans service process, which includes facilitating loan applications with our
                partner banks and NBFCs.
              </li>
              <li>
                Your Aadhaar information will be used exclusively for identity verification and will
                not be shared with any third parties without your explicit consent.
              </li>
              <li>
                As part of the verification process, you will receive an OTP (One-Time Password)
                from UIDAI on your registered mobile number. This OTP will be used to authenticate
                your identity.
              </li>
            </ul>
          </Typography>
          <Typography variant="body2" gutterBottom>
            <strong>Data Security:</strong>
            <ul>
              <li>
                MingleLoans is committed to ensuring the highest level of security for your Aadhaar
                information. Your data will be stored securely and handled with the utmost care to
                prevent unauthorized access.
              </li>
            </ul>
          </Typography>
          <Typography variant="body2" gutterBottom>
            <strong>Consent Agreement:</strong> By checking the box below and providing the OTP sent
            by UIDAI, you agree to the terms and conditions outlined above regarding the use of your
            Aadhaar information for verification purposes by MingleLoans.
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}

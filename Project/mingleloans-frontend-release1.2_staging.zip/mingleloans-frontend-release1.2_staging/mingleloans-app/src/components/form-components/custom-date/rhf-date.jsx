import PropTypes from 'prop-types';
import { Controller, useFormContext } from 'react-hook-form';

import TextField from '@mui/material/TextField';

export default function RHFDateField({ name, helperText, placeholder = 'dd-mm-yyyy', ...other }) {
  const { control } = useFormContext();

  return (
    <Controller
      name={name}
      control={control}
      render={({ field, fieldState: { error } }) => (
        <TextField
          {...field}
          fullWidth
          type="text"
          onChange={(event) => {
            const { value } = event.target;
            // Allow only valid date-like input
            if (/^\d{0,2}(-\d{0,2}){0,1}(-\d{0,4})?$/.test(value)) {
              field.onChange(value);
            }
          }}
          error={!!error}
          placeholder={placeholder} // Placeholder is visible when label is not floating
          {...other}
          // InputLabelProps={{
          //   shrink: field.value !== undefined && field.value !== '', // Shrink label only if there is a value or field is focused
          // }}
          helperText={error ? error.message : helperText} // Show error or helper text
        />
      )}
    />
  );
}

RHFDateField.propTypes = {
  helperText: PropTypes.string,
  name: PropTypes.string.isRequired,
  placeholder: PropTypes.string,
};

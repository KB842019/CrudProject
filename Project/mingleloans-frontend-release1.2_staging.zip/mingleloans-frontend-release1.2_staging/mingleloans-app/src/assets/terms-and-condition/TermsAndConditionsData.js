export const TermsAndConditionsData = [
  {
    title: 'Eligibility',
    content:
      'You must be at least 18 years old to register and apply for a loan through MingleLoans.',
  },
  {
    title: 'Accuracy of Information',
    content:
      'You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete. MingleLoans reserves the right to suspend or terminate your account if any information provided during the registration process or thereafter proves to be inaccurate, not current, or incomplete.',
  },
  {
    title: 'Account Security',
    content:
      'You are responsible for maintaining the confidentiality of your login credentials and are fully responsible for all activities that occur under your account. You agree to immediately notify MingleLoans of any unauthorized use, or suspected unauthorized use, of your account or any other breach of security.',
  },
  {
    title: 'Use of Services',
    content:
      'MingleLoans is an intermediary platform that facilitates loan applications between you and financial institutions such as banks and NBFCs. We do not provide loans ourselves. Your use of the MingleLoans platform is at your own risk, and MingleLoans is not responsible for any decisions made by financial institutions.',
  },
  {
    title: 'Application Processing',
    content:
      'Submitting a loan application does not guarantee loan approval. The approval and terms of any loan are determined solely by the financial institutions to which you apply.',
  },
  {
    title: 'Fees',
    content:
      'MingleLoans does not charge users for registration or for applying for loans. However, financial institutions may have their own fees and charges, which will be communicated to you during the loan application process.',
  },
  {
    title: 'Changes to Terms',
    content:
      'MingleLoans reserves the right to modify these terms at any time. We will notify you of any changes by posting the new terms on the site. Your continued use of the platform after such changes constitutes your acceptance of the new terms.',
  },
];

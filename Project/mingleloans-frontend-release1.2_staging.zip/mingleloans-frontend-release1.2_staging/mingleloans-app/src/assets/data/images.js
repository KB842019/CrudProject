import IMG1 from '../images/shared/1.jpg';
import IMG2 from '../images/shared/loanmela1.jpg';

export const images = {
  IMG1,
  IMG2,
};

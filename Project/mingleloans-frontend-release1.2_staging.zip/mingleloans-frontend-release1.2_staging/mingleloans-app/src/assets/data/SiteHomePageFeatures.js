import HomeLoan from '@images/shared/home-loan.png';
import WorkWithUsImg1 from '@images/shared/img1.png';
import WorkWithUsImg2 from '@images/shared/img2.png';
import WorkWithUsImg3 from '@images/shared/img3.png';
import WorkWithUsImg4 from '@images/shared/img4.png';
import BalanceTransfer from '@images/shared/BT 1.png';
import OverDraft from '@images/shared/over-draft.png';
import BusinessLoan from '@images/shared/business-loan.png';
import MortgageLoan from '@images/shared/mortgage-loan.png';
import PersonalLoan from '@images/shared/personal-loan.png';
import Image1 from '@images/shared/banner mingleloans Final 1.png';
import Image2 from '@images/shared/Banner mingleloans Final 2.png';
import Image3 from '@images/shared/banner mingleloans Final 3.jpg';
import Image4 from '@images/shared/banner mingleloans Final 4.png';
import Image5 from '@images/shared/banner mingleloans Final 5.jpg';
import Image6 from '@images/shared/banner mingleloans Final 6.jpg';
import Image7 from '@images/shared/banner mingleloans 7 Final.jpg';

export const chooseMingleloans = [
  {
    title: 'Affordable Rates',
    desc: 'MingleLoans negotiates with multiple banks and NBFCs to offer you the most competitive interest rates available.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'Instant Approval',
    desc: 'Our efficient approval process ensures you receive a decision within minutes, saving you time and reducing stress.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'CIBIL Monitoring',
    desc: 'We monitor your CIBIL score and offer guidance on how to improve it, enhancing your eligibility for better loan terms.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'Seamless Process',
    desc: 'From application to disbursement, our process is designed to be smooth and hassle-free, with continuous expert support at every step.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'Repayment Terms',
    desc: 'We provide flexible repayment options tailored to your financial situation, making it easier to manage your loan.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'Expert Guidance',
    desc: 'Each customer is assigned a dedicated expert who provides free guidance throughout the loan process, from application to disbursement.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'Special Discount',
    desc: 'MingleLoans occasionally offers special loans and discounts, providing additional value and savings for our customers.',
    animation: 'zoom-in',
    duration: '1200',
  },
  {
    title: 'Tailored for All',
    desc: 'Whether you are a salaried individual or self-employed, MingleLoans has tailored loan solutions to meet your specific financial needs.',
    animation: 'zoom-in',
    duration: '1200',
  },
];

export const workWithUs = [
  {
    img: WorkWithUsImg1,
    name: 'Smooth Loans',
    animation: 'zoom-in',
    duration: '700',
  },
  {
    img: WorkWithUsImg2,
    name: 'Low Interests',
    animation: 'zoom-in',
    duration: '500',
  },
  {
    img: WorkWithUsImg3,
    name: 'Speedy Approval',
    animation: 'zoom-in',
    duration: '500',
  },
  {
    img: WorkWithUsImg4,
    name: 'Online Funding',
    animation: 'zoom-in',
    duration: '7000',
  },
];

export const BenefitsItems = [
  {
    number: 1,
    title: 'Dedicated Support',
    desc: 'Each customer receives one-on-one attention from a dedicated expert.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Personalized Solutions',
    desc: 'Tailored loan options and financial advice based on your unique needs.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Ease and Convenience',
    desc: 'Simplified application process with expert assistance at every step.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Quick Approval',
    desc: 'Streamlined process to ensure fast loan approval and disbursement.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Continuous Guidance',
    desc: 'Ongoing support even after loan disbursement for effective financial management.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const serviceCard = [
  {
    icon: HomeLoan,
    name: 'Home Loan',
    animation: 'zoom-in',
    duration: '800',
  },
  {
    icon: PersonalLoan,
    name: 'Personal Loan',
    animation: 'zoom-in',
    duration: '800',
  },
  {
    icon: BusinessLoan,
    name: 'Business Loan',
    animation: 'zoom-in',
    duration: '800',
  },
  {
    icon: BalanceTransfer,
    name: 'Balance Transfer',
    animation: 'zoom-in',
    duration: '800',
  },
  {
    icon: MortgageLoan,
    name: 'Mortgage Loan',
    animation: 'zoom-in',
    duration: '800',
  },
  {
    icon: OverDraft,
    name: 'OverDraft',
    animation: 'zoom-in',
    duration: '800',
  },
];

export const shapes = [
  {
    top: '-2.4rem',
    left: '0',
    width: '35px',
    height: '35px',
    backgroundColor: '#CF8080',
    borderRadius: '50% 50% 50% 0%',
  },
  {
    top: '-1.5rem',
    left: '-1.6rem',
    width: '20px',
    height: '20px',
    backgroundColor: '#B23333',
    borderRadius: '50% 50% 0% 50%',
  },
  {
    top: '0',
    left: '-3.5rem',
    width: '50px',
    height: '50px',
    backgroundColor: '#B23333',
    borderRadius: '50% 0 50% 50%',
  },
];

export const expertService = [
  {
    serviceName: 'Initial Consultation',
    list: [
      'When you first approach MingleLoans, you are assigned a dedicated expert who will understand your financial needs and goals.',
      'During the initial consultation, the expert gathers information about your financial situation, preferences, and loan requirements.',
    ],
  },
  {
    serviceName: 'Personalized Guidance',
    list: [
      'Based on the information collected, your expert provides personalized loan options that best suit your needs.',
      'They explain the terms, interest rates, and repayment plans for each loan option, helping you make an informed decision.',
    ],
  },
  {
    serviceName: 'CIBIL Monitoring and Improvement',
    list: [
      'Your expert monitors your CIBIL score and provides actionable advice to improve it if necessary.',
      'They guide you on how to maintain a good credit score to ensure better loan terms and approval chances.',
    ],
  },
  {
    serviceName: 'Application Assistance',
    list: [
      'The expert assists you in filling out the loan application accurately and gathering all required documents.',
      'They ensure that the application process is smooth and that all necessary paperwork is completed without any hassle.',
    ],
  },
  {
    serviceName: 'Instant Approval and Follow-Up',
    list: [
      'Once the application is submitted, the expert keeps track of the approval process and provides you with updates.',
      'They work to expedite the approval, ensuring that you get a response as quickly as possible.',
    ],
  },
  {
    serviceName: 'Support Until Disbursement',
    list: [
      'After approval, your expert helps you understand the disbursement process and what to expect next.',
      'They remain available to answer any questions and resolve any issues that may arise until the loan is disbursed into your account.',
    ],
  },
  {
    serviceName: 'Ongoing Support',
    list: [
      'Even after the loan is disbursed, your expert continues to offer support. They provide advice on managing repayments and maintaining financial health.',
      'If you need additional services or have any concerns, your expert is always ready to assist.',
    ],
  },
];

export const choosePersonalLoan = [
  {
    title: 'Home Renovation',
    desc: "A personal loan can help you finance home improvements, giving you the means to create the living space you've always wanted. Whether it's a kitchen remodel, new furniture, or a fresh coat of paint, a personal loan ensures you don't have to wait to turn your house into your dream home.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Debt Consolidation',
    desc: 'Managing multiple debts can be overwhelming. A personal loan allows you to consolidate your debts into a single, manageable payment, often at a lower interest rate. This simplifies your finances and can save you money in the long run.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Education',
    desc: "Whether you want to further your education or support your child's academic goals, a personal loan can cover tuition fees, purchase study materials, or pay for educational courses.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Emergency Expenses',
    desc: 'Life is unpredictable, and unexpected expenses can arise at any time. A personal loan provides a safety net, allowing you to cover medical bills, car repairs, or other emergencies without financial stress.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Travel and Leisure',
    desc: "If you've been dreaming of a vacation, a personal loan can make it happen. It enables you to plan and book your trip without waiting, so you can explore the world or enjoy a much-needed break with your loved ones.",
    animation: 'fade-up',
    duration: '1200',
  },
];

export const chooseBusinessLoan = [
  {
    title: 'Expand Your Business',
    desc: "Whether you're opening a new location, hiring additional staff, or launching a new product line, our business loans provide the capital you need to grow.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Invest in Technology',
    desc: 'Stay competitive by investing in the latest technology. Our loans can help you purchase new equipment, upgrade software, or enhance your infrastructure.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Manage Cash Flow',
    desc: 'Ensure smooth operations with funds to manage working capital, pay suppliers, and cover unexpected expenses.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Seize Opportunities',
    desc: "With quick access to funds, you can take advantage of business opportunities as they arise, whether it's a bulk inventory purchase or entering a new market.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Build Business Credit',
    desc: "Regular loan repayments help build your business's credit profile, making future financing easier to secure.",
    animation: 'fade-up',
    duration: '1200',
  },
];

export const howToApplyBL = [
  {
    number: 1,
    title: 'Register and Apply Online',
    desc: 'Start by registering on our website and filling out our online application form with basic business details.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Submit Documentation',
    desc: 'Upload necessary documents like financial statements, tax returns, and proof of ownership securely on our platform.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Expert Review',
    desc: 'Our financial experts review your application and help you choose the best loan options for your business.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Loan Offer',
    desc: 'We present a customized loan offer with competitive rates and terms. Upon acceptance, we proceed with the approval process.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Disbursement',
    desc: 'Once approved, funds are quickly disbursed to your business’s bank account, ready to be used as needed.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const howToApplyPL = [
  {
    number: 1,
    title: 'Registration',
    desc: "Start by registering on the MingleLoans platform. This process is quick and easy, requiring only basic information such as your name, contact details, and employment status. Once registered, you'll have access to our range of loan products and services.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Personal Loan Application',
    desc: "After registration, you can apply for a personal loan by filling out a simple application form. You'll need to provide details such as the loan amount, the purpose of the loan, and your income information. Our platform guides you through each step, ensuring that you provide all the necessary information.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Documentation Submission',
    desc: "To process your loan application, you'll need to submit a few essential documents. These typically include proof of identity (like an Aadhaar card or PAN card), proof of income (such as salary slips or bank statements), and proof of address. Our platform allows you to upload these documents securely.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Expert Review',
    desc: 'Once your application and documents are submitted, our experts review your information to match you with the best loan options available. They consider factors such as your credit score, income, and loan amount to identify the most suitable financial institutions for your needs.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Loan Approval and Disbursement',
    desc: 'After the expert review, your loan application is forwarded to the selected financial institutions for approval. Thanks to our strong partnerships with multiple banks and NBFCs, we can expedite the approval process, often providing you with a decision within minutes. Once approved, the loan amount is disbursed directly into your bank account.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 6,
    title: 'Post-Disbursement Support',
    desc: 'Our relationship with you doesn’t end with the disbursement of funds. MingleLoans offers ongoing support to help you manage your loan repayments, address any concerns, and provide guidance on loan management strategies.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const howToApplyBT = [
  {
    number: 1,
    title: 'Initial Consultation',
    desc: 'The first step is to contact MingleLoans and schedule a consultation with one of our financial experts. During this consultation, we will review your existing loan details, including the interest rate, tenure, and outstanding balance.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Comparing Lenders',
    desc: 'Our expert will then help you compare various lenders who offer lower interest rates than your current lender. We work with a wide range of banks and financial institutions to find the best possible deal for you.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Application Submission',
    desc: "Once you've chosen a new lender, our expert will guide you through the application process. This includes gathering all the necessary documents, such as your current loan statement, proof of income, and identification documents.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Approval and Disbursement',
    desc: 'After your application is submitted, the new lender will review it and, upon approval, will disburse the loan amount to pay off your existing loan. You will then start repaying the new lender at the lower interest rate.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Post-Transfer Support',
    desc: "At MingleLoans, our support doesn't end with the disbursement of the loan. We continue to provide guidance and support throughout the tenure of your new loan, ensuring that you stay on track with your repayments.",
    animation: 'fade-up',
    duration: '1200',
  },
];

export const howToApplyOD = [
  {
    number: 1,
    title: 'Register on MingleLoans',
    desc: 'Start by creating an account on our platform. The registration process is quick, requiring only basic information to get you started. Once registered, you can begin the application process for your Overdraft Loan.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Complete the Application Form',
    desc: "Our easy-to-navigate application form will ask for details about your financial situation, such as your income, existing debts, and the reason for applying for an Overdraft Loan. For businesses, we may also require information about your business's financial health.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Upload Required Documents',
    desc: 'To process your application, we’ll need certain documents, such as proof of income, bank statements, and identification. For business applicants, additional documents like financial statements or tax returns may be required. You can upload these securely through our platform.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Get Matched with Lenders',
    desc: 'MingleLoans partners with a wide network of banks and financial institutions. After reviewing your application, we’ll match you with the best lenders based on your financial profile and needs. This ensures that you receive competitive loan offers tailored to your situation.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Review and Select Loan Offers',
    desc: 'You’ll receive multiple Overdraft Loan offers from our lending partners. Each offer will include details about the interest rate, repayment terms, and any fees. You can compare these offers to find the one that best suits your needs.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 6,
    title: 'Consult with Your Dedicated Expert',
    desc: 'At MingleLoans, we provide each customer with a dedicated expert who will guide you through the loan selection process. They’ll answer any questions you have, help you understand the terms of each offer, and assist you in making the best decision.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const howToApplyML = [
  {
    number: 1,
    title: 'Register on MingleLoans',
    desc: 'Start by registering on our platform. The registration process is quick and easy, allowing you to create an account and begin your mortgage loan application.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Complete the Application Form',
    desc: "Once registered, you'll need to fill out our mortgage loan application form. The form will ask for basic information about your employment status, income, and the property you wish to use as collateral. Our user-friendly interface ensures that you can complete the form with ease.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Upload Required Documents',
    desc: 'To process your application, we require certain documents, such as proof of income, identity verification, property details, and property ownership documents. For salaried individuals, this may include salary slips and bank statements, while self-employed individuals may need to provide financial statements and business documents. Our platform allows you to upload these documents securely.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Get Matched with Lenders',
    desc: 'After reviewing your application, MingleLoans will match you with the best lenders from our extensive network of banks and NBFCs. We consider your financial profile and property details to ensure that you receive the most suitable loan offers.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Review and Select Loan Offers',
    desc: "You'll receive multiple loan offers tailored to your needs. Each offer will include details such as interest rates, repayment terms, and any associated fees. You can compare these offers and choose the one that best fits your financial situation.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 6,
    title: 'Consult with Your Dedicated Expert',
    desc: 'At MingleLoans, we assign a dedicated expert to each customer. Your expert will guide you through the loan selection process, helping you understand the terms and make an informed decision. They will also assist with any queries or concerns you may have.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 7,
    title: 'Sign the Agreement and Receive Funds',
    desc: "Once you've selected a loan offer, you'll need to sign the loan agreement. After completing the necessary formalities, the funds will be disbursed directly to your account, enabling you to access the financial support you need.",
    animation: 'fade-up',
    duration: '1200',
  },
];

export const howToApplyHL = [
  {
    number: 1,
    title: 'Register on MingleLoans',
    desc: 'Start by registering on our platform. The registration process is quick and easy, allowing you to create an account and begin your home loan application.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 2,
    title: 'Complete the Application Form',
    desc: "Once registered, you'll need to fill out our home loan application form. The form will ask for basic information about your employment status, income, and the property you wish to purchase. Our user-friendly interface ensures that you can complete the form with ease.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 3,
    title: 'Upload Required Documents',
    desc: 'To process your application, we require certain documents, such as proof of income, identity verification, and property details. For salaried individuals, this may include salary slips and bank statements, while self-employed individuals may need to provide financial statements and business documents. Our platform allows you to upload these documents securely.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 4,
    title: 'Get Matched with Lenders',
    desc: 'After reviewing your application, MingleLoans will match you with the best lenders from our extensive network of banks and NBFCs. We consider your financial profile and property details to ensure that you receive the most suitable loan offers.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 5,
    title: 'Review and Select Loan Offers',
    desc: "You'll receive multiple loan offers tailored to your needs. Each offer will include details such as interest rates, repayment terms, and any associated fees. You can compare these offers and choose the one that best fits your financial situation.",
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 6,
    title: 'Consult with Your Dedicated Expert',
    desc: 'At MingleLoans, we assign a dedicated expert to each customer. Your expert will guide you through the loan selection process, helping you understand the terms and make an informed decision. They will also assist with any queries or concerns you may have.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    number: 7,
    title: 'Sign the Agreement and Receive Funds',
    desc: "Once you've selected a loan offer, you'll need to sign the loan agreement. After completing the necessary formalities, the funds will be disbursed directly to your account, enabling you to move forward with your home purchase.",
    animation: 'fade-up',
    duration: '1000',
  },
];

export const balanceTransferEligibleCriteria = [
  {
    title: 'Current Loan Tenure',
    desc: 'The remaining tenure of your current loan should be sufficient for the new lender to offer a balance transfer. Typically, lenders prefer loans with at least 12 months of remaining tenure.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Loan Repayment History',
    desc: ' You should have a good repayment history with your current lender, with no missed payments or defaults. A positive credit history increases your chances of approval for a balance transfer.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Income Stability',
    desc: 'Lenders will also assess your income stability to ensure that you can manage the repayments on the new loan. This typically involves providing proof of income, such as salary slips, bank statements, or tax returns.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Loan Amount',
    desc: 'The outstanding balance on your current loan should fall within the limits set by the new lender for balance transfers. Different lenders may have different criteria for the minimum and maximum loan amounts eligible for transfer.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'CIBIL Score',
    desc: ' A good CIBIL score is crucial for getting approval for a balance transfer. Most lenders require a CIBIL score of 700 or above for balance transfer loans.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const businessLoanEligibleCriteria = [
  {
    title: 'Business Age',
    desc: 'Operational for at least 1-2 years.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Annual Revenue',
    desc: ' Meet minimum revenue requirements.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Credit Score',
    desc: 'A good business credit score is advantageous but not the only consideration',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Profitability',
    desc: 'Demonstrated profitability or a clear path to it',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Collateral',
    desc: ' Depending on the loan type, collateral may be required',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Business Plan',
    desc: 'A solid business plan that outlines goals and financial projections',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const personalLoanEligibleCriteria = [
  {
    title: 'Age',
    desc: ' Applicants should be between 21 and 60 years of age. This ensures that the borrower is in an active working phase, capable of repaying the loan.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Employment Status',
    desc: ' You must be a salaried employee with a minimum of two years of work experience. Consistent employment history enhances your chances of loan approval and helps secure better loan terms.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Income',
    desc: ' A minimum monthly income of ₹15,000 is required. This ensures that you have sufficient financial resources to manage your loan repayments alongside other expenses.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Credit Score',
    desc: ' A credit score of 650 or above is typically required. A higher credit score not only increases your chances of loan approval but can also help you secure lower interest rates.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Residence',
    desc: ' Applicants should have a stable residential address. Some financial institutions may require proof of residence at the current address for a minimum of one year.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Bank Account',
    desc: ' You must have a valid bank account in your name. This is necessary for the disbursement of the loan amount and repayment installments.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const overDraftEligibleCriteria = [
  {
    heading: 'Eligibility Criteria for Individuals',
    cardDetail: [
      {
        title: 'Age',
        desc: 'Applicants must typically be between 21 and 60 years old.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Income',
        desc: 'A stable income is required. The minimum income level may vary depending on the loan amount and lender requirements.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Bank Account',
        desc: ' You must have an existing bank account with a history of regular transactions. Some lenders may also require a minimum balance.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Credit Score',
        desc: 'A good credit score is important for securing favorable terms on your Overdraft Loan. However, MingleLoans works with a variety of lenders, some of whom may offer loans to individuals with lower credit scores.',
        animation: 'fade-up',
        duration: '1200',
      },
    ],
  },
  {
    heading: 'Eligibility Criteria for Businesses',
    cardDetail: [
      {
        title: 'Age',
        desc: 'Your business should typically be operational for at least 2-3 years.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Annual Turnover',
        desc: 'Lenders may require a minimum annual turnover, which varies depending on the loan amount and business type.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Bank Account',
        desc: 'Your business should have a current account with regular transaction history.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Creditworthiness',
        desc: 'The creditworthiness of your business, as well as its financial stability, will be assessed by the lender.',
        animation: 'fade-up',
        duration: '1200',
      },
    ],
  },
];

export const mortgageLoanEligibleCriteria = [
  {
    heading: 'Eligibility Criteria for Salaried Individuals',
    cardDetail: [
      {
        title: 'Age',
        desc: 'Applicants should typically be between 21 and 65 years old at the time of loan maturity.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Income',
        desc: 'A stable income is required, with a minimum monthly income depending on the loan amount and the value of the property.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Employment Status',
        desc: 'You should have a minimum of 2-3 years of continuous employment with a reputable organization.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Credit Score',
        desc: 'A good credit score is essential to secure favorable loan terms. Most lenders require a minimum credit score, which will be assessed during the application process.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Property',
        desc: "The property should meet the lender's specifications, be free from legal encumbrances, and have sufficient value to cover the loan amount.",
        animation: 'fade-up',
        duration: '1200',
      },
    ],
  },
  {
    heading: 'Eligibility Criteria for Self-Employed Individuals',
    cardDetail: [
      {
        title: 'Age',
        desc: 'Applicants should typically be between 21 and 70 years old at the time of loan maturity.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Income',
        desc: 'A consistent income flow is required, which will be evaluated based on your financial statements, business turnover, and profit margins.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Business Stability',
        desc: 'You should have at least 3-5 years of experience in your current business or profession.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Credit Score',
        desc: 'A good credit score is important for securing a home loan. Lenders may have varying minimum score requirements.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Property',
        desc: "The property should meet the lender's guidelines, must be legally clear, and should have adequate value.",
        animation: 'fade-up',
        duration: '1200',
      },
    ],
  },
];

export const homeLoanEligibleCriteria = [
  {
    heading: 'Eligibility Criteria for Salaried Individuals',
    cardDetail: [
      {
        title: 'Age',
        desc: 'Applicants should typically be between 21 and 65 years old at the time of loan maturity.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Income',
        desc: 'A stable income is required, with a minimum monthly income depending on the loan amount and location of the property.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Employment Status',
        desc: 'You should have a minimum of 2-3 years of continuous employment with a reputable organization.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Credit Score',
        desc: 'A good credit score is essential to secure favorable loan terms. Most lenders require a minimum credit score, which will be assessed during the application process.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Property',
        desc: "The property should meet the lender's specifications and should be free from legal encumbrances.",
        animation: 'fade-up',
        duration: '1200',
      },
    ],
  },
  {
    heading: 'Eligibility Criteria for Self-Employed Individuals',
    cardDetail: [
      {
        title: 'Age',
        desc: 'Applicants should typically be between 21 and 70 years old at the time of loan maturity.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Income',
        desc: 'A consistent income flow is required, which will be evaluated based on your financial statements, business turnover, and profit margins.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Business Stability',
        desc: 'You should have at least 3-5 years of experience in your current business or profession.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Credit Score',
        desc: 'A good credit score is important for securing a home loan. Lenders may have varying minimum score requirements.',
        animation: 'fade-up',
        duration: '1200',
      },
      {
        title: 'Property',
        desc: "The property should meet the lender's guidelines and must be legally clear.",
        animation: 'fade-up',
        duration: '1200',
      },
    ],
  },
];

export const overDraftFacility = [
  {
    title: 'Accessing Funds',
    desc: 'Once your overdraft facility is approved, you can access funds as and when needed, up to the approved limit. The flexibility of the overdraft account allows you to withdraw any amount within this limit without having to go through a new loan application process each time.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Interest Calculation',
    desc: 'Interest is charged only on the amount you withdraw, not on the total overdraft limit. This makes it a cost-effective solution for managing your short-term financial needs.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Daily Interest Calculation',
    desc: 'Interest on the withdrawn amount is calculated on a daily basis. This means that if you repay the withdrawn amount quickly, your interest cost will be minimized.',
    animation: 'fade-up',
    duration: '1200',
  },
  {
    title: 'Easy Repayment',
    desc: 'You can repay the withdrawn amount at any time during the tenure. As soon as you deposit money back into your OD account, the interest stops accruing. This flexible repayment option allows you to manage your cash flow effectively.',
    animation: 'fade-up',
    duration: '1200',
  },
];

export const whyContactUs = [
  {
    title: 'Expert Guidance',
    desc: 'Our team of financial experts is here to guide you through every step of your loan journey, offering personalized advice and support.',
  },
  {
    title: 'Quick Response',
    desc: 'We prioritize your needs and strive to respond to all enquiries promptly.',
  },
  {
    title: 'Comprehensive Support',
    desc: 'From initial enquiry to loan disbursement and beyond, we’re with you every step of the way.',
  },
];

export const howWeBenefitYou = [
  {
    title: 'Wide Selection of Loan Products',
    desc: 'MingleLoans has established partnerships with multiple banks and NBFCs, giving you access to a broad spectrum of loan products. Whether you need a small personal loan or a large mortgage, we have the options to meet your needs.',
    animation: 'fade-right',
    duration: '1200',
  },
  {
    title: 'Expert Guidance',
    desc: 'Navigating the loan market can be complex, with numerous options, terms, and conditions to consider. At MingleLoans, each customer is assigned a dedicated expert who provides personalized guidance throughout the entire loan process. Our experts are well-versed in the nuances of different loan products and financial institutions, ensuring that you receive the best possible advice.',
    animation: 'fade-left',
    duration: '1200',
  },
  {
    title: 'Negotiation Power',
    desc: 'One of the key advantages of working with MingleLoans is our ability to negotiate on your behalf. Because we work with multiple financial institutions, we can leverage our relationships to secure better interest rates, lower fees, and more favorable repayment terms for you.',
    animation: 'fade-right',
    duration: '1200',
  },
  {
    title: 'Streamlined Process',
    desc: 'Applying for a loan can be time-consuming and stressful. MingleLoans simplifies the process by handling all the paperwork, coordinating with financial institutions, and ensuring that your application is processed smoothly and efficiently. Our goal is to make the loan application process as hassle-free as possible.',
    animation: 'fade-left',
    duration: '1200',
  },
  {
    title: 'Customer-Centric Approach',
    desc: 'At MingleLoans, your satisfaction is our top priority. We take the time to understand your financial goals and work tirelessly to help you achieve them. Whether you’re looking to finance a new home, expand your business, or cover unexpected expenses, we’re here to support you every step of the way.',
    animation: 'fade-right',
    duration: '1200',
  },
];

export const howItWorks = [
  {
    number: '1',
    title: 'Customer Registration',
    desc: 'The first step in the MingleLoans process is to register on our platform. By creating an account, you gain access to a wide range of financial services and can easily apply for your desired loan. The registration process is quick and straightforward, ensuring that you can start exploring your loan options in no time.',
    animation: 'fade-right',
    duration: '1200',
  },
  {
    number: '2',
    title: 'Initial Consultation',
    desc: 'Once registered, you will be contacted by one of our experts for an initial consultation. During this consultation, we’ll discuss your financial needs, goals, and preferences. We’ll also review your financial profile, including your income, credit score, and any existing debts.',
    animation: 'fade-left',
    duration: '1200',
  },
  {
    number: '3',
    title: 'Loan Matching',
    desc: 'Based on the information gathered during the consultation, our expert will match you with the most suitable loan options from our partner banks and NBFCs. We’ll present you with a shortlist of loan products that best meet your needs, along with detailed information on interest rates, repayment terms, and any applicable fees.',
    animation: 'fade-right',
    duration: '1200',
  },
  {
    number: '4',
    title: 'Application Submission',
    desc: 'Once you’ve selected a loan product, we’ll assist you in preparing and submitting your application. This includes gathering the necessary documentation, completing the required forms, and submitting everything to the financial institution on your behalf.',
    animation: 'fade-left',
    duration: '1200',
  },
  {
    number: '5',
    title: 'Negotiation and Approval',
    desc: 'After your application is submitted, MingleLoans takes on the role of negotiator. We’ll work with the financial institution to ensure that you receive the best possible terms. Our team will keep you informed throughout the approval process, providing updates and answering any questions you may have.',
    animation: 'fade-right',
    duration: '1200',
  },
  {
    number: '6',
    title: 'Loan Disbursement',
    desc: 'Once your loan is approved, we’ll guide you through the disbursement process, ensuring that the funds are transferred to your account without any delays. We’ll also provide you with all the necessary information on how to manage your loan repayments.',
    animation: 'fade-left',
    duration: '1200',
  },
  {
    number: '7',
    title: 'Post-Disbursement Support',
    desc: 'Our commitment to you doesn’t end once your loan is disbursed. MingleLoans provides ongoing support to help you manage your loan effectively. Whether you need assistance with repayments, refinancing, or understanding your loan terms, our experts are always available to help.',
    animation: 'fade-right',
    duration: '1200',
  },
];

export const FAQHomePage = [
  {
    question: 'What types of loans does MingleLoans offer?',
    answer:
      'MingleLoans offers a variety of loans including Personal Loans, Business Loans, Home Loans, Overdraft Facilities, Mortgage Loans, Education Loans, and more.',
  },
  {
    question: 'How can I apply for a loan with MingleLoans?',
    answer:
      'You can apply for a loan by visiting our website, filling out the online application form, and submitting the required documents. Alternatively, you can contact our customer service for assistance.',
  },
  {
    question: 'How does MingleLoans help improve my CIBIL score?',
    answer:
      'Our experts monitor your CIBIL score and provide guidance on how to improve it. This may include advice on timely repayments, reducing outstanding debt, and maintaining a healthy credit mix.',
  },
  {
    question: 'Is there any fee for consulting with an expert?',
    answer:
      'No, MingleLoans provides free expert guidance to all customers. Each customer is assigned a dedicated expert to assist them throughout the loan process at no additional cost.',
  },
  {
    question: 'Can I refinance or transfer my existing loan to another bank with MingleLoans?',
    answer:
      'Yes, we offer balance transfer options to help you refinance your existing loans at lower interest rates. Our experts will guide you through the process to make it seamless and beneficial for you.',
  },
  {
    question: 'How can I track my loan application status?',
    answer:
      'You can track your loan application status through our website by logging into your account, or you can contact your dedicated expert for updates.',
  },
  {
    question: 'How does MingleLoans choose the best loan options for me?',
    answer:
      'MingleLoans acts as an intermediary between customers and banks or NBFCs. Based on your profile and requirements, our experts compare options from various banks and NBFCs to find the best loan solutions for you.',
  },
  {
    question: 'What is the role of MingleLoans as intermediaries?',
    answer:
      'As intermediaries, MingleLoans connects customers with banks and NBFCs, providing expert guidance to ensure you get the best possible loan options. We handle the application process, negotiations, and follow-ups on your behalf.',
  },
  {
    question:
      'Do MingleLoans provide services for both salaried individuals and self-employed persons?',
    answer:
      "Yes, we offer tailored loan solutions for both salaried individuals and self-employed persons, ensuring that each customer's unique financial needs are met.",
  },
  {
    question: 'What are the benefits of choosing MingleLoans over direct bank applications?',
    answer:
      'MingleLoans offers personalized expert guidance, a wide range of loan options from multiple banks and NBFCs, competitive interest rates, and a hassle-free application process. Our dedicated experts ensure that you get the best loan terms tailored to your needs.',
  },
  {
    question: 'How secure is my personal information with MingleLoans?',
    answer:
      'At MingleLoans, we prioritize the security and privacy of your personal information. We use advanced encryption and security measures to protect your data and ensure confidentiality.',
  },
  {
    question: 'Do you offer any special loans or discounts?',
    answer:
      'Yes, MingleLoans occasionally offers special loans and discounts for certain loan types or during promotional periods. Please check our website or contact our experts for the latest offers.',
  },
  {
    question: 'What if my loan application is rejected?',
    answer:
      'If your loan application is rejected, our experts will help you understand the reasons and provide guidance on how to improve your eligibility for future applications. We can also explore alternative loan options that might be more suitable for your profile.',
  },
  {
    question: 'How do I know which loan option is best for me?',
    answer:
      'Our dedicated experts will assess your financial situation, requirements, and preferences to recommend the best loan options. We ensure that you have all the information needed to make an informed decision.',
  },
];

export const FAQPersonalLoan = [
  {
    question: 'What is the maximum loan amount I can borrow?',
    answer:
      'The loan amount depends on your income, credit score, and the financial institution’s policies. Typically, you can borrow up to ₹50 lakhs.',
  },
  {
    question: 'How quickly can I get my loan approved?',
    answer:
      'At MingleLoans, we strive to provide instant approvals. In many cases, your loan can be approved within minutes, and the funds disbursed within 24 to 48 hours.',
  },
  {
    question: 'What is the interest rate on a personal loan?',
    answer:
      'Interest rates vary based on your credit profile, income, and the lender’s terms. Our experts will help you secure the most competitive rates available.',
  },
  {
    question: 'Can I prepay my loan?',
    answer:
      'Yes, most lenders allow prepayment of personal loans, often with minimal or no prepayment penalties. Prepaying can help you save on interest costs.',
  },
  {
    question: 'What happens if I miss a payment?',
    answer:
      'Missing a payment can result in late fees and a negative impact on your credit score. It’s essential to stay on top of your repayment schedule. If you anticipate difficulty making a payment, contact our support team for assistance.',
  },
  {
    question: 'Is my loan information confidential?',
    answer:
      'Absolutely. MingleLoans is committed to protecting your privacy and ensuring that your personal and financial information is kept secure and confidential.',
  },
];

export const FAQBusinessLoan = [
  {
    question: 'What types of business loans does MingleLoans offer?',
    answer:
      'MingleLoans offers a variety of business loans, including working capital loans, equipment financing, term loans, and business expansion loans. We work with a wide network of banks and NBFCs to provide tailored loan options.',
  },
  {
    question: 'How long does it take to get a business loan?',
    answer:
      'The time frame for getting a business loan varies depending on the lender and the complexity of your application. However, with MingleLoans, you can expect to receive loan offers within a few days of submitting your application.',
  },
  {
    question: 'What is the interest rate for business loans?',
    answer:
      "Interest rates for business loans vary based on factors such as your business's financial health, loan amount, and repayment term. Our experts will help you find the most competitive rates available.",
  },
  {
    question: 'Can I get a business loan without collateral?',
    answer:
      'Yes, MingleLoans offers both secured and unsecured business loans. Unsecured loans do not require collateral, making them a good option for businesses without significant assets.',
  },
  {
    question: 'What if I have a low credit score?',
    answer:
      'While a good credit score can help secure better loan terms, MingleLoans works with a variety of lenders, including those who offer loans to businesses with lower credit scores. Our experts will help you explore your options.',
  },
  {
    question: 'How do I repay the business loan?',
    answer:
      "Business loans are typically repaid in monthly installments over a fixed term. MingleLoans offers flexible repayment options, allowing you to choose a plan that fits your business's cash flow.",
  },
  {
    question: 'What happens if I miss a payment?',
    answer:
      "Missing a payment can result in late fees and a negative impact on your business's credit score. If you anticipate difficulty in making a payment, contact our support team for assistance.",
  },
];

export const FAQHomeLoan = [
  {
    question: 'What types of home loans does MingleLoans offer?',
    answer:
      'MingleLoans offers a variety of home loans, including loans for purchasing a new home, construction loans, home improvement loans, and plot loans. We work with a wide network of lenders to provide tailored loan options.',
  },
  {
    question: 'How long does it take to get a home loan?',
    answer:
      'The time frame for processing a home loan varies depending on the lender and the complexity of your application. Typically, you can expect to receive loan offers within a few days of submitting your application.',
  },
  {
    question: 'What is the interest rate for home loans?',
    answer:
      'Interest rates for home loans depend on several factors, including your credit score, loan amount, and repayment term. Our experts will help you find the most competitive rates available.',
  },
  {
    question: 'Can I apply for a home loan if I have a low credit score?',
    answer:
      'While a good credit score is important for securing favorable loan terms, MingleLoans works with a variety of lenders, including those who offer loans to individuals with lower credit scores. Our experts will help you explore your options.',
  },
  {
    question: 'What documents are required for a home loan?',
    answer:
      'Required documents typically include proof of income, identity verification, property details, and financial statements. Our experts will provide you with a detailed list based on your specific application.',
  },
  {
    question: 'How do I repay the home loan?',
    answer:
      'Home loans are usually repaid in monthly installments over a fixed term. MingleLoans offers flexible repayment options, allowing you to choose a plan that suits your financial situation.',
  },
  {
    question: 'What happens if I miss a payment?',
    answer:
      'Missing a payment can result in late fees and may negatively impact your credit score. If you anticipate difficulty in making a payment, contact our support team for assistance and possible solutions.',
  },
];

export const FAQBalanceTransfer = [
  {
    question: 'What is a Balance Transfer Loan?',
    answer:
      'A Balance Transfer Loan allows you to transfer your existing loan from one lender to another, typically to take advantage of a lower interest rate or better loan terms.',
  },
  {
    question: 'How much can I save with a Balance Transfer Loan?',
    answer:
      'The amount you can save depends on the difference in interest rates between your current loan and the new loan. Our experts will help you calculate the potential savings.',
  },
  {
    question: 'Is there a fee for transferring my loan?',
    answer:
      'A Balance Transfer Loan allows you to transfer your existing loan from one lender to another, typically to take advantage of a lower interest rate or better loan terms.',
  },
  {
    question: 'Can I transfer any type of loan?',
    answer:
      'Most types of loans, including personal loans, home loans, and business loans, are eligible for balance transfer. Our experts will help you determine if your loan qualifies.',
  },
  {
    question: 'How long does the balance transfer process take?',
    answer:
      'The balance transfer process typically takes 7-10 business days, depending on the lender. Our team will keep you informed throughout the process',
  },
  {
    question: 'What documents are required for a balance transfer?',
    answer:
      'Commonly required documents include your existing loan statement, proof of income, identity proof, and address proof. Our experts will guide you through the documentation process.',
  },
  {
    question: 'Can I extend the tenure of my loan during a balance transfer?',
    answer:
      'Yes, in many cases, you can negotiate a longer loan tenure with the new lender, which can further reduce your monthly EMIs.',
  },
];

export const FAQOverdraft = [
  {
    question: 'What is an Overdraft Loan?',
    answer:
      'An Overdraft Loan allows you to withdraw more money from your bank account than what is currently available, up to a pre-approved limit. It provides a financial cushion for managing short-term cash flow needs.',
  },
  {
    question: 'How is an Overdraft Loan different from a personal loan?',
    answer:
      'Unlike a personal loan, where you receive a lump sum upfront, an Overdraft Loan allows you to access funds as needed. You only pay interest on the amount you use, making it a flexible and cost-effective option for short-term financing.',
  },
  {
    question: 'What is the interest rate for an Overdraft Loan?',
    answer:
      'Interest rates for Overdraft Loans vary depending on the lender and your credit profile. Typically, you’ll be charged interest only on the amount you withdraw, not on the entire overdraft limit.',
  },
  {
    question: 'Can I use an Overdraft Loan for any purpose??',
    answer:
      'Yes, Overdraft Loans are versatile and can be used for a variety of purposes, including managing personal expenses, covering business cash flow gaps, or funding unexpected costs.',
  },
  {
    question: 'How do I repay an Overdraft Loan?',
    answer:
      'Repayment typically occurs automatically as funds are deposited into your account. You can continue using the overdraft facility as long as you stay within the approved limit and make regular payments.',
  },
  {
    question: 'What happens if I exceed my overdraft limit?',
    answer:
      'Exceeding your overdraft limit may result in additional fees and a higher interest rate. It can also negatively impact your credit score. It’s important to monitor your account balance and manage your overdraft carefully.',
  },
  {
    question: 'Is there a fee for setting up an Overdraft Loan?',
    answer:
      'Some lenders may charge a setup fee or an annual fee for maintaining the overdraft facility. Our experts will help you understand all associated costs before you proceed with the loan.',
  },
];

export const FAQMortgageLoan = [
  {
    question: 'What types of mortgage loans does MingleLoans offer?',
    answer:
      'MingleLoans offers a variety of mortgage loans, including loans against residential properties, commercial properties, and plots. We work with a wide network of lenders to provide tailored loan options.',
  },
  {
    question: 'How long does it take to get a mortgage loan?',
    answer:
      'The time frame for processing a mortgage loan varies depending on the lender and the complexity of your application. Typically, you can expect to receive loan offers within a few days of submitting your application',
  },
  {
    question: 'What is the interest rate for mortgage loans?',
    answer:
      'Interest rates for mortgage loans depend on several factors, including your credit score, loan amount, and repayment term. Our experts will help you find the most competitive rates available.',
  },
  {
    question: 'Can I apply for a mortgage loan if I have a low credit score?',
    answer:
      'While a good credit score is important for securing favorable loan terms, MingleLoans works with a variety of lenders, including those who offer loans to individuals with lower credit scores. Our experts will help you explore your options.',
  },
  {
    question: 'What documents are required for a mortgage loan?',
    answer:
      'Required documents typically include proof of income, identity verification, property ownership details, and financial statements. Our experts will provide you with a detailed list based on your specific application.',
  },
  {
    question: 'How do I repay the mortgage loan?',
    answer:
      'Mortgage loans are usually repaid in monthly installments over a fixed term. MingleLoans offers flexible repayment options, allowing you to choose a plan that suits your financial situation.',
  },
  {
    question: 'What happens if I miss a payment?',
    answer:
      'Missing a payment can result in late fees and may negatively impact your credit score. If you anticipate difficulty in making a payment, contact our support team for assistance and possible solutions.',
  },
];

export const heroCarouselImages = [
  {
    img: Image1,
  },
  {
    img: Image2,
  },
  {
    img: Image3,
  },
  {
    img: Image4,
  },
  {
    img: Image5,
  },
  {
    img: Image6,
  },
  {
    img: Image7,
  },
];

export const serviceDropDown = [
  { title: 'Expert Services' },
  { title: 'Personal Loan' },
  { title: 'Business Loan' },
  { title: 'Home Loan' },
  { title: 'Mortgage Loan' },
  { title: 'OverDraft' },
  { title: 'Balance Transfer' },
];

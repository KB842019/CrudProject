export const PrivacyPolicyData = [
  {
    title: 'Data Collection',
    content:
      'We collect personal information such as your name, contact details, financial information, and any other data necessary for processing your loan applications.',
  },
  {
    title: 'Use of Data',
    content:
      'The information collected is used to facilitate your loan application process, communicate with you, and improve our services. Your information may be shared with financial institutions for the purpose of processing your loan application.',
  },
  {
    title: 'Data Protection',
    content:
      'MingleLoans takes the protection of your personal information seriously and implements reasonable security measures to safeguard it. However, we cannot guarantee the absolute security of your information.',
  },
  {
    title: 'Third-Party Disclosure',
    content:
      'We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties except to trusted financial institutions and partners who assist us in operating our platform, conducting our business, or serving our users.',
  },
  {
    title: 'Cookies',
    content:
      'MingleLoans uses cookies to enhance your user experience. Cookies help us understand and save your preferences for future visits.',
  },
  {
    title: 'Data Retention',
    content:
      'We will retain your personal information for as long as necessary to provide our services to you, comply with legal obligations, resolve disputes, and enforce our agreements.',
  },
  {
    title: 'User Rights',
    content:
      'You have the right to access, update, and delete your personal information by logging into your account or contacting us directly. You also have the right to withdraw consent to our processing of your personal data.',
  },

  {
    title: 'Changes to Privacy Policy',
    content:
      'MingleLoans reserves the right to update this privacy policy at any time. We will notify you of any changes by posting the new policy on the site. Your continued use of the platform after such changes constitutes your acceptance of the new policy.',
  },
];

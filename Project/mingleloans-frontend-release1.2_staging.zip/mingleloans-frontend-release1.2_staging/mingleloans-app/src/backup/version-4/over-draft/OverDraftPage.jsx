import PropTypes from 'prop-types';
import { useTheme } from '@emotion/react';
import React, { lazy, useState, Suspense, useEffect } from 'react';

import {
  Grid,
  Step,
  Button,
  Stepper,
  StepLabel,
  FormLabel,
  Typography,
  useMediaQuery,
  CircularProgress,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';

import {
  getSteps,
  StepEnum,
  callGetLoanDetailsService,
  callPostLoanDetailsService,
} from './OverDraftService';

const LoanPreview = lazy(() => import('./sections/tabs/LoanPreview'));
const LoanDetailsView = lazy(() => import('./sections/tabs/LoanDetailsView'));
const LoanDocumentView = lazy(() => import('./sections/tabs/LoanDocumentView'));
const PersonalDetailsView = lazy(() => import('./sections/tabs/PersonalDetailsView'));
const EmploymentDetailsView = lazy(() => import('./sections/tabs/EmploymentDetailsView'));

export default function OverDraftPage({ readOnly = false }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const { activeStep, handleReset, loanInfo, setLoanInfo } = useApplyLoanStore((state) => ({
    activeStep: state.activeStep,
    handleReset: state.handleReset,
    loanInfo: state.loanInfo,
    setLoanInfo: state.setLoanInfo,
  }));
  const [selectedImage, setSelectedImage] = useState(null);
  useEffect(() => {
    const fetchLoanData = async () => {
      try {
        const fetchedData = await callGetLoanDetailsService();
        if (!fetchedData || fetchedData.data === null) {
          setLoanInfo({});
          return;
        }
        setLoanInfo(fetchedData.data);
      } catch (error) {
        setLoanInfo({});
      }
    };
    fetchLoanData();
  }, [setLoanInfo]);

  const handleNextOrSubmit = async (data) => {
    try {
      alert(loanInfo);
      const response = await callPostLoanDetailsService(data);
      alert(response);
    } catch (error) {
      console.error('❌ Error submitting loan details:', error);
    }
  };
  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedImage(file);
    }
  };
  return (
    <Grid sx={{ width: '100%', mt: { xs: 1, sm: 1, md: 2, lg: 0, xl: 0 } }}>
      <Stepper
        sx={{ marginLeft: isMobile ? null : '-8px' }}
        activeStep={activeStep}
        orientation={isMobile ? 'vertical' : 'horizontal'}
      >
        {getSteps.map((label, index) => (
          <Step key={index}>
            <StepLabel>{label}</StepLabel>
          </Step>
        ))}
      </Stepper>
      <Grid
        item
        sx={{
          display: 'flex',
          alignItems: 'flex-end',
          borderBottom: '2px solid gray',
          width: '100%',
          paddingTop: '10px',
          paddingBottom: '5px',
        }}
      />
      {activeStep === getSteps.length ? (
        <>
          <Typography sx={{ mt: 1, mb: 1 }}>All steps completed - you&apos;re finished</Typography>
          <Grid sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
            <Grid sx={{ flex: '1 1 auto' }} />
            <Button onClick={handleReset}>Reset</Button>
          </Grid>
        </>
      ) : (
        <Grid container item xs={12} spacing={1} mt={1}>
          <Grid item xs={12} sm={2} md={2}>
            <Grid sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <FormLabel
                htmlFor="image-upload"
                style={{
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Grid
                  sx={{
                    width: 150,
                    height: 150,
                    border: '1px solid #ddd',
                    borderRadius: 1,
                    overflow: 'hidden',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    position: 'relative',
                    left: '-18px',
                  }}
                >
                  {selectedImage ? (
                    <img
                      src={URL.createObjectURL(selectedImage)}
                      alt="Uploaded"
                      style={{ width: '100%', height: '100%', objectFit: 'cover', padding: 10 }}
                    />
                  ) : (
                    <Typography
                      variant="body1"
                      sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        style={{ width: '40px', height: '40px' }}
                      >
                        <path d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 4.5 4.5M12 3v13.5" />
                      </svg>
                      <span style={{ fontSize: 14, marginTop: 10 }}>Upload Picture</span>
                      <span style={{ fontSize: 10, marginTop: 5 }}>
                        Format supported: *.jpg, *.png
                      </span>
                    </Typography>
                  )}
                </Grid>
                <input
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  style={{ display: 'none' }}
                  onChange={handleImageChange}
                />
              </FormLabel>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={10} md={10}>
            <Suspense fallback={<CircularProgress />}>
              {activeStep === StepEnum.PERSONAL_DETAILS && (
                <PersonalDetailsView handleNextOrSubmit={handleNextOrSubmit} />
              )}
              {activeStep === StepEnum.EMPLOYMENT_DETAILS && (
                <EmploymentDetailsView handleNextOrSubmit={handleNextOrSubmit} />
              )}
              {activeStep === StepEnum.LOAN_DETAILS && (
                <LoanDetailsView handleNextOrSubmit={handleNextOrSubmit} />
              )}
              {activeStep === StepEnum.UPLOAD_DOCUMENTS && (
                <LoanDocumentView handleNextOrSubmit={handleNextOrSubmit} />
              )}
              {activeStep === StepEnum.LOAN_PREVIEW && (
                <LoanPreview handleNextOrSubmit={handleNextOrSubmit} />
              )}
            </Suspense>
          </Grid>
        </Grid>
      )}
    </Grid>
  );
}
OverDraftPage.propTypes = {
  readOnly: PropTypes.bool,
};

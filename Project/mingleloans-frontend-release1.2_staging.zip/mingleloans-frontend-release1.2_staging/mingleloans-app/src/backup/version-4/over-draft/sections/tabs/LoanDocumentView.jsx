import * as Yup from 'yup';
import { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useTheme } from '@emotion/react';
import { yupResolver } from '@hookform/resolvers/yup';
import Iconify from '@components/mui-components/iconify';
import FormProvider from '@components/mui-components/hook-form';
import RHFFileUpload from '@components/mui-components/hook-form/rhf-uplaod-field';

import { GridCheckCircleIcon } from '@mui/x-data-grid';
import { Grid, Alert, FormControl, useMediaQuery } from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/personal-loan/sections/StepperContainer';

export default function LoanDocumentView({ readOnly = false, handleNextOrSubmit }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const { documentUpload, setDocuments, handleNext, handleBack, activeStep } = useApplyLoanStore(
    (state) => state
  );
  const [errorMsg, setErrorMsg] = useState('');
  const defaultValues = {
    panCard: documentUpload?.panCard ?? '',
    aadhaarCard: documentUpload?.aadhaarCard ?? '',
    salarySlip: documentUpload?.salarySlip ?? '',
    bankStatement: documentUpload?.bankStatement ?? '',
  };
  const documentSchema = Yup.object({
    panCard: Yup.mixed().required(''),
    aadhaarCard: Yup.mixed().required(''),
    salarySlip: Yup.mixed().required(''),
    bankStatement: Yup.mixed().required(''),
  });
  const methods = useForm({
    resolver: yupResolver(documentSchema),
    defaultValues,
  });
  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;
  const onSubmit = handleSubmit(async (data) => {
    if (!data.panCard || !data.aadhaarCard || !data.salarySlip || !data.bankStatement) {
      setErrorMsg('All document uploads are required to proceed.');
      return;
    }
    try {
      setDocuments(data);
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });
  const renderForm = (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid
            item
            spacing={2}
            xs={isMobile ? 4 : 3}
            sx={{ display: 'flex', flexDirection: 'column' }}
          >
            <Grid item xs={12} sx={{ display: 'flex', alignItems: 'center', gap: 1 }} mb={2}>
              <span>
                {methods.watch('panCard') ? (
                  <GridCheckCircleIcon color="success" sx={{ fontSize: 25 }} />
                ) : (
                  <Iconify icon="eva:clock-fill" width={30} sx={{ color: 'red' }} />
                )}
              </span>
              <span>Pan Card</span>
            </Grid>
            <Grid item xs={12} sx={{ display: 'flex', alignItems: 'center', gap: 1 }} mb={2}>
              <span>
                {methods.watch('aadhaarCard') ? (
                  <GridCheckCircleIcon color="success" sx={{ fontSize: 25 }} />
                ) : (
                  <Iconify icon="eva:clock-fill" width={30} sx={{ color: 'red' }} />
                )}
              </span>
              <span>Aadhaar Card</span>
            </Grid>
            <Grid item xs={12} sx={{ display: 'flex', alignItems: 'center', gap: 1 }} mb={2}>
              <span>
                {methods.watch('salarySlip') ? (
                  <GridCheckCircleIcon color="success" sx={{ fontSize: 25 }} />
                ) : (
                  <Iconify icon="eva:clock-fill" width={30} sx={{ color: 'red' }} />
                )}
              </span>
              <span>Latest salary slips (3 Months)</span>
            </Grid>
            <Grid item xs={12} sx={{ display: 'flex', alignItems: 'center', gap: 1 }} mb={2}>
              <span>
                {methods.watch('bankStatement') ? (
                  <GridCheckCircleIcon color="success" sx={{ fontSize: 25 }} />
                ) : (
                  <Iconify icon="eva:clock-fill" width={30} sx={{ color: 'red' }} />
                )}
              </span>
              <span>Bank Statement (6 Months)</span>
            </Grid>
          </Grid>
          <Grid
            item
            spacing={2}
            xs={isMobile ? 8 : 9}
            sx={{ display: 'flex', flexDirection: 'column' }}
          >
            <Grid item xs={12} mb={2}>
              <RHFFileUpload
                name="panCard"
                showIcon={activeStep === 4}
                type="file"
                multiple={false}
                label="Drop files here or click to browse through your machine."
                disabled={readOnly}
              />
            </Grid>
            <Grid item xs={12} mb={2}>
              <RHFFileUpload
                name="aadhaarCard"
                showIcon={activeStep === 4}
                type="file"
                multiple={false}
                label="Drop files here or click to browse through your machine."
                disabled={readOnly}
              />
            </Grid>
            <Grid item xs={12} mb={2}>
              <RHFFileUpload
                name="salarySlip"
                showIcon={activeStep === 4}
                type="file"
                multiple={false}
                label="Drop files here or click to browse through your machine."
                disabled={readOnly}
              />
            </Grid>
            <Grid item xs={12} mb={2}>
              <RHFFileUpload
                name="bankStatement"
                showIcon={activeStep === 4}
                type="file"
                multiple={false}
                label="Drop files here or click to browse through your machine."
                disabled={readOnly}
              />
            </Grid>
          </Grid>
        </Grid>
        {readOnly === false && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} handleBack={handleBack} />
          </Grid>
        )}
      </FormControl>
    </FormProvider>
  );
  return (
    <>
      {!!errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
      {renderForm}
    </>
  );
}
LoanDocumentView.propTypes = {
  readOnly: PropTypes.bool,
  handleNextOrSubmit: PropTypes.func,
};

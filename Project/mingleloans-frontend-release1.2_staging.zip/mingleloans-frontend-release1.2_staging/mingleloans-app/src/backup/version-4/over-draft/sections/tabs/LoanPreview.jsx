import { useForm } from 'react-hook-form';
import Iconify from '@components/mui-components/iconify';
import React, { lazy, useState, Suspense, useEffect } from 'react';

import {
  Grid,
  Accordion,
  Typography,
  useMediaQuery,
  AccordionDetails,
  AccordionSummary,
  CircularProgress,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/personal-loan/sections/StepperContainer';

const LoanInfoView = lazy(() => import('./LoanDetailsView'));
const PersonalInfoView = lazy(() => import('./PersonalDetailsView'));
const ApplicationDocumentView = lazy(() => import('./LoanDocumentView'));
const EmploymentDetailsView = lazy(() => import('./EmploymentDetailsView'));
function LoanPreview() {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const {
    personalInfo,
    employmentInfo,
    loanInfo,
    documentUpload,
    myApplications,
    setMyApplications,
    handleBack,
    setIsApplicationSubmitted,
  } = useApplyLoanStore((state) => state);
  const bool = true;
  const [errorMsg, setErrorMsg] = useState('');
  const methods = useForm();
  const {
    reset,
    formState: { isSubmitting },
  } = methods;
  const onSubmit = async (e) => {
    e.preventDefault();
    if (personalInfo && loanInfo && documentUpload && employmentInfo) {
      try {
        console.log({ personalInfo, employmentInfo, loanInfo });
        setMyApplications({
          id: +myApplications.length + 1,
          title: loanInfo?.loanType,
          description: loanInfo?.loanAmount,
          personalInfo,
          loanInfo,
          employmentInfo,
          documentUpload,
        });
        setIsApplicationSubmitted(true);
      } catch (error) {
        console.error(error);
        reset();
        setErrorMsg(typeof error === 'string' ? error : error.message);
      }
    }
  };
  const [personalExpanded, setPersonalExpanded] = useState(true);
  const [employementExpanded, setEmployementExpanded] = useState(true);
  const [loanInfoExpanded, setLoanInfoExpanded] = useState(true);
  const [uploadDocumentsExpanded, setUploadDocumentsExpanded] = useState(true);
  const expandAll = () => {
    setPersonalExpanded(true);
    setEmployementExpanded(true);
    setLoanInfoExpanded(true);
    setUploadDocumentsExpanded(true);
  };
  const collapseAll = () => {
    setPersonalExpanded(false);
    setEmployementExpanded(false);
    setLoanInfoExpanded(false);
    setUploadDocumentsExpanded(false);
  };
  const [allExpanded, setAllExpanded] = useState(
    personalExpanded && employementExpanded && loanInfoExpanded && uploadDocumentsExpanded
  );
  useEffect(() => {
    if (personalExpanded && employementExpanded && loanInfoExpanded && uploadDocumentsExpanded) {
      setAllExpanded(true);
    } else {
      setAllExpanded(false);
    }
  }, [personalExpanded, employementExpanded, uploadDocumentsExpanded, loanInfoExpanded]);
  return (
    <form onSubmit={onSubmit}>
      {errorMsg}
      <Grid
        container
        xs={12}
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          cursor: 'pointer',
          marginBottom: '10px',
          paddingRight: isMobile ? '10px' : '40px',
        }}
        onClick={allExpanded ? collapseAll : expandAll}
        title={allExpanded ? 'Collapse All' : 'Expand All'}
      >
        <Iconify icon={!allExpanded ? 'eva:expand-fill' : 'eva:collapse-fill'} width={40} />
      </Grid>
      {[
        {
          title: 'Personal Information',
          expanded: personalExpanded,
          setExpanded: setPersonalExpanded,
          Component: PersonalInfoView,
        },
        {
          title: 'Employment Details',
          expanded: employementExpanded,
          setExpanded: setEmployementExpanded,
          Component: EmploymentDetailsView,
        },
        {
          title: 'Loan Information',
          expanded: loanInfoExpanded,
          setExpanded: setLoanInfoExpanded,
          Component: LoanInfoView,
        },
        {
          title: 'Upload Documents',
          expanded: uploadDocumentsExpanded,
          setExpanded: setUploadDocumentsExpanded,
          Component: ApplicationDocumentView,
        },
      ].map(({ title, expanded, setExpanded, Component }) => (
        <Accordion
          key={title}
          expanded={expanded}
          onChange={() => setExpanded(!expanded)}
          sx={{ padding: '20px 0px', marginBottom: '5px' }}
        >
          <AccordionSummary expandIcon={<Iconify icon="eva:arrow-down-outline" width={25} />}>
            <Typography>{title}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Suspense fallback={<CircularProgress size={24} />}>
              <Component readOnly={bool} />
            </Suspense>
          </AccordionDetails>
        </Accordion>
      ))}
      <Grid container spacing={1.5} mt={1} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
        <StepperContainer loading={isSubmitting} handleBack={handleBack} activeStep={5} />
      </Grid>
    </form>
  );
}
export default LoanPreview;

import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import FormProvider, { RHFTextField } from '@components/mui-components/hook-form';

import {
  Grid,
  Alert,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  useMediaQuery,
} from '@mui/material';

import Years from 'src/assets/data/dummy-data/Years.json';
import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/personal-loan/sections/StepperContainer';

export default function EmploymentDetailsView({ readOnly = false, handleNextOrSubmit }) {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const { employmentInfo, setEmploymentInfo, occupation, handleNext } = useApplyLoanStore(
    (state) => state
  );
  const [errorMsg, setErrorMsg] = useState('');

  const defaultValues = {
    occupation,
    companyName: employmentInfo?.companyName ?? '',
    takeHomeSalary: employmentInfo?.takeHomeSalary ?? 0,
    netSalary: employmentInfo?.netSalary ?? 0,
    currentObligation: employmentInfo?.currentObligation ?? 0,
    degree: employmentInfo?.degree ?? '',
    designation: employmentInfo?.designation ?? '',
    withdrawalType: employmentInfo?.withdrawalType ?? '',
    currentExperience: employmentInfo?.currentExperience ?? '',
    totalExperience: employmentInfo?.totalExperience ?? '',
    pfStatus: employmentInfo?.pfStatus ?? '',
  };

  const qualificationSchema = Yup.object().shape({
    companyName: Yup.string().required('Company Name is required'),
    pfStatus: Yup.string().required('PF status is required'),
    companyAddress: Yup.string().required('Company Address is required'),
    officeEmail: Yup.string().email('Invalid email').required('Office Email is required'),
    takeHomeSalary: Yup.number().required('TakeHomeSalary is required'),
    currentObligation: Yup.number().required('Current Obligation is required'),
    degree: Yup.string().required('Degree is required'),
    designation: Yup.string().required('Designation is required'),
  });

  const methods = useForm({
    resolver: yupResolver(qualificationSchema),
    defaultValues,
  });

  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
    watch,
    setValue,
    register,
  } = methods;
  const takeHomeSalaryWatch = watch('takeHomeSalary');
  const currentObligationWatch = watch('currentObligation');

  useEffect(() => {
    const NET_SALARY = +takeHomeSalaryWatch - +currentObligationWatch;
    if (NET_SALARY < 0) {
      setErrorMsg('Net Salary cannot be greator then Take Home Salary');
    } else {
      setErrorMsg('');
      setValue('netSalary', NET_SALARY);
    }
  }, [setValue, takeHomeSalaryWatch, currentObligationWatch]);

  const onSubmit = handleSubmit(async (data) => {
    try {
      setEmploymentInfo({ ...data, occupation });
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });

  const isSelfEmployed = occupation === 'self-employed';
  const renderForm = (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="companyName"
              label="Company Name"
              disabled={readOnly}
              helperText={isSelfEmployed ? '' : '* as per salary Slip'}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="companyAddress"
              label="Company Address"
              disabled={readOnly}
              helperText={isSelfEmployed ? '' : '* as per salary Slip'}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="designation"
              label="Designation"
              disabled={readOnly}
              helperText={isSelfEmployed ? '' : '* as per salary Slip'}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="officeEmail" label="Office Email Address" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <FormControl fullWidth>
              <InputLabel id="degree">Education Qualification</InputLabel>
              <Select
                fullWidth
                labelId="degree"
                id="degree"
                autoWidth
                name="degree"
                label="Education Qualification"
                xs={12}
                sm={6}
                md={4}
                {...register('degree')}
                defaultValue={employmentInfo?.degree ?? ''}
                disabled={readOnly}
                required
              >
                <MenuItem value="">
                  <em>Select a degree</em>
                </MenuItem>
                <MenuItem value="doctorate">Doctorate</MenuItem>
                <MenuItem value="postgraduate">Post graduate</MenuItem>
                <MenuItem value="graduate">Graduate</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          {!isSelfEmployed && (
            <>
              <Grid item xs={12} sm={6} md={6} fullWidth>
                <FormControl fullWidth>
                  <InputLabel id="currentExperience">Current Company Experience</InputLabel>
                  <Select
                    fullWidth
                    labelId="currentExperience"
                    id="currentExperience"
                    autoWidth
                    name="currentExperience"
                    label="current company experience"
                    xs={12}
                    sm={6}
                    md={4}
                    {...register('currentExperience')}
                    defaultValue={employmentInfo?.currentExperience ?? ''}
                    disabled={readOnly}
                    required
                  >
                    <MenuItem value="">
                      <em>Select years</em>
                    </MenuItem>
                    {Years.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControl fullWidth>
                  <InputLabel id="totalExperience">Total Experience</InputLabel>
                  <Select
                    fullWidth
                    labelId="totalExperience"
                    id="totalExperience"
                    autoWidth
                    name="totalExperience"
                    label="Total Experience"
                    {...register('totalExperience')}
                    defaultValue={employmentInfo?.totalExperience ?? ''}
                    disabled={readOnly}
                    required
                  >
                    <MenuItem value="">
                      <em>Select years</em>
                    </MenuItem>
                    {Years.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
            </>
          )}
          {!isSelfEmployed && (
            <Grid item xs={12} sm={6} md={4}>
              <FormControl fullWidth>
                <InputLabel id="withdrawalType">Salary Withdrawal</InputLabel>
                <Select
                  fullWidth
                  labelId="withdrawalType"
                  htmlFor="withdrawalType"
                  autoWidth
                  label="withdrawalType"
                  name="withdrawalType"
                  xs={12}
                  sm={6}
                  md={4}
                  required
                  disabled={readOnly}
                  {...register('withdrawalType')}
                  defaultValue={employmentInfo?.withdrawalType ?? ''}
                >
                  <MenuItem value="">
                    <em>Salary Withdrawal Type</em>
                  </MenuItem>
                  <MenuItem value="bank">In bank account</MenuItem>
                  <MenuItem value="cheque">By cheque</MenuItem>
                  <MenuItem value="cash">By cash</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          )}

          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="takeHomeSalary"
              type="number"
              label="Take Home Salary"
              disabled={readOnly}
              helperText={isSelfEmployed ? '' : '* as per salary Slip'}
              required
            />
          </Grid>

          {!isSelfEmployed && (
            <Grid item xs={12} sm={6} md={4}>
              <RHFTextField
                name="currentObligation"
                type="number"
                label="Current Obligation"
                disabled={readOnly}
                required
              />
            </Grid>
          )}

          {!isSelfEmployed && (
            <Grid item xs={12} sm={6} md={6}>
              <RHFTextField name="netSalary" type="number" label="Net Salary" disabled />
            </Grid>
          )}
          {!isSelfEmployed && (
            <Grid item xs={12} sm={6} md={6}>
              <FormControl fullWidth>
                <InputLabel id="pfStatus">Is PF Deducted?</InputLabel>
                <Select
                  fullWidth
                  labelId="pfStatus"
                  htmlFor="pfStatus"
                  autoWidth
                  label="Is PF Deducted?"
                  name="pfStatus"
                  xs={12}
                  sm={6}
                  md={4}
                  required
                  disabled={readOnly}
                  {...register('pfStatus')}
                  defaultValue={employmentInfo?.pfStatus ?? ''}
                >
                  <MenuItem value="">
                    <em>Is PF Deducted?</em>
                  </MenuItem>

                  <MenuItem value="yes">Yes</MenuItem>
                  <MenuItem value="no">No</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          )}
        </Grid>
        {readOnly === false && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} />
          </Grid>
        )}
      </FormControl>
    </FormProvider>
  );

  return (
    <>
      {!!errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
      {renderForm}
    </>
  );
}

EmploymentDetailsView.propTypes = {
  readOnly: PropTypes.bool,
  handleNext: PropTypes.func,
  handleBack: PropTypes.func,
  occupation: PropTypes.string,
  handleNextOrSubmit: PropTypes.func,
};

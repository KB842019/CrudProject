import { RESPONSE_CODES } from 'src/global/ResponseCodes';
import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import {
  getLoanDetails,
  postLoanDetails,
  updateLoanDetails,
} from 'src/middleware/loans/LoanServices';

export const StepEnum = {
  PERSONAL_DETAILS: 0,
  EMPLOYMENT_OR_BUSINESS: 1,
  LOAN_DETAILS: 2,
  PROPERTY_DETAILS: 3,
  LOAN_DOCUMENTS_VIEW: 4,
  LOAN_PREVIEW: 5,
};

export const getSteps = (occupation) => [
  'Personal Information',
  occupation === 'salaried' ? 'Employment Details' : 'Business Details',
  'Loan Information',
  'Property Details',
  'Upload Documents',
  'Preview',
];

export const callGetLoanDetailsService = async (loanData) => {
  try {
    const { loanInfo, setLoanInfo } = useApplyLoanStore.getState();
    if (loanInfo && Object.keys(loanInfo).length > 0) {
      return {
        success: true,
        message: 'Loan details fetched from Zustand store',
        data: loanInfo,
      };
    }
    const response = await getLoanDetails(loanData);
    if (response?.responseCode === RESPONSE_CODES.general.Success.code) {
      setLoanInfo(response.data);
      return {
        success: true,
        message: 'Loan details fetched successfully from API',
        data: response.data,
      };
    }
    return { success: false, message: 'Failed to fetch loan details', data: null };
  } catch (error) {
    return { success: false, message: error.message || 'Unexpected error occurred', data: null };
  }
};
export const callPostLoanDetailsService = async (loanData) => {
  try {
    const response = await postLoanDetails(loanData);
    if (response?.responseCode === RESPONSE_CODES.general.Success.code) {
      return { success: true, message: 'Loan details saved successfully', data: response.data };
    }
    return { success: false, message: 'Failed to save loan details', data: null };
  } catch (error) {
    return { success: false, message: error.message || 'Unexpected error occurred', data: null };
  }
};
export const callUpdateLoanDetailsService = async (loanData) => {
  try {
    const response = await updateLoanDetails(loanData);
    if (response?.httpStatusCode === RESPONSE_CODES.general.Success.code) {
      return { success: true, message: 'Loan details updated successfully', data: response.data };
    }
    return { success: false, message: 'Failed to update loan details', data: null };
  } catch (error) {
    return { success: false, message: error.message || 'Unexpected error occurred', data: null };
  }
};

/* eslint-disable import/no-unresolved */
import React from 'react';
import PropTypes from 'prop-types';

import Grid from '@mui/material/Grid';
import LoadingButton from '@mui/lab/LoadingButton';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import { StepEnum } from 'src/modules/loans/mortgage-loan/MortgageLoanServices';

export default function StepperContainer({ loading }) {
  const { handleBack, activeStep } = useApplyLoanStore((state) => state);
  return (
    <Grid item container mt={4} pl={2} xs={12}>
      <Grid item xs={6} sm={6}>
        {!(activeStep === StepEnum.PERSONAL_DETAILS) && (
          <LoadingButton
            sx={{ float: 'left', width: '150px' }}
            color="primary"
            size="large"
            type="button"
            disabled={false}
            variant="contained"
            loading={loading}
            onClick={handleBack}
          >
            Back
          </LoadingButton>
        )}
      </Grid>
      <Grid item xs={6} sm={6}>
        <LoadingButton
          sx={{ float: 'right', width: '150px' }}
          color="primary"
          disabled={false}
          size="large"
          type="submit"
          variant="contained"
          loading={loading}
        >
          {activeStep === StepEnum.LOAN_PREVIEW ? 'Submit' : 'Next'}
        </LoadingButton>
      </Grid>
    </Grid>
  );
}

StepperContainer.propTypes = {
  loading: PropTypes.bool,
};

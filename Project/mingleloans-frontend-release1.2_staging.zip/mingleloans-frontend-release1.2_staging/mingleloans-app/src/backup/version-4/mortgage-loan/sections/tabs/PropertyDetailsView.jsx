import * as Yup from 'yup';
import { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm, Controller } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import FormProvider, { RHFTextField } from '@components/mui-components/hook-form';

import {
  Grid,
  Alert,
  Select,
  MenuItem,
  InputLabel,
  Typography,
  FormControl,
  useMediaQuery,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/mortgage-loan/sections/StepperContainer';

export default function PropertyDetailsView({ readOnly = false, handleNextOrSubmit }) {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const { propertyInfo, setPropertyInfo, handleNext, handleBack } = useApplyLoanStore(
    (state) => state
  );
  const [errorMsg, setErrorMsg] = useState('');
  const defaultValues = propertyInfo ?? {
    propertyType: '',
    propertyOwnership: '',
    propertySize: '',
    propertyValue: '',
    propertyAddress: '',
    sellerName: '',
    sellerContact: '',
    sellerEmail: '',
  };
  const qualificationSchema = Yup.object().shape({
    propertyType: Yup.string().required('Property Type is required'),
    propertyOwnership: Yup.string().required('Ownership is required'),
    propertySize: Yup.string().required('Property Size is required'),
    propertyValue: Yup.string().required('Property Value is required'),
    propertyAddress: Yup.string().required('Property Address is required'),
    sellerName: Yup.string().required('Seller Name is required'),
    sellerContact: Yup.string()
      .matches(/^[6789]\d{9}$/, 'Invalid mobile number')
      .required('Seller Contact is required'),
    sellerEmail: Yup.string().email('Invalid email').required('Seller Email is required'),
  });
  const methods = useForm({
    resolver: yupResolver(qualificationSchema),
    defaultValues,
  });
  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
  } = methods;
  const onSubmit = handleSubmit(async (data) => {
    try {
      setPropertyInfo(data);
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });
  return (
    <>
      {errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
      <FormProvider methods={methods} onSubmit={onSubmit}>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          {/* Row 1: Property Details */}
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel id="propertyTypeLabel">Property Type</InputLabel>
              <Controller
                name="propertyType"
                control={methods.control}
                render={({ field }) => (
                  <Select
                    {...field}
                    labelId="propertyTypeLabel"
                    label="Property Type"
                    defaultValue={propertyInfo?.propertyType}
                    disabled={readOnly}
                  >
                    <MenuItem value="">
                      <em>Select Property Type</em>
                    </MenuItem>
                    <MenuItem value="residential">Residential</MenuItem>
                    <MenuItem value="commercial">Commercial</MenuItem>
                    <MenuItem value="plot">Plot</MenuItem>
                  </Select>
                )}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel id="propertyOwnershipLabel">Ownership</InputLabel>
              <Controller
                name="propertyOwnership"
                control={methods.control}
                render={({ field }) => (
                  <Select
                    {...field}
                    labelId="propertyOwnershipLabel"
                    label="Ownership"
                    defaultValue={propertyInfo?.propertyOwnership ?? ''}
                    disabled={readOnly}
                    required
                  >
                    <MenuItem value="">
                      <em>Select Ownership</em>
                    </MenuItem>
                    <MenuItem value="owned">Owned</MenuItem>
                    <MenuItem value="joint-ownership">Joint Ownership</MenuItem>
                  </Select>
                )}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="propertySize" label="Property Size" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField
              name="propertyValue"
              label="Property Value"
              disabled={readOnly}
              helperText="Estimate Market Value"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="propertyAddress" label="Property Address" disabled={readOnly} />
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body2" mt={2}>
              Seller Information
            </Typography>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="sellerName" label="Seller Name" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="sellerContact"
              type="number"
              label="Seller Contact"
              disabled={readOnly}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="sellerEmail" label="Seller Email" disabled={readOnly} />
          </Grid>
        </Grid>
        {!readOnly && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} handleBack={handleBack} />
          </Grid>
        )}
      </FormProvider>
    </>
  );
}
PropertyDetailsView.propTypes = {
  readOnly: PropTypes.bool,
  handleNextOrSubmit: PropTypes.func,
};

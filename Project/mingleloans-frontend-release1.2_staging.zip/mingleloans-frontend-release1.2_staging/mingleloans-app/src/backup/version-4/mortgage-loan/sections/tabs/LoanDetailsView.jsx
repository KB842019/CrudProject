import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import FormProvider, { RHFTextField } from '@components/mui-components/hook-form';

import {
  Grid,
  Alert,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  useMediaQuery,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/mortgage-loan/sections/StepperContainer';

export default function LoanDetailsView({ readOnly = false, handleNextOrSubmit }) {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));
  const { loanInfo, setLoanInfo, handleNext, handleBack } = useApplyLoanStore((state) => state);
  const [errorMsg, setErrorMsg] = useState('');
  const defaultValues = loanInfo ?? {
    loanType: '',
    loanPurpose: '',
    loanAmount: '',
    tenure: '',
    roi: '10.25',
    emiCalculated: '',
  };
  const qualificationSchema = Yup.object().shape({
    loanAmount: Yup.string()
      .required('Loan amount is required')
      .test(
        'maximum',
        'Loan amount must be lesser than or equal to 50,00,000/-',
        (val) => +val <= 5000000
      ),
  });
  const methods = useForm({
    resolver: yupResolver(qualificationSchema),
    defaultValues,
  });
  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
    watch,
    setValue,
    register,
  } = methods;
  const loanAmountWatch = watch('loanAmount');
  const tenureWatch = watch('tenure');
  function calculateEMI(principal, annualRate, tenureYears) {
    const monthlyInterestRate = annualRate / 12 / 100;
    const totalPayments = tenureYears * 12;
    const emi =
      (principal * monthlyInterestRate * (1 + monthlyInterestRate) ** totalPayments) /
      ((1 + monthlyInterestRate) ** totalPayments - 1);
    return emi.toFixed(2);
  }
  useEffect(() => {
    setValue('roi', 10.25);
    setValue('emiCalculated', calculateEMI(+loanAmountWatch, 10.25, +tenureWatch));
  }, [setValue, loanAmountWatch, tenureWatch, watch]);
  const onSubmit = handleSubmit(async (data) => {
    try {
      setLoanInfo(data);
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });
  const isMortgageLoan = loanInfo?.loanType === 'Mortage-loan';
  const loanTenureCount = isMortgageLoan ? 30 : 6;
  const loanTenuareArray = Array.from({ length: loanTenureCount }, (_, index) => index + 1);
  const renderForm = (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="loanAmount"
              label="Loan Amount"
              disabled={readOnly}
              helperText="Maximum 50,00,00,000/-"
              type="number"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel id="tenure">Loan Tenure</InputLabel>
              <Select
                fullWidth
                labelId="tenure"
                htmlFor="tenure"
                autoWidth
                label="Loan tenure"
                name="tenure"
                xs={12}
                sm={6}
                md={4}
                defaultValue={loanInfo?.tenure || ''}
                required
                disabled={readOnly}
                {...register('tenure')}
              >
                <MenuItem value="">
                  <em>Loan Tenure</em>
                </MenuItem>
                {loanTenuareArray.map((_, i) => (
                  <MenuItem value={i}>
                    {i + 1} year{i === 0 ? '' : 's'}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel id="loanPurpose">Loan Purpose</InputLabel>
              <Select
                fullWidth
                labelId="loanPurpose"
                htmlFor="loanPurpose"
                autoWidth
                label="loanPurpose"
                name="loanPurpose"
                xs={12}
                sm={6}
                md={4}
                defaultValue={loanInfo?.loanPurpose || ''}
                required
                disabled={readOnly}
                {...register('loanPurpose')}
              >
                <MenuItem value="">
                  <em>Loan Purpose</em>
                </MenuItem>
                <MenuItem value="new-home">New Home</MenuItem>
                <MenuItem value="construction">Construction</MenuItem>
                <MenuItem value="home-renovation">Home renovation</MenuItem>
                <MenuItem value="others">Others</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        {readOnly === false && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} handleBack={handleBack} />
          </Grid>
        )}
      </FormControl>
    </FormProvider>
  );
  return (
    <>
      {!!errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
      {renderForm}
    </>
  );
}
LoanDetailsView.propTypes = {
  readOnly: PropTypes.bool,
  handleNext: PropTypes.object,
  handleBack: PropTypes.object,
  handleNextOrSubmit: PropTypes.func,
};

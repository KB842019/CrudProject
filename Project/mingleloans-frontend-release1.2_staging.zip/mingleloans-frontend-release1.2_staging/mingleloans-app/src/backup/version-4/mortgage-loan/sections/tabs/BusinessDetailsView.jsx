import * as Yup from 'yup';
import { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import FormProvider, { RHFTextField } from '@components/mui-components/hook-form';

import {
  Grid,
  Alert,
  Select,
  MenuItem,
  Typography,
  InputLabel,
  FormControl,
  useMediaQuery,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/mortgage-loan/sections/StepperContainer';

const BusinessDetailsView = ({ readOnly = false, handleNextOrSubmit }) => {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));

  const { employmentInfo, setEmploymentInfo, occupation, handleNext, handleBack } =
    useApplyLoanStore((state) => state);
  const defaultValues = employmentInfo ?? {
    gstin: '',
    businessPAN: '',
    BusinessName: '',
    businessType: '',
    industryType: '',
    annualTurnover: '',
    netProfit: '',
    totalAssets: '',
  };
  const [errorMsg, setErrorMsg] = useState('');
  const qualificationSchema = Yup.object().shape({
    gstin: Yup.string().required('GSTIN/TIN is required'),
    businessPAN: Yup.string().required('Business PAN is required'),
    BusinessName: Yup.string().required('Business Name is required'),
    businessType: Yup.string().required('Business Type is required'),
    industryType: Yup.string().required('Industry Type is required'),
    annualTurnover: Yup.number()
      .typeError('Annual Turnover must be a number')
      .transform((value, originalValue) => (originalValue === '' ? undefined : value))
      .required('Annual Turnover is required'),
    netProfit: Yup.number()
      .typeError('Net Profit must be a number')
      .transform((value, originalValue) => (originalValue === '' ? undefined : value))
      .required('Net Profit is required'),
    totalAssets: Yup.number()
      .typeError('Total Assets must be a number')
      .transform((value, originalValue) => (originalValue === '' ? undefined : value))
      .required('Total Assets is required'),
  });
  const methods = useForm({
    resolver: yupResolver(qualificationSchema),
    defaultValues,
  });
  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
    register,
  } = methods;
  const onSubmit = handleSubmit(async (data) => {
    try {
      setEmploymentInfo({ ...data, occupation });
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });
  const renderForm = (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="gstin" label="GSTIN/TIN" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={6}>
            <RHFTextField name="businessPAN" label="Business PAN" disabled={readOnly} />
          </Grid>
          <Grid item xs={12}>
            <Grid item xs={12}>
              <Typography>Business Information</Typography>
            </Grid>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="BusinessName" label="Business Name" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel id="businessType">Business Type</InputLabel>
              <Select
                fullWidth
                labelId="businessType"
                id="businessType"
                label="Business Name"
                name="businessType"
                {...register('businessType')}
                defaultValue={employmentInfo?.businessType}
                disabled={readOnly}
                required
              >
                <MenuItem value="">
                  <em>Select Business Type</em>
                </MenuItem>
                <MenuItem value="sole-proprietorship">Sole Proprietorship</MenuItem>
                <MenuItem value="partnership">Partnership</MenuItem>
                <MenuItem value="llc">LLC</MenuItem>
                <MenuItem value="corporation">Corporation</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControl fullWidth>
              <InputLabel id="industryType">Industry Type</InputLabel>
              <Select
                fullWidth
                labelId="industryType"
                id="industryType"
                name="industryType"
                label="Industry Type"
                {...register('industryType')}
                defaultValue={employmentInfo?.industryType}
                disabled={readOnly}
                required
              >
                <MenuItem value="">
                  <em>Select Industry Type</em>
                </MenuItem>
                <MenuItem value="it">IT</MenuItem>
                <MenuItem value="finance">Finance</MenuItem>
                <MenuItem value="manufacturing">Manufacturing</MenuItem>
                <MenuItem value="healthcare">Healthcare</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Typography>Financial Details</Typography>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="annualTurnover"
              type="number"
              label="Annual Turnover"
              disabled={readOnly}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="netProfit" type="number" label="Net Profit" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField
              name="totalAssets"
              type="number"
              label="Total Assets"
              disabled={readOnly}
            />
          </Grid>
        </Grid>
        {!readOnly && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} handleBack={handleBack} />
          </Grid>
        )}
      </FormControl>
    </FormProvider>
  );
  return (
    <>
      {renderForm}
      {errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
    </>
  );
};
BusinessDetailsView.propTypes = {
  readOnly: PropTypes.bool,
  handleNextOrSubmit: PropTypes.func,
};
export default BusinessDetailsView;

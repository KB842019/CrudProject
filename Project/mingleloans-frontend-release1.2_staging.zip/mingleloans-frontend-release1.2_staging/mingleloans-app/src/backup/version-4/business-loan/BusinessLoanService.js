import { RESPONSE_CODES } from 'src/global/ResponseCodes';
import {
  getLoanDetails,
  postLoanDetails,
  updateLoanDetails,
} from 'src/middleware/loans/LoanServices';

export const StepEnum = {
  PERSONAL_DETAILS: 0,
  BUSINESS_DETAILS: 1,
  LOAN_DETAILS: 2,
  UPLOAD_DOCUMENTS: 3,
  LOAN_PREVIEW: 4,
};

export const getSteps = [
  'Personal Information',
  'Business Details',
  'Loan Information',
  'Upload Documents',
  'Preview',
];

export const callPostLoanDetailsService = async (loanData) => {
  try {
    const response = await postLoanDetails(loanData);
    if (response?.httpStatusCode === RESPONSE_CODES.general.Success.code) {
      return { success: true, message: "Loan details saved successfully", data: response.data };
    }
    console.error('❌ Failed to post loan details:', response);
    return { success: false, message: "Failed to save loan details", data: null };
  } catch (error) {
    console.error('❌ Error in callPostLoanDetailsService:', error);
    return { success: false, message: error.message || "Unexpected error occurred", data: null };
  }
};


export const callGetLoanDetailsService = async (loanData) => {
  try {
    const response = await getLoanDetails(loanData);
    if (response?.responseCode === RESPONSE_CODES.general.Success.code) {
      return { success: true, message: "Loan details fetched successfully", data: response.data };
    }
    console.error('❌ Failed to fetch loan details:', response);
    return { success: false, message: "Failed to fetch loan details", data: null };
  } catch (error) {
    console.error('❌ Error in callGetLoanDetailsService:', error);
    return { success: false, message: error.message || "Unexpected error occurred", data: null };
  }
};



export const callUpdateLoanDetailsService = async (loanData) => {
  try {
    const response = await updateLoanDetails(loanData);
    if (response?.httpStatusCode === RESPONSE_CODES.general.Success.code) {
      return { success: true, message: "Loan details updated successfully", data: response.data };
    }
    console.error('❌ Failed to update loan details:', response);
    return { success: false, message: "Failed to update loan details", data: null };
  } catch (error) {
    console.error('❌ Error in callUpdateLoanDetailsService:', error);
    return { success: false, message: error.message || "Unexpected error occurred", data: null };
  }
};

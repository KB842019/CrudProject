/* eslint-disable perfectionist/sort-imports */
import * as Yup from 'yup';
import { useEffect } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import { usePathname } from 'src/routes/hooks';
import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import AadhaarForm from 'src/modules/loans/shared/AadhaarVerification';
import RadioCardGroup from 'src/components/form-components/radio-card-group/RadioCardGroup';

export default function ApplicantEmploymentType({ handleNext }) {
  const pathname = usePathname();
  const { loanType, setLoanType, occupation, setOccupation } = useApplyLoanStore((state) => state);

  useEffect(() => {
    if (pathname.includes('loan-applications')) setLoanType(pathname?.split('/')?.pop());
    if (pathname.includes('personal-loan')) setOccupation('salaried');
    if (pathname.includes('business-loan')) setOccupation('self-employed');
    if (pathname.includes('apply-loan')) setOccupation('');
  }, [pathname, setLoanType, setOccupation]);

  const defaultValues = {
    occupation,
    loanType,
  };

  const qualificationSchema = Yup.object().shape({
    occupation: Yup.string().required('Occupation is required'),
    loanType: Yup.string().required('Loan type is required'),
  });

  const methods = useForm({
    resolver: yupResolver(qualificationSchema),
    defaultValues,
  });

  const { register } = methods;

  const showOccupationType =
    pathname.includes('personal-loan') || pathname.includes('business-loan');
  return (
    <Grid container mt={1} mb={1}>
      {!showOccupationType && (
        <Grid item xs={12} sm={12} md={12}>
          <FormControl>
            <RadioCardGroup
              sx={{ position: 'relative', left: '-40px' }}
              required
              register={{ ...register('occupation') }}
              heading="Your Occupation"
              cards={[
                {
                  value: 'salaried',
                  title: 'Salaried',
                  description: 'Working professional',
                  image: 'https://cdn-icons-png.flaticon.com/512/2200/2200422.png',
                },
                {
                  value: 'self-employed',
                  title: 'Self-Employed',
                  description: 'Business owner',
                  image: 'https://cdn-icons-png.flaticon.com/512/6232/6232164.png',
                },
              ]}
              selectedValue={occupation}
              setSelectedValue={setOccupation}
            />
          </FormControl>
        </Grid>
      )}

      {occupation && (
        <Grid item xs={12} sm={12} md={12}>
          <AadhaarForm handleNext={handleNext} />
        </Grid>
      )}
    </Grid>
  );
}

ApplicantEmploymentType.propTypes = {
  handleNext: PropTypes.object,
};

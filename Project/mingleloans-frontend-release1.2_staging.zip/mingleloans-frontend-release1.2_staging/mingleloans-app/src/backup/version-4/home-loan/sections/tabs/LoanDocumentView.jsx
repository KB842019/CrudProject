import * as Yup from 'yup';
import { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useTheme } from '@emotion/react';
import { yupResolver } from '@hookform/resolvers/yup';
import Iconify from '@components/mui-components/iconify';
import FormProvider from '@components/mui-components/hook-form';
import RHFFileUpload from '@components/mui-components/hook-form/rhf-uplaod-field';

import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import { GridCheckCircleIcon } from '@mui/x-data-grid';
import { Alert, Tooltip, IconButton, useMediaQuery } from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/home-loan/sections/StepperContainer';

export default function LoanDocumentView({ readOnly = false, handleNextOrSubmit }) {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

  const { documentUpload, setDocuments, handleNext, handleBack, occupation, activeStep } =
    useApplyLoanStore((state) => state);

  const [errorMsg, setErrorMsg] = useState('');

  const defaultValues = documentUpload ?? {
    panCard: '',
    aadhaarCard: '',
    businessRegistrationCertificate: '',
    financialStatements: '',
    lastYearBankStatement: '',
    latestSalarySlip: '',
    propertyDocument: '',
  };

  const documentSchema = Yup.object().shape({
    panCard: Yup.mixed().required('Pan Card is required.'),
    aadhaarCard: Yup.mixed().required('Aadhaar Card is required.'),
    ...(occupation === 'self-employed' && {
      businessRegistrationCertificate: Yup.mixed().required(
        'Business Registration Certificate is required.'
      ),
      financialStatements: Yup.mixed().required('Financial Statements are required.'),
      lastYearBankStatement: Yup.mixed().required('Last Year Bank Statement is required.'),
      propertyDocument: Yup.mixed().required('Property Document is required.'),
    }),
    ...(occupation === 'salaried' && {
      latestSalarySlip: Yup.mixed().required('Latest Salary Slip is required.'),
      bankStatement: Yup.mixed().required('Bank Statement is required.'),
      propertyDocument: Yup.mixed().required('Property Document is required.'),
    }),
  });

  const methods = useForm({
    resolver: yupResolver(documentSchema),
    defaultValues,
  });

  const {
    reset,
    handleSubmit,
    watch,
    formState: { isSubmitting },
  } = methods;

  const onSubmit = handleSubmit(async (data) => {
    if (occupation === 'self-employed') {
      if (
        !data.panCard ||
        !data.aadhaarCard ||
        !data.businessRegistrationCertificate ||
        !data.financialStatements ||
        !data.lastYearBankStatement ||
        !data.propertyDocument
      ) {
        setErrorMsg('Please upload all the required documents.');
        return;
      }
    } else if (occupation === 'salaried') {
      if (
        !data.panCard ||
        !data.aadhaarCard ||
        !data.latestSalarySlip ||
        !data.bankStatement ||
        !data.propertyDocument
      ) {
        setErrorMsg('Please upload all the required documents.');
        return;
      }
    }

    try {
      setDocuments(data);
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });

  const renderIcon = (fieldName) => {
    const value = watch(fieldName);

    // Check if value is an array and has files or if it's a single file
    const hasValue = Array.isArray(value) ? value.length > 0 : value;

    return hasValue ? (
      <GridCheckCircleIcon color="success" sx={{ fontSize: 25 }} />
    ) : (
      <Iconify icon="eva:clock-fill" width={30} sx={{ color: 'red' }} />
    );
  };

  const renderForm = (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          {occupation === 'self-employed' && (
            <>
              <Grid item xs={isMobile ? 4 : 3} sx={{ display: 'flex', flexDirection: 'column' }}>
                {[
                  { name: 'panCard', label: 'Pan Card' },
                  { name: 'aadhaarCard', label: 'Aadhaar Card' },
                  {
                    name: 'businessRegistrationCertificate',
                    label: 'Business Registration Certificate',
                  },
                  {
                    name: 'financialStatements',
                    label: 'Financial Statements',
                    tooltip: 'Balance Sheets, Profit and Loss Statements',
                  },
                  { name: 'lastYearBankStatement', label: 'Last 1 Year Bank Statement' },
                  {
                    name: 'propertyDocument',
                    label: 'Property Document',
                    tooltip: 'Sale Deed, Sale Agreement and Property Tax Receipt',
                  },
                ].map(({ name, label, tooltip }) => (
                  <Grid
                    item
                    xs={12}
                    sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
                    mb={2}
                    key={name}
                  >
                    <span>{renderIcon(name)}</span>
                    <span style={{ display: 'flex', alignItems: 'center' }}>
                      {label}
                      {tooltip && activeStep === 4 && (
                        <Tooltip title={tooltip}>
                          <IconButton size="small">⚠️</IconButton>
                        </Tooltip>
                      )}
                    </span>
                  </Grid>
                ))}
              </Grid>
              <Grid item xs={isMobile ? 8 : 9} sx={{ display: 'flex', flexDirection: 'column' }}>
                {[
                  'panCard',
                  'aadhaarCard',
                  'businessRegistrationCertificate',
                  'financialStatements',
                  'lastYearBankStatement',
                  'propertyDocument',
                ].map((name) => (
                  <Grid item xs={12} mb={2} key={name}>
                    <RHFFileUpload
                      name={name}
                      showIcon={activeStep === 4}
                      type="file"
                      label="Drop files here or click to browse through your machine."
                      disabled={readOnly}
                    />
                  </Grid>
                ))}
              </Grid>
            </>
          )}
          {occupation === 'salaried' && (
            <>
              <Grid item xs={isMobile ? 4 : 3} sx={{ display: 'flex', flexDirection: 'column' }}>
                {[
                  { name: 'panCard', label: 'Pan Card' },
                  { name: 'aadhaarCard', label: 'Aadhaar Card' },
                  { name: 'latestSalarySlip', label: 'Latest Salary Slip' },
                  { name: 'bankStatement', label: '6 Months Bank Statement' },
                  {
                    name: 'propertyDocument',
                    label: 'Property Document',
                    tooltip: 'Sale Deed, Sale Agreement and Property Tax Receipt',
                  },
                ].map(({ name, label, tooltip }) => (
                  <Grid
                    item
                    xs={12}
                    sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
                    mb={2}
                    key={name}
                  >
                    <span>{renderIcon(name)}</span>
                    <span style={{ display: 'flex', alignItems: 'center' }}>
                      {label}
                      {tooltip && activeStep === 4 && (
                        <Tooltip title={tooltip}>
                          <IconButton size="small">⚠️</IconButton>
                        </Tooltip>
                      )}
                    </span>
                  </Grid>
                ))}
              </Grid>
              <Grid item xs={isMobile ? 8 : 9} sx={{ display: 'flex', flexDirection: 'column' }}>
                {[
                  'panCard',
                  'aadhaarCard',
                  'latestSalarySlip',
                  'bankStatement',
                  'propertyDocument',
                ].map((name) => (
                  <Grid item xs={12} mb={2} key={name}>
                    <RHFFileUpload
                      name={name}
                      showIcon={activeStep === 4}
                      type="file"
                      label="Drop files here or click to browse through your machine."
                      disabled={readOnly}
                    />
                  </Grid>
                ))}
              </Grid>
            </>
          )}
        </Grid>
        {readOnly === false && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} handleBack={handleBack} />
          </Grid>
        )}
      </FormControl>
    </FormProvider>
  );

  return (
    <>
      {!!errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
      {renderForm}
    </>
  );
}

LoanDocumentView.propTypes = {
  readOnly: PropTypes.bool,
  handleNextOrSubmit: PropTypes.func,
};

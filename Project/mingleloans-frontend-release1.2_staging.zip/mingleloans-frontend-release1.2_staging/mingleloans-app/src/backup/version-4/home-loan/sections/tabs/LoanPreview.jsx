import { useForm } from 'react-hook-form';
import React, { useState, useEffect } from 'react';
import Iconify from '@components/mui-components/iconify';

import {
  Grid,
  Accordion,
  Typography,
  useMediaQuery,
  AccordionDetails,
  AccordionSummary,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import LoanInfoView from 'src/modules/loans/home-loan/sections/tabs/LoanDetailsView';
import StepperContainer from 'src/modules/loans/home-loan/sections/StepperContainer';
import BusinessView from 'src/modules/loans/home-loan/sections/tabs/BusinessDetailsView';
import PersonalInfoView from 'src/modules/loans/home-loan/sections/tabs/PersonalDetailsView';
import UploadDocumentsView from 'src/modules/loans/home-loan/sections/tabs/LoanDocumentView';
import PropertyDetailsView from 'src/modules/loans/home-loan/sections/tabs/PropertyDetailsView';
import EmploymentDetailsView from 'src/modules/loans/home-loan/sections/tabs/EmploymentDetailsView';

function LoanPreview() {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));

  const {
    personalInfo,
    employmentInfo,
    loanInfo,
    documentUpload,
    myApplications,
    setMyApplications,
    handleBack,
    setIsApplicationSubmitted,
    occupation,
    propertyInfo,
  } = useApplyLoanStore((state) => state);

  const bool = true;
  const [errorMsg, setErrorMsg] = useState('');

  const methods = useForm();

  const {
    reset,
    formState: { isSubmitting },
  } = methods;
  const onSubmit = async (e) => {
    e.preventDefault();
    if (personalInfo && loanInfo && documentUpload && employmentInfo && propertyInfo) {
      try {
        setMyApplications({
          id: +myApplications.length + 1,
          title: loanInfo?.loanType,
          description: loanInfo?.loanAmount,
          personalInfo,
          loanInfo,
          propertyInfo,
          employmentInfo,
          documentUpload,
        });

        setIsApplicationSubmitted(true);
      } catch (error) {
        reset();
        setErrorMsg(typeof error === 'string' ? error : error.message);
      }
    }
  };

  const [personalExpanded, setPersonalExpanded] = useState(true);
  const [employementExpanded, setEmployementExpanded] = useState(true);
  const [loanInfoExpanded, setLoanInfoExpanded] = useState(true);
  const [carDetailsExpanded, setCarDetailsExpanded] = useState(true);
  const [uploadDocumentsExpanded, setUploadDocumentsExpanded] = useState(true);

  const expandAll = () => {
    setPersonalExpanded(true);
    setEmployementExpanded(true);
    setLoanInfoExpanded(true);
    setUploadDocumentsExpanded(true);
    setCarDetailsExpanded(true);
  };

  const collapseAll = () => {
    setPersonalExpanded(false);
    setEmployementExpanded(false);
    setLoanInfoExpanded(false);
    setUploadDocumentsExpanded(false);
    setCarDetailsExpanded(false);
  };

  const [allExpanded, setAllExpanded] = useState(
    personalExpanded &&
      employementExpanded &&
      loanInfoExpanded &&
      uploadDocumentsExpanded &&
      carDetailsExpanded
  );
  useEffect(() => {
    if (
      personalExpanded &&
      employementExpanded &&
      loanInfoExpanded &&
      uploadDocumentsExpanded &&
      carDetailsExpanded
    ) {
      setAllExpanded(true);
    } else {
      setAllExpanded(false);
    }
  }, [
    personalExpanded,
    employementExpanded,
    uploadDocumentsExpanded,
    loanInfoExpanded,
    carDetailsExpanded,
  ]);

  return (
    <form onSubmit={onSubmit}>
      {errorMsg}
      <Grid
        container
        xs={12}
        sx={{
          display: 'flex',
          justifyContent: 'flex-end',
          cursor: 'pointer',
          marginBottom: '10px',
          paddingRight: isMobile ? '10px' : '40px',
        }}
        onClick={allExpanded ? collapseAll : expandAll}
        title={allExpanded ? 'Collapse All' : 'Expand All'}
      >
        <Iconify icon={!allExpanded ? 'eva:expand-fill' : 'eva:collapse-fill'} width={40} />
      </Grid>
      <Accordion
        expanded={personalExpanded}
        onChange={() => {
          setPersonalExpanded(!personalExpanded);
        }}
        sx={{ padding: '20px 0px', marginBottom: '5px' }}
      >
        <AccordionSummary expandIcon={<Iconify icon="eva:arrow-down-outline" width={25} />}>
          <Typography>Personal Information</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <PersonalInfoView readOnly={bool} />
        </AccordionDetails>
      </Accordion>

      <Accordion
        expanded={employementExpanded}
        onChange={() => {
          setEmployementExpanded(!employementExpanded);
        }}
        sx={{ padding: '20px 0px', marginBottom: '5px' }}
      >
        <AccordionSummary expandIcon={<Iconify icon="eva:arrow-down-outline" width={25} />}>
          <Typography>
            {occupation === 'salaried' ? 'Employement Details' : 'Business Details'}
          </Typography>
        </AccordionSummary>
        <AccordionDetails>
          {occupation === 'salaried' ? (
            <EmploymentDetailsView readOnly={bool} />
          ) : (
            <BusinessView readOnly={bool} />
          )}
        </AccordionDetails>
      </Accordion>

      <Accordion
        expanded={carDetailsExpanded}
        onChange={() => {
          setCarDetailsExpanded(!carDetailsExpanded);
        }}
        sx={{ padding: '20px 0px', marginBottom: '5px' }}
      >
        <AccordionSummary expandIcon={<Iconify icon="eva:arrow-down-outline" width={25} />}>
          <Typography>Property Details</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <PropertyDetailsView readOnly={bool} />
        </AccordionDetails>
      </Accordion>

      <Accordion
        expanded={loanInfoExpanded}
        onChange={() => {
          setLoanInfoExpanded(!loanInfoExpanded);
        }}
        sx={{ padding: '20px 0px', marginBottom: '5px' }}
      >
        <AccordionSummary expandIcon={<Iconify icon="eva:arrow-down-outline" width={25} />}>
          <Typography>Loan Information</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <LoanInfoView readOnly={bool} />
        </AccordionDetails>
      </Accordion>

      <Accordion
        expanded={uploadDocumentsExpanded}
        onChange={() => {
          setUploadDocumentsExpanded(!uploadDocumentsExpanded);
        }}
        sx={{ padding: '20px 0px', marginBottom: '5px' }}
      >
        <AccordionSummary expandIcon={<Iconify icon="eva:arrow-down-outline" width={25} />}>
          <Typography>Upload Documents</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <UploadDocumentsView readOnly={bool} />
        </AccordionDetails>
      </Accordion>

      <Grid container spacing={1.5} mt={1} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
        <StepperContainer loading={isSubmitting} handleBack={handleBack} activeStep={5} />
      </Grid>
    </form>
  );
}

export default LoanPreview;

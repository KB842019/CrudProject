import * as Yup from 'yup';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { useState, useEffect } from 'react';
import { yupResolver } from '@hookform/resolvers/yup';
import FormProvider, { RHFTextField } from '@components/mui-components/hook-form';

import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import {
  Grid,
  Alert,
  Select,
  MenuItem,
  Checkbox,
  FormGroup,
  InputLabel,
  Typography,
  FormControl,
  useMediaQuery,
  FormControlLabel,
} from '@mui/material';

import useApplyLoanStore from 'src/store/loan-store/LoanStore';
import StepperContainer from 'src/modules/loans/home-loan/sections/StepperContainer';

export default function PersonalDetailsView({ readOnly = false, handleNextOrSubmit }) {
  const isMobile = useMediaQuery((theme) => theme.breakpoints.down('sm'));

  const { personalInfo, setPersonalInfo, handleNext } = useApplyLoanStore((state) => state);
  const [errorMsg, setErrorMsg] = useState('');
  const defaultValues = {
    firstName: personalInfo?.firstName ?? '',
    middleName: personalInfo?.middleName ?? '',
    lastName: personalInfo?.lastName ?? '',
    email: personalInfo?.email ?? '',
    contactNumber: personalInfo?.contactNumber ?? '',
    pan: personalInfo?.pan ?? '',
    aadhaarNumber: personalInfo?.aadhaarNumber ?? '',
    permanentAddress: personalInfo?.permanentAddress ?? '',
    paCity: personalInfo?.paCity ?? '',
    paState: personalInfo?.paState ?? '',
    paPinCode: personalInfo?.paPinCode ?? '',
    communicationAddress: personalInfo?.communicationAddress ?? '',
    caCity: personalInfo?.firstName ?? '',
    caState: personalInfo?.firstName ?? '',
    caPinCode: personalInfo?.firstName ?? '',
    coApplicantFullName: personalInfo?.coApplicantFullName ?? '',
    coApplicantRelationship: personalInfo?.coApplicantRelationship ?? '',
    coApplicantAadhaarNumber: personalInfo?.coApplicantAadhaarNumber ?? '',
    coApplicantDOB: personalInfo?.coApplicantDOB ?? '',
    coApplicantEmploymentType: personalInfo?.coApplicantEmploymentType ?? '',
  };

  const personalInfoSchema = Yup.object().shape({
    firstName: Yup.string().required('First Name is required'),
    lastName: Yup.string().required('Last Name is required'),
    email: Yup.string().email('Invalid email').required('Email is required'),
    contactNumber: Yup.string()
      .matches(/^[6789]\d{9}$/, 'Invalid mobile number')
      .required('Mobile number is required'),
    pan: Yup.string()
      .matches(/^[A-Z]{5}[0-9]{4}[A-Z]$/, 'Invalid PAN number')
      .required('PAN number is required'),
    aadhaarNumber: Yup.string()
      .matches(/^\d{12}$/, 'Invalid Aadhaar number')
      .required('Aadhaar number is required'),
    permanentAddress: Yup.string()
      .required('Address is required')
      .max(100, 'Address must be no more than 100 characters'),
    communicationAddress: Yup.string()
      .required('Address is required')
      .max(100, 'Address must be no more than 100 characters'),
    paCity: Yup.string().required('City is required'),
    paState: Yup.string().required('State is required'),
    paPinCode: Yup.string().required('Pin Code is required'),
    caCity: Yup.string().required('City is required'),
    caState: Yup.string().required('State is required'),
    caPinCode: Yup.string().required('Pin Code is required'),
    coApplicantFullName: Yup.string().required('Full Name is required'),
    coApplicantRelationship: Yup.string().required('Relationship is required'),
    coApplicantAadhaarNumber: Yup.string()
      .matches(/^\d{12}$/, 'Invalid Aadhaar number')
      .required('Aadhaar number is required'),
    coApplicantDOB: Yup.string().required('Date Of Birth is required'),
    coApplicantEmploymentType: Yup.string().required('Employment Type is required'),
  });

  const methods = useForm({
    resolver: yupResolver(personalInfoSchema),
    defaultValues,
  });

  const {
    reset,
    handleSubmit,
    formState: { isSubmitting },
    watch,
    setValue,
    register,
  } = methods;

  const watchSameAddress = watch('sameAsPermanent', personalInfo?.sameAsPermanent ?? false);

  useEffect(() => {
    if (watchSameAddress) {
      setValue('communicationAddress', watch('permanentAddress'));
      setValue('caCity', watch('paCity'));
      setValue('caState', watch('paState'));
      setValue('caPinCode', watch('paPinCode'));
    }
  }, [setValue, watchSameAddress, watch]);

  const onSubmit = handleSubmit(async (data) => {
    try {
      setPersonalInfo(data);
      handleNext();
      handleNextOrSubmit(data);
    } catch (error) {
      reset();
      setErrorMsg(typeof error === 'string' ? error : error.message);
    }
  });

  const renderForm = (
    <FormProvider methods={methods} onSubmit={onSubmit}>
      <FormControl fullWidth>
        <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="firstName" label="First Name" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="middleName" label="Middle Name" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="lastName" label="Last Name" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="email" label="Email Address" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="contactNumber" label="Contact Number" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="pan" label="Permanent Account Number (PAN)" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4} md={4}>
            <RHFTextField name="aadhaarNumber" label="Aadhaar Number" disabled />
          </Grid>
        </Grid>

        <Grid container mt={1} spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12}>
            <Typography>Permanent Address</Typography>
          </Grid>
          <Grid item xs={12} sm={12} md={12}>
            <RHFTextField name="permanentAddress" label="Address" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="paCity" label="City" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="paState" label="State" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="paPinCode" label="Pin Code" disabled={readOnly} />
          </Grid>
        </Grid>

        <Grid container mt={1} spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12} sm={12} md={12} container justifyContent="space-between">
            <Typography>Communication Address</Typography>
            <FormGroup>
              <FormControlLabel
                control={
                  <Checkbox
                    {...register('sameAsPermanent')}
                    disabled={readOnly}
                    defaultChecked={personalInfo?.sameAsPermanent}
                  />
                }
                label="Same as above"
                disabled={readOnly}
              />
            </FormGroup>
          </Grid>
          <Grid item xs={12} sm={12} md={12}>
            <RHFTextField
              type="text"
              name="communicationAddress"
              label="Address"
              disabled={readOnly}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="caCity" label="City" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="caState" label="State" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <RHFTextField name="caPinCode" label="Pin Code" disabled={readOnly} />
          </Grid>
        </Grid>

        <Grid container mt={1} spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
          <Grid item xs={12}>
            <Typography>Co-Applicant Information</Typography>
          </Grid>
          <Grid item xs={12} sm={4}>
            <RHFTextField name="coApplicantFullName" label="Full Name" disabled={readOnly} />
          </Grid>
          <Grid item xs={12} sm={4}>
            <FormControl fullWidth>
              <InputLabel id="coApplicantRelationship">Relationship with Applicant</InputLabel>
              <Select
                fullWidth
                labelId="coApplicantRelationship"
                id="coApplicantRelationship"
                autoWidth
                name="coApplicantRelationship"
                label="Relationship with Applicant"
                xs={12}
                sm={6}
                md={4}
                {...register('coApplicantRelationship')}
                defaultValue={personalInfo?.coApplicantRelationship || ''}
                disabled={readOnly}
                required
              >
                <MenuItem value="">
                  <em>Select a relation</em>
                </MenuItem>
                <MenuItem value="spouse">Spouse</MenuItem>
                <MenuItem value="sibling">Sibling</MenuItem>
                <MenuItem value="parent">Parent</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={12} sm={4}>
            <RHFTextField
              name="coApplicantAadhaarNumber"
              label="Co-Applicant Aadhaar Number"
              disabled={readOnly}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DesktopDatePicker
                label="Date of birth"
                name="dob"
                required
                minDate={new Date('1950-01-01')}
                onChange={(newValue) => {
                  setValue('coApplicantDOB', newValue);
                }}
                slotProps={{
                  textField: {
                    fullWidth: true,
                  },
                }}
              />
            </LocalizationProvider>
          </Grid>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth>
              <InputLabel id="coApplicantEmploymentType">Employement Type</InputLabel>
              <Select
                fullWidth
                labelId="coApplicantEmploymentType"
                id="coApplicantEmploymentType"
                autoWidth
                name="coApplicantEmploymentType"
                label="Employement Type"
                xs={12}
                sm={6}
                md={4}
                {...register('coApplicantEmploymentType')}
                defaultValue={personalInfo?.coApplicantEmploymentType || ''}
                disabled={readOnly}
                required
              >
                <MenuItem value="">
                  <em>Select a employment</em>
                </MenuItem>
                <MenuItem value="salaried">Salaried</MenuItem>
                <MenuItem value="self-employement">Self-Employement</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        {!readOnly && (
          <Grid container spacing={1.5} sx={{ paddingRight: isMobile ? '10px' : '20px' }}>
            <StepperContainer loading={isSubmitting} />
          </Grid>
        )}
      </FormControl>
    </FormProvider>
  );

  return (
    <>
      {!!errorMsg && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {errorMsg}
        </Alert>
      )}
      {renderForm}
    </>
  );
}

PersonalDetailsView.propTypes = {
  readOnly: PropTypes.bool,
  handleNextOrSubmit: PropTypes.func,
};

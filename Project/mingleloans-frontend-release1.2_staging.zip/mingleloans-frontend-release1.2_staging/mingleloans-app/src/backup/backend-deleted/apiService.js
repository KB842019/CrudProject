import axios from 'axios';

const domain = `${'HERE COME OUR DOMAIN/'}api/`;

const createHeaders = (isSecure = false, isFileUpload = false) => {
  const headers = {
    Accept: 'application/json',
    'Content-Type': isFileUpload ? 'multipart/form-data' : 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT',
    'X-Authorization': 'USp7DbDxHQ9rDSvhmyhz1ubZd4ZrlnoIiGmc70jlSkcVG4h8GiDSCgj6WsADhNmF',
  };
  if (isSecure) {
    headers.Authorization = ''; // `Bearer ${Auth.getToken()}`;
  }
  return headers;
};

class API {
  // UNSECURE METHODS
  static getRequest(endPoint) {
    return axios.get(domain + endPoint, { headers: createHeaders() });
  }

  static postRequest(endPoint, data) {
    return axios.post(domain + endPoint, data, { headers: createHeaders() });
  }

  static putRequest(endPoint, data) {
    return axios.put(domain + endPoint, data, { headers: createHeaders() });
  }

  // SECURE METHODS
  static getSecureRequest(endPoint) {
    return axios.get(domain + endPoint, { headers: createHeaders(true) });
  }

  static postSecureRequest(endPoint, data) {
    return axios.post(domain + endPoint, data, { headers: createHeaders(true) });
  }

  static postSecureFormDataRequest(endPoint, data) {
    return axios.post(domain + endPoint, data, { headers: createHeaders(true, true) });
  }

  static putSecureRequest(endPoint, data) {
    return axios.put(domain + endPoint, data, { headers: createHeaders(true) });
  }

  static patchRequest(endPoint, id, data) {
    return axios.patch(`${domain + endPoint}/${id}`, data, { headers: createHeaders() });
  }

  static deleteSecureRequest(endPoint) {
    return axios.delete(domain + endPoint, { headers: createHeaders(true) });
  }

  static postFileUpload(endPoint, data) {
    return axios.post(domain + endPoint, data, { headers: createHeaders(true, true) });
  }
}

export default API;

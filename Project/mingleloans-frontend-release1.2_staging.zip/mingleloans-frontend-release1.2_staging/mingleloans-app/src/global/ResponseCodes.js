export const RESPONSE_CODES = {
  general: {
    Success: {
      code: 0,
      message: 'Process completed successfully.',
    },
    ApplicantSuccessfulRegistration: {
      code: 101,
      message: 'Applicant registered successfully.',
    },
    PartnerSuccessfulRegistration: {
      code: 102,
      message: 'Partner registered successfully.',
    },
  },

  validation: {
    InvalidEntityType: {
      code: 1000,
      message: 'This entity type is invalid.',
    },
    AccountPendingForReview: {
      code: 1001,
      message: 'This entity type is invalid.',
    },
    AccountInReview: {
      code: 1002,
      message: 'This entity type is invalid.',
    },
    SuspendedAccount: {
      code: 1003,
      message: 'This mobile number/email account is suspended.',
    },
    DeletedAccount: {
      code: 1004,
      message: 'This mobile number/email account is deleted.',
    },
    AlreadyRegisteredEntity: {
      code: 1005,
      message: 'This mobile number/email is already registered.',
    },
    DifferentRegisteredEntityAccount: {
      code: 1006,
      message: 'This mobile/email is linked to another registered account.',
    },
    InvalidOrExpiredOTP: {
      code: 1007,
      message: 'Invalid or expired OTP.',
    },
    AadhaarCardValidationFailed: {
      code: 1008,
      message: 'Aadhaar card validation failed.',
    },
    EmailRequired: {
      code: 1009,
      message: 'Email is required.',
    },
    MobileFormatIncorrect: {
      code: 1010,
      message: 'Mobile number format is incorrect.',
    },
    UnknownValidationError: {
      code: 1999,
      message: 'An unknown error occurred',
    },
  },
  database: {
    ConnectionFailed: {
      code: 2000,
      message: 'Unable to connect to the database.',
    },
    RecordNotFound: {
      code: 2001,
      message: 'Requested record does not exist.',
    },
    QueryExecutionError: {
      code: 2002,
      message: 'Error occurred during query execution.',
    },
    ApplicantRegistrationFailed: {
      code: 2003,
      message: 'Applicant registration failed.',
    },
    UnknownDbError: {
      code: 2999,
      message: 'A database error occurred.',
    },
  },
  external: {
    FirebaseRegistrationFailed: {
      code: 3000,
      message: 'Failed to create account in firebase.',
    },
    FirebaseLoginFailed: {
      code: 3001,
      message: 'Failed to login via firebase.',
    },
    PaymentGatewayFailed: {
      code: 3002,
      message: 'Failed to connect to the payment gateway.',
    },
    ThirdPartyApiFailure: {
      code: 3003,
      message: 'An external service call error occurred.',
    },
    MobileOTPRequestFailed: {
      code: 3004,
      message: 'Mobile OTP request failed. An internal error occurred. Please try after sometime.',
    },
    UnknownExternalError: {
      code: 3999,
      message: 'A database error occurred.',
    },
  },
  permissionError: {
    InvalidModuleAccess: {
      code: 4000,
      message: 'You do not have permission to access this module.',
    },
    EntityAccountUserIdNotFound: {
      code: 4001,
      message: 'Entity account user id not found.',
    },
  },
  appError: {
    NullApiServiceHandler: {
      code: 5001,
      message: 'Requested API Service handler returned null.',
    },
    NullResponseError: {
      code: 5002,
      message: 'Response not received.',
    },
  },
};

/* 
  EXAMPLES
  Note: Below code is only for demonstration

  function checkAccountExists(responseCode) {
  if (responseCode === RESPONSE_CODES.general.AccountAlreadyExists.code) {
    alert(RESPONSE_CODES.general.AccountAlreadyExists.message);
  } else if (responseCode === RESPONSE_CODES.general.OperationSuccessful.code) {
    alert(RESPONSE_CODES.general.OperationSuccessful.message);
  } else {
    alert(RESPONSE_CODES.general.UnknownError.message);
  }
}

// Simulating a response code
checkAccountExists(1003); // Alerts: "Account already exists"

*/

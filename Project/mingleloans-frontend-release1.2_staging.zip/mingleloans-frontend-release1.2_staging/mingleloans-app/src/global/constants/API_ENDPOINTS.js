export const AUTH_ENDPOINTS = {
  EntityAccountRegistrationApi: 'entityaccount/{{entitytype}}-registration',
  EntityAccountVerificationApi: 'entityaccount/{{entitytype}}/verify',
  MobileVerificationApi: 'entityaccount/{{entitytype}}/send-mobile-otp',
  OtpVerificationApi: 'entityaccount/{{entitytype}}/verify-mobile-otp',
  EntityAccountAppSignInApi: 'entityaccount/sign-in',
};

export const SHARED_ENDPOINTS = {
  EntityProfileApi: 'entityaccount/profile',
};

export const LOAN_ENDPOINTS = {
  loanApi: 'loans/loan',
  businessLoanApi: 'loans/business-loan',
  personalLoanApi: 'loans/personal-loan',
  mortgageLoanApi: 'loans/mortgage-loan',
  homeLoanApi: 'loans/home-loan',
  overdraftApi: 'loans/overdraft',
  balanceTransferApi: 'loans/balance-transfer',
};
export const RAISE_TICKET_ENDPOINTS = {
  RaiseTicketApi: 'support/raise-ticket',
};

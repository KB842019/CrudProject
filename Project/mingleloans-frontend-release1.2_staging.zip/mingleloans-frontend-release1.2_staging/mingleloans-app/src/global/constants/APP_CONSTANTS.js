export const AUTH_KEYS = {
  STORAGE_KEY: 'accessToken',
};

export const IDENTITY_PROVIDERS = {
  Firebase: 1,
  Gmail: 2,
  Outlook: 3,
  X: 4,
  LinkedIn: 5,
};

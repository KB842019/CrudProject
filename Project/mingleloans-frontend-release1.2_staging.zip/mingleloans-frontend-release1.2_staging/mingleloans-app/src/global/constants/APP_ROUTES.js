export const PUBLIC_ROUTES = {
  HOME: '/',
  ABOUT_US: '/about-us',
  CONTACT_US: '/contact-us',
  EXPERT_SERVICES: '/services/expert-services',
  PERSONAL_LOAN: '/services/personal-loan',
  BUSINESS_LOAN: '/services/business-loan',
  HOME_LOAN: '/services/home-loan',
  MORTGAGE_LOAN: '/services/mortgage-loan',
  OVERDRAFT: '/services/overdraft',
  BALANCE_TRANSFER: '/services/balance-transfer',
  LOGIN: '/auth/jwt/login',
  FORGET_PASSWORD: '/auth/jwt/forget-password',
  RESET_PASSWORD: '/auth/jwt/reset-password',
  APPLICANT_REGISTRATION: '/auth/registration/applicant',
  PARTNER_REGISTRATION: '/auth/registration/partner',
};

export const VERIFICATION_ROUTES = {
  OTP_VERIFICATION: '/auth/jwt/<session-id>/verify-otp',
};

export const AUTH_SHARED_ROUTES = {
  INITIATE_ENTITY_AUTH: '/initiate-entity-auth',
  APPLICANT_WELCOME_PAGE: '/applicant/welcome',
  DASHBOARD: '/dashboard',
  REPORTS: '/reports',
  PROFILE: '/profile',
  RESET_PASSWORD: '/reset-password',
  REFER_N_EARN: '/refer-and-earn',
  ACCOUNT_SETTINGS: 'account-settings',
};

export const LOAN_ROUTES = {
  NEW_HOME_LOAN: '/loans/apply-home-loan',
  NEW_PERSONAL_LOAN: '/loans/apply-personal-loan',
  NEW_BUSINESS_LOAN: '/loans/apply-business-loan',
  NEW_MORTGAGE_LOAN: '/loans/apply-mortgage-loan',
  NEW_OVERDRAFT: '/loans/apply-overdraft',
  NEW_BALANCE_TRANSFER: '/loans/apply-balance-transfer',
  MY_LOAN_APPLICATIONS: '/loans/my-loan-applications',
};

export const STAFF_ROUTES = {
  STAFF_LIST: '/staff',
  NEW_STAFF: '/staff/staff-registration',
  STAFF_PROFILE: '/staff/profile',
};

export const CUSTOMER_ROUTES = {
  CUSTOMER_LIST: '/customer',
  NEW_CUSTOMER: '/customer/customer-registration',
  CUSTOMER_PROFILE: '/customer/profile',
};

export const SUPPORT_ROUTES = {
  INDEX: 'support',
  MY_TICKETS: 'support/my-tickets',
  RAISE_TICKET: 'support/raise-ticket',
};

// ----------------------------------------------------------------
export const endpoints = {
  chat: '/api/chat',
  kanban: '/api/kanban',
  calendar: '/api/calendar',
  auth: {
    me: '/api/auth/me',
    login: '/auth/login',
    register: '/api/auth/register',
  },
  mail: {
    list: '/api/mail/list',
    details: '/api/mail/details',
    labels: '/api/mail/labels',
  },
  post: {
    list: '/api/post/list',
    details: '/api/post/details',
    latest: '/api/post/latest',
    search: '/api/post/search',
  },
  product: {
    list: '/api/product/list',
    details: '/api/product/details',
    search: '/api/product/search',
  },
};

// ROOT PATH AFTER LOGIN SUCCESSFUL
export const PATH_AFTER_LOGIN = AUTH_SHARED_ROUTES.DASHBOARD;
export const PATH_AFTER_REGISTRATION = AUTH_SHARED_ROUTES.INITIATE_ENTITY_AUTH;

export const tokenKey = 'accessToken';
export const expirationKey = 'accessToken-exp';
export const saltCharacters = 'abcdefghijklmnopqrstuvwxyz0123456789';

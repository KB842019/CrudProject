export const AXIOS_VAR = {
  localBaseUrl: import.meta.env.VITE_MINGLELOANS_LOCAL_API,
  devBaseUrl: import.meta.env.VITE_MINGLELOANS_DEV_API,
  demoBaseUrl: import.meta.env.VITE_MINGLELOANS_DEMO_API,
  baseUrl: import.meta.env.VITE_MINGLELOANS_PROD_API,
  timeOut: import.meta.env.VITE_AXIOS_TIMEOUT_SEC,
};

export const FIREBASE_API = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APPID,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID,
};

export const CURRENT_ENVIRONMENT = import.meta.env.VITE_MINGLELOANS_ENV;
export const GOOGLE_RECAPTCHA_KEY = import.meta.env.VITE_GOOGLE_RECAPTCHA_KEY;

export const SESSION_TIMEOUT_MINS = import.meta.env.VITE_SESSION_TIMEOUT_MINS;
export const INVALID_PWD_ATTEMPT = import.meta.env.VITE_INVALID_PWD_ATTEMPT;
export const INVALID_OTP_ATTEMPT = import.meta.env.VITE_INVALID_OTP_ATTEMPT;
export const REGISTRATION_OTP_TIMEOUT_MINS = import.meta.env.VITE_REGISTRATION_OTP_TIMEOUT_MINS;

// OLD ENV VARIABLES
// TODO: Remove these variables after updating the codebase
// ----------------------------------------------------------------------

export const HOST_API = import.meta.env.VITE_HOST_API;
export const ASSETS_API = import.meta.env.VITE_ASSETS_API;

export const AMPLIFY_API = {
  userPoolId: import.meta.env.VITE_AWS_AMPLIFY_USER_POOL_ID,
  userPoolWebClientId: import.meta.env.VITE_AWS_AMPLIFY_USER_POOL_WEB_CLIENT_ID,
  region: import.meta.env.VITE_AWS_AMPLIFY_REGION,
};

export const AUTH0_API = {
  clientId: import.meta.env.VITE_AUTH0_CLIENT_ID,
  domain: import.meta.env.VITE_AUTH0_DOMAIN,
  callbackUrl: import.meta.env.VITE_AUTH0_CALLBACK_URL,
};

export const SUPABASE_API = {
  url: import.meta.env.VITE_SUPABASE_URL,
  key: import.meta.env.VITE_SUPABASE_ANON_KEY,
};

export const MAPBOX_API = import.meta.env.VITE_MAPBOX_API;

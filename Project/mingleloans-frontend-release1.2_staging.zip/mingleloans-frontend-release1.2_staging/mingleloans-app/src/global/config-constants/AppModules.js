export const ApplicantModules = {
  dashboard: {
    name: 'dashboard',
    sub_modules: null,
  },
  entityAccount: {
    name: 'entityaccount',
    sub_modules: null,
  },

  myApplications: {
    name: 'myApplications',
    sub_modules: null,
  },
  allLoanApplications: {
    name: 'allLoanApplications',
    sub_modules: null,
  },
  loanApplications: {
    name: 'loanApplications',
    sub_modules: {
      homeLoan: 'homeLoan',
      mortgage: 'mortgage',
      overdraft: 'overdraft',
      personalLoan: 'personalLoan',
      businessLoan: 'businessLoan',
      balanceTransfer: 'balanceTransfer',
    },
  },
  support: {
    name: 'support',
    sub_modules: {
      raiseTicket: 'raiseTicket',
      myTickets: 'myTickets',
    },
  },
  profile: {
    name: 'profile',
    sub_modules: null,
  },
  notifications: {
    name: 'notifications',
    sub_modules: null,
  },
};

export const PartnerModules = {
  dashboard: {
    name: 'dashboard',
    sub_modules: null,
  },
  entityAccount: {
    name: 'entityaccount',
    sub_modules: null,
  },

  myApplications: {
    name: 'myApplications',
    sub_modules: null,
  },
  allLoanApplications: {
    name: 'allLoanApplications',
    sub_modules: null,
  },
  loanApplications: {
    name: 'loanApplications',
    sub_modules: {
      homeLoan: 'homeLoan',
      mortgage: 'mortgage',
      overdraft: 'overdraft',
      personalLoan: 'personalLoan',
      businessLoan: 'businessLoan',
      balanceTransfer: 'balanceTransfer',
    },
  },
  support: {
    name: 'support',
    sub_modules: {
      raiseTicket: 'raiseTicket',
      myTickets: 'myTickets',
    },
  },
  profile: {
    name: 'profile',
    sub_modules: null,
  },
  notifications: {
    name: 'notifications',
    sub_modules: null,
  },
};

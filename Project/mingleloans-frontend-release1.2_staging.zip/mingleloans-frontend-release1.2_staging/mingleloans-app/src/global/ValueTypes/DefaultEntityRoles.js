export const DefaultEntityRoles = {
  ADMIN: 'admin',
  SUPPORT: 'support',
  STAFF: 'staff',
  SALES: 'sales',
  CLIENT: 'client',
  PARTNER: 'partner',
  APPLICANT: 'applicant',
  AGENT: 'agent',
  CUSTOMER: 'customer',
  // ENTITY: 'entity',
};

export const PermissionTypes = {
  allowRead: 'allowread',
  allowAdd: 'allowadd',
  allowUpdate: 'allowupdate',
  allowPatch: 'allowpatch',
  allowDelete: 'allowdelete',
  allowImport: 'allowimport',
  allowExport: 'allowexport',
};

export const Permissions = {
  [PermissionTypes.allowAdd]: false,
  [PermissionTypes.allowRead]: false,
  [PermissionTypes.allowUpdate]: false,
  [PermissionTypes.allowPatch]: false,
  [PermissionTypes.allowDelete]: false,
  [PermissionTypes.allowImport]: false,
  [PermissionTypes.allowExport]: false,
};

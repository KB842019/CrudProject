export const GenderTypes = {
  MALE: 'male',
  FEMALE: 'female',
  OTHER: 'others',
};

export const GenderTypesEnum = {
  MALE: 1,
  FEMALE: 2,
  OTHER: 3,
};

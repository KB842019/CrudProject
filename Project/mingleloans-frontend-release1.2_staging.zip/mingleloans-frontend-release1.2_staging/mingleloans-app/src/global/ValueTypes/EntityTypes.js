export const EntityTypes = {
  ADMIN: 'admin',
  SUPPORT: 'support',
  SALES: 'sales',
  CLIENT: 'client',
  PARTNER: 'partner',
  APPLICANT: 'applicant',
  STAFF: 'staff',
  AGENT: 'agent',
  CUSTOMER: 'customer',
};

export const EntityTypesEnum = {
  ADMIN: 1,
  SUPPORT: 2,
  SALES: 3,
  APPLICANT: 4,
  PARTNER: 5,
  CLIENT: 6,
  STAFF: 7,
  AGENT: 8,
  CUSTOMER: 9,
};

export const EntityTypes = {
  Active: 'active',
  ReviewPending: 'reviewpending',
  InReview: 'inreview',
  Reactivate: 'reactivate',
  Suspended: 'suspended',
  Deleted: 'deleted',
};

export const EntityTypesEnum = {
  Active: 1,
  ReviewPending: 2,
  InReview: 3,
  Reactivate: 4,
  Suspended: 5,
  Deleted: 6,
};

# Response Code Documentation

## Custom Response Codes

### **0 to 999: General, Default, and Informational Response Codes**

These codes represent general responses, including successful operations, default cases, or informational messages.

| **Code** | **Description**            | **Example Message**                      |
| -------- | -------------------------- | ---------------------------------------- |
| `0`      | Success                    | "Success."                               |
| `101`    | New Applicant Registration | "New applicant registered successfully." |
| `102`    | New Partner Registration   | "New partner registered successfully."   |

---

### **1000 to 1999: Validation Failures and Missing Data**

Codes in this range are used when data validation fails or required fields are missing.

| **Code** | **Description**            | **Example Message**                    |
| -------- | -------------------------- | -------------------------------------- |
| `1000`   | Invalid Entity Type        | "Entity type is inavlid."              |
| `1001`   | Missing Required Field     | "Email is required."                   |
| `1002`   | Invalid Data Format        | "Phone number format is incorrect."    |
| `1999`   | Multiple Validation Errors | "Several fields contain invalid data." |

---

### **2000 to 2999: Database Errors**

These codes indicate issues related to database operations such as connectivity or query failures.

| **Code** | **Description**            | **Example Message**                  |
| -------- | -------------------------- | ------------------------------------ |
| `2001`   | Database Connection Failed | "Unable to connect to the database." |
| `2002`   | Data Not Found             | "Requested record does not exist."   |
| `2999`   | General Database Error     | "A database error occurred."         |

---

### **3001 to 3999: External or Third-Party Errors**

Codes in this range are reserved for issues with external services or third-party integrations.

| **Code** | **Description**                       | **Example Message**                         |
| -------- | ------------------------------------- | ------------------------------------------- |
| `3001`   | External Service Unreachable          | "Failed to connect to the payment gateway." |
| `3002`   | API Rate Limit Exceeded               | "Third-party API limit has been reached."   |
| `3999`   | General Third-Party Integration Error | "An external service error occurred."       |

---

## Standard HTTP Status Codes

These are widely used HTTP response codes that indicate the status of an HTTP request.

### **Success Codes**

| **Code** | **Description** | **Example Message**                  |
| -------- | --------------- | ------------------------------------ |
| `200`    | OK              | "Request succeeded."                 |
| `201`    | Created         | "Resource successfully created."     |
| `204`    | No Content      | "Request succeeded with no content." |

### **Client Error Codes**

| **Code** | **Description**      | **Example Message**                     |
| -------- | -------------------- | --------------------------------------- |
| `400`    | Bad Request          | "Invalid request syntax or parameters." |
| `401`    | Unauthorized         | "Authentication is required."           |
| `403`    | Forbidden            | "You do not have permission to access." |
| `404`    | Not Found            | "Requested resource does not exist."    |
| `422`    | Unprocessable Entity | "Validation failed for the input data." |

### **Server Error Codes**

| **Code** | **Description**       | **Example Message**                                     |
| -------- | --------------------- | ------------------------------------------------------- |
| `500`    | Internal Server Error | "An unexpected error occurred on the server."           |
| `503`    | Service Unavailable   | "The server is currently unable to handle the request." |

---

## Examples

### Example 1: Success Response

**Code:** `200`  
**Message:** "Operation completed successfully."  
**Data:** `{ "id": 1, "name": "Sample Data" }`

### Example 2: Validation Failure

**Code:** `1002`  
**Message:** "Phone number format is incorrect."  
**Details:** `{ "field": "phoneNumber", "expectedFormat": "###-###-####" }`

### Example 3: Database Error

**Code:** `2002`  
**Message:** "Requested record does not exist."  
**Query:** `"SELECT * FROM users WHERE id=10"`

### Example 4: Third-Party Error

**Code:** `3001`  
**Message:** "Failed to connect to the payment gateway."  
**Details:** `{ "service": "PayPal", "timeout": "30s" }`

---

This structure ensures clarity for developers when handling and debugging various response codes in the application.

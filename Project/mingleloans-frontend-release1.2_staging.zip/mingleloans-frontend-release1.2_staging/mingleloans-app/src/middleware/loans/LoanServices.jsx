import axiosServiceClient from 'src/middleware/axios/AxiosService';
import { LOAN_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

const formLoanData = (data = {}) => ({
  personalInfo: {
    firstName: data.personalInfo?.firstName || '',
    middleName: data.personalInfo?.middleName || '',
    lastName: data.personalInfo?.lastName || '',
    pan: data.personalInfo?.pan || '',
    contactNumber: data.personalInfo?.contactNumber || '',
    aadhaar: data.personalInfo?.aadhaar || '',
    permanentAddress: {
      address: data.personalInfo?.address || '',
      city: data.personalInfo?.permanentAddress?.city || '',
      state: data.personalInfo?.permanentAddress?.state || '',
      pincode: data.personalInfo?.permanentAddress?.pincode || '',
    },
    communicationAddress: {
      sameAsAbove: data.personalInfo?.communicationAddress?.sameAsAbove ?? false,
      address: data.personalInfo?.address || '',
      city: data.personalInfo?.communicationAddress?.city || '',
      state: data.personalInfo?.communicationAddress?.state || '',
      pincode: data.personalInfo?.communicationAddress?.pincode || '',
    },
    coApplicantInfo: {
      fullName: data.personalInfo?.fullName || '',
      relationship: data.personalInfo?.relationship || '',
      coApplicantAadhaar: data.personalInfo?.coApplicantAadhaar || '',
      dateOfBirth: data.personalInfo?.dateOfBirth || '',
      employmentType: data.personalInfo?.employmentType || '',
    },
  },
  employmentInfo: {
    companyName: data.employmentInfo?.companyName || '',
    companyAddress: data.employmentInfo?.companyAddress || '',
    designation: data.employmentInfo?.designation || '',
    officeEmail: data.employmentInfo?.officeEmail || '',
    educationQualification: data.employmentInfo?.educationQualification || '',
    currentCompanyExperience: data.employmentInfo?.currentCompanyExperience || '',
    totalExperience: data.employmentInfo?.totalExperience || '',
    salaryWithdrawal: data.employmentInfo?.salaryWithdrawal || '',
    takeHomeSalary: data.employmentInfo?.takeHomeSalary || 0,
    currentObligation: data.employmentInfo?.currentObligation || 0,
    netSalary: data.employmentInfo?.netSalary || 0,
    isPfDeducted: data.employmentInfo?.isPfDeducted ?? false,
  },
  loanInfo: {
    loanAmount: data.loanInfo?.loanAmount || 0,
    loanTenure: data.loanInfo?.loanTenure || 0,
    loanPurpose: data.loanInfo?.loanPurpose || '',
  },
  propertyInfo: {
    propertyType: data.propertyInfo?.propertyType || '',
    ownership: data.propertyInfo?.ownership || '',
    propertySize: data.propertyInfo?.propertySize || 0,
    propertyValue: data.propertyInfo?.propertyValue || 0,
    propertyAddress: data.propertyInfo?.propertyAddress || '',
    sellerInfo: {
      sellerName: data.sellerInfo?.sellerName || '',
      sellerContact: data.sellerInfo?.sellerContact || '',
      sellerEmail: data.sellerInfo?.sellerEmail || '',
    },
  },
});

export const getLoanDetails = async () => {
  try {
    const response = await axiosServiceClient.get(LOAN_ENDPOINTS.loanApi);
    if (!response.data) throw new Error('Invalid API response');
    return {
      httpStatusCode: response.status,
      responseCode: response.responseCode,
      data: formLoanData(response.data),
    };
  } catch (error) {
    return {
      httpStatusCode: error.response?.status || 500,
      responseCode: null,
      data: null,
    };
  }
};

export const postLoanDetails = async (loanData) => {
  try {
    const response = await axiosServiceClient.post(LOAN_ENDPOINTS.loanApi, loanData);
    if (!response.data) throw new Error('Invalid API response');
    return {
      httpStatusCode: response.httpStatusCode,
      responseCode: response.responseCode,
      data: formLoanData(response.data),
    };
  } catch (error) {
    return {
      httpStatusCode: error.response?.status || 500,
      responseCode: null,
      data: formLoanData(loanData),
    };
  }
};

export const updateLoanDetails = async (loanData) => {
  try {
    const response = await axiosServiceClient.put(LOAN_ENDPOINTS.loanApi, loanData);
    if (!response.data) throw new Error('Invalid API response');
    return {
      httpStatusCode: response.status,
      responseCode: response.data.responseCode || 'UNKNOWN',
      data: formLoanData(response.data),
    };
  } catch (error) {
    return {
      httpStatusCode: error.response?.status || 500,
      responseCode: null,
      data: formLoanData(loanData),
    };
  }
};

import { convertToDateTime } from 'src/utils/timeUtil';

import { EntityTypesEnum } from 'src/global/ValueTypes/EntityTypes';
import axiosServiceClient, { UrlHandler } from 'src/middleware/axios/AxiosService';
import { EntityProfile } from 'src/models/entity-account-models/EntityProfileRequest';

export const getEntityProfile = async (entityType) => {
  const { url } = EntityProfile.EntityProfileGetRequest;
  const apiResponse = await axiosServiceClient.get(url);

  const response = {
    httpStatusCode: apiResponse.httpStatusCode,
    responseCode: apiResponse.responseCode,
    data: null,
  };

  if (entityType === EntityTypesEnum.APPLICANT)
    response.data = getApplicantProfileData(apiResponse.data);

  return response;
};

export const updateEntityProfile = async (profileData) => {
  const { url, bodyParams } = EntityProfile.EntityProfilePutRequest;

  // TODO:
  bodyParams.mobileno = profileData.firstName;
  bodyParams.otp = profileData.lastName;

  const finalUrl = UrlHandler.appendToUrl(url, profileData.id);
  return axiosServiceClient.put(finalUrl, bodyParams);
};

const getApplicantProfileData = (data) => ({
  entityCode: data.entityCode,
  emailId: data.emailId,
  mobileNo: data.mobileNo,
  profileImage: data.profileImage || null,
  referredByEntityCode: data.referredByEntityCode || null,
  dateOfJoining: convertToDateTime(data.dateOfJoining),
  accountStatus: data.accountStatus || 0,

  firstName: data.profileDetail?.firstName || '',
  middleName: data.profileDetail?.middleName || '',
  lastName: data.profileDetail?.lastName || '',
  gender: data.profileDetail?.gender || '',
  dateOfBirth: convertToDateTime(data.profileDetail?.dateOfBirth),
  pan: data.profileDetail?.pan || '',

  permanentAddress: {
    addressLine: data.permanentAddress?.addressLine,
    city: data.permanentAddress?.city,
    state: data.permanentAddress?.state,
    pinCode: data.permanentAddress?.pinCode,
    isPermanent: data.permanentAddress?.isPermanent,
    preferForCommunication: data.permanentAddress?.preferForCommunication,
  },

  communicationAddress: {
    addressLine: data.permanentAddress?.addressLine,
    city: data.permanentAddress?.city,
    state: data.permanentAddress?.state,
    pinCode: data.permanentAddress?.pinCode,
    isPermanent: data.permanentAddress?.isPermanent,
    preferForCommunication: data.permanentAddress?.preferForCommunication,
  },
});

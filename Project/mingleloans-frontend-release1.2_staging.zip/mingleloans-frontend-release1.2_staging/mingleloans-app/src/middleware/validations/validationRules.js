export const validationRules = {
    email: {
        required: true,
        pattern: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/,
    },
    password: {
        required: true,
        minLength: 8,
        custom: (values) => {
            if (!/[A-Z]/.test(values.password)) return "Password must include an uppercase letter";
            if (!/[a-z]/.test(values.password)) return "Password must include a lowercase letter";
            if (!/[0-9]/.test(values.password)) return "Password must include a number";
            return null;
        },
    },
    phoneNumber: {
        required: true,
        pattern: /^[0-9]{10}$/,
    },
    amount: {
        required: true,
        custom: (values) => {
            if (Number(values.amount) || values.amount <= 0) return "Amount must be a positive number";
            return null;
        },
    },
};
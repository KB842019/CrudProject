import { useState, useEffect } from 'react';

import { validationRules } from './validationRules';

const useValidation = (initialValues) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    const validate = (data) => {
      const validationErrors = {};

      Object.keys(validationRules).forEach((field) => {
        const rules = validationRules[field];
        if (rules.required && !data[field]) {
          validationErrors[field] = `${field} is required`;
        }
        if (rules.pattern && data[field] && !rules.pattern.test(data[field])) {
          validationErrors[field] = `${field} is invalid`;
        }
        if (rules.minLength && data[field] && data[field].length < rules.minLength) {
          validationErrors[field] = `${field} must be at least ${rules.minLength} characters`;
        }
        if (rules.custom && typeof rules.custom === 'function') {
          const customError = rules.custom(data);
          if (customError) validationErrors[field] = customError;
        }
      });

      return validationErrors;
    };

    const validationErrors = validate(values);
    setErrors(validationErrors);
    setIsValid(Object.keys(validationErrors).length === 0);
  }, [values]);

  const handleChange = (field, value) => {
    setValues((prev) => ({ ...prev, [field]: value }));
  };

  return { values, errors, isValid, handleChange };
};

export default useValidation
import axiosServiceClient from 'src/middleware/axios/AxiosService';
import { RAISE_TICKET_ENDPOINTS } from 'src/global/constants/API_ENDPOINTS';

const formTicketData = (data = {}) => ({
  fullName: data.fullName || '',
  email: data.email || '',
  category: data.category || '',
  subject: data.subject || '',
  description: data.description || '',
  attachment: data.attachment || null,
});

export const postTicket = async (ticketData) => {
  try {
    const response = await axiosServiceClient.post(
      RAISE_TICKET_ENDPOINTS.RaiseTicketApi,
      ticketData
    );
    if (!response.data) throw new Error('Invalid API response');

    return {
      httpStatusCode: response.status,
      responseCode: response.data.responseCode,
      data: formTicketData(response.data),
    };
  } catch (error) {
    return {
      httpStatusCode: error.response?.status || 500,
      responseCode: null,
      data: formTicketData(ticketData),
    };
  }
};

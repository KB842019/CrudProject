// Helper function to log errors
export const logErrorMessage = async (error) => {
  const logMessage = `[${new Date().toISOString()}] - Error: ${error.message}\n`;

  try {
    // Fetch to log endpoint or backend service
    await fetch('/log-error', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ logMessage }),
    });
  } catch (errorLog) {
    console.error('Error logging to file:', errorLog);
  }
};

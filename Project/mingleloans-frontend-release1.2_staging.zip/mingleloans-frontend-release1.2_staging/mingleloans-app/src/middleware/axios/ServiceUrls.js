import { AXIOS_VAR, CURRENT_ENVIRONMENT } from 'src/global/GlobalConfig';

export const getBackendBaseUrl = () => {
  const baseUrls = {
    local: AXIOS_VAR.localBaseUrl,
    dev: AXIOS_VAR.devBaseUrl,
    demo: AXIOS_VAR.demoBaseUrl,
    prod: AXIOS_VAR.baseUrl,
  };

  return baseUrls[CURRENT_ENVIRONMENT] || '';
};

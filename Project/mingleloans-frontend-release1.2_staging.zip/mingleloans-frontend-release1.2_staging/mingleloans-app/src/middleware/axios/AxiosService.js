// Import package
import axios from 'axios';

import { getResponse, getErrorResponse } from 'src/utils/response-formatter';

// import { logErrorInFile } from 'src/middleware/logger/file-log';
import { AXIOS_VAR } from 'src/global/GlobalConfig';

import { getBackendBaseUrl } from './ServiceUrls';
import { getHeaders, HeaderTypes } from './AxiosHeader';

/*
Use axiosClient (Singleton):

- For simple applications with a single API endpoint.
- When uniform configuration suffices across the app.
- To reduce resource consumption by reusing the same instance.

Use getAxiosClient (Factory Function):

- For more complex applications with multiple APIs or varied endpoint requirements.
- When runtime logic needs distinct configurations or interceptors.
- For modular services or testable code where client behavior needs customization.
*/

// Instance of axios
const axiosClient = axios.create({
  baseURL: getBackendBaseUrl(), // CURRENT_ENVIRONMENT === 'DEV' ? AXIOS_VAR.localBaseUrl : AXIOS_VAR.baseUrl,
  timeout: AXIOS_VAR.timeOut,
});

export const getAxiosClient = () => {
  const instance = axios.create({
    baseURL: getBackendBaseUrl(), // CURRENT_ENVIRONMENT === 'DEV' ? AXIOS_VAR.localBaseUrl : AXIOS_VAR.baseUrl,
    timeout: AXIOS_VAR.timeOut,
  });

  instance.interceptors.response.use(
    (res) => res,
    (error) => Promise.reject((error.response && error.response.data) || 'Something went wrong')
  );
};

export const UrlHandler = {
  // Create QueryString
  createQueryString: (url, params) => {
    if (!params) return url;

    const queryString = new URLSearchParams(params).toString();
    const separator = url.includes('?') ? '&' : '?';

    return `${url}${separator}${queryString}`;
  },
  appendToUrl: (url, routeParam) => {
    // Ensure the URL ends with a single forward slash before appending
    if (!url.endsWith('/')) {
      url += '/';
    }
    return url + routeParam;
  },
};

// Get Headers as per header type
const getHeaderType = (method) => {
  if (method === 'upload') return HeaderTypes.FILE_UPLOAD;
  if (['get', 'put', 'post', 'patch', 'delete'].includes(method)) return HeaderTypes.SECURE;
  return HeaderTypes.DEFAULT;
};

// Generic API request handler with error handling
const requestHandler = async (method, url, data = null) => {
  try {
    if (method === 'get' && url.includes('loan')) {
      const formattedData = localStorage.getItem('loanDetails');
      return {
        data: formattedData,
        httpStatusCode: 200,
        responseCode: 0,
      };
    }

    if (method === 'post' && url.includes('loan')) {
      localStorage.setItem('loanDetails', JSON.stringify(data));
      return {
        data,
        httpStatusCode: 200,
        responseCode: 0,
      };
    }
    
    const headerType = getHeaderType(method);
    const headers = getHeaders(headerType);

    const response = await axiosClient({
      method,
      url,
      data,
      headers,
    });
    return getResponse(response);
  } catch (error) {
    return getErrorResponse(error);
  }
};

const axiosServiceClient = {
  get: (url) => requestHandler('get', url),
  put: (url, data) => requestHandler('put', url, data),
  post: (url, data) => requestHandler('post', url, data),
  patch: (url, data) => requestHandler('patch', url, data),
  upload: (url, data) => requestHandler('upload', url, data),

  delete: (url) => requestHandler('delete', url),
};

export default axiosServiceClient;

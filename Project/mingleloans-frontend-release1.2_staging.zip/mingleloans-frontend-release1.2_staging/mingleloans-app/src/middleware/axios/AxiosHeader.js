import useAuthStore from 'src/store/auth-store/useAuthStore';

// Define an enum or object to handle header types
export const HeaderTypes = {
  DEFAULT: 'default',
  SECURE: 'secure',
  FILE_UPLOAD: 'file_upload',
};

// Create a single function to get different types of headers
export const getHeaders = (type = HeaderTypes.DEFAULT) => {
  const { token } = useAuthStore.getState();

  // Base headers for all types
  const baseHeaders = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
  };

  switch (type) {
    case HeaderTypes.SECURE:
      return {
        ...baseHeaders,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH',
      };
    case HeaderTypes.FILE_UPLOAD:
      return {
        ...baseHeaders,
        'Content-Type': 'multipart/form-data', // Override content-type
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH',
      };
    case HeaderTypes.DEFAULT:
    default:
      return baseHeaders;
  }
};

// Example usage:
// getHeaders(HeaderTypes.SECURE);
// getHeaders(HeaderTypes.FILE_UPLOAD);
// getHeaders();  // Default headers

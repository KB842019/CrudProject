import axios from 'axios';

import { AXIOS_VAR } from 'src/global/GlobalConfig';

// ----------------------------------------------------------------------

const axiosInstance = axios.create({ baseURL: AXIOS_VAR.baseUrl });

axiosInstance.interceptors.response.use(
  (res) => res,
  (error) => Promise.reject((error.response && error.response.data) || 'Something went wrong')
);

export default axiosInstance;

// ----------------------------------------------------------------------

export const fetc4her = async (args) => {
  const [url, config] = Array.isArray(args) ? args : [args];

  const res = await axiosInstance.get(url, { ...config });

  return res.data;
};

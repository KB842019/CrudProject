import {
  // sendEmailVerification,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
} from 'firebase/auth';

import { getFirebaseErrorResponse } from 'src/utils/response-formatter';

import { RESPONSE_CODES } from 'src/global/ResponseCodes';
import { firebaseClient } from 'src/middleware/auth/firebase';
import axiosServiceClient from 'src/middleware/axios/AxiosService';
import { IDENTITY_PROVIDERS } from 'src/global/constants/APP_CONSTANTS';
import { EntityRegistration } from 'src/models/auth-models/EntityRegistrationRequest';
import { MobileVerification } from 'src/models/auth-models/MobileVerificationRequests';
import { EntityAccountAppSignIn } from 'src/models/auth-models/EntityAccountAppSignInRequest';
import { EntityAccountVerification } from 'src/models/auth-models/EntityAccountVerificationRequest';

export const verifyEntityAccount = async (entitytype, email, mobile) => {
  const { url, bodyParams } = EntityAccountVerification.EntityAccountVerificationRequest;
  bodyParams.email = email;
  bodyParams.mobileno = mobile;

  const finalUrl = url.replace('{{entitytype}}', entitytype);
  return axiosServiceClient.post(finalUrl, bodyParams);
};

export const verifyMobile = async (entitytype, mobile) => {
  const { url, bodyParams } = MobileVerification.MobileVerificationRequest;
  bodyParams.mobileno = mobile;

  const finalUrl = url.replace('{{entitytype}}', entitytype);
  return axiosServiceClient.post(finalUrl, bodyParams);
};

export const verifyOTP = async (entitytype, mobile, otp) => {
  const { url, bodyParams } = MobileVerification.OtpVerificationRequest;
  bodyParams.mobileno = mobile;
  bodyParams.otp = otp;

  const finalUrl = url.replace('{{entitytype}}', entitytype);
  return axiosServiceClient.post(finalUrl, bodyParams);
};

export const createNewFirebaseUser = async (email, password) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(firebaseClient, email, password);
    const { user } = userCredential;

    return {
      httpStatusCode: 200,
      responseCode: RESPONSE_CODES.general.Success.code,
      data: { uid: user.uid },
    };
  } catch (error) {
    alert('error creating user in firebase');
    alert(error);
    return getFirebaseErrorResponse(error);
  }
};

export const createNewEntityAccount = async (
  entitytype,
  identityUid,
  firstName,
  lastName,
  email,
  mobile
) => {
  const { url, bodyParams } = EntityRegistration.ApplicantRegistrationRequest;

  // SET BODY PARAMS
  bodyParams.identityUid = identityUid;
  bodyParams.identityProvider = IDENTITY_PROVIDERS.Firebase;
  bodyParams.entitytype = entitytype;
  bodyParams.firstName = firstName;
  bodyParams.lastName = lastName;
  bodyParams.email = email;
  bodyParams.mobileno = mobile;

  const finalUrl = url.replace('{{entitytype}}', entitytype);
  return axiosServiceClient.post(finalUrl, bodyParams);
};

export const signInByFirebase = async (email, password) => {
  const response = await signInWithEmailAndPassword(firebaseClient, email, password);
  return {
    httpStatusCode: 200,
    responseCode: RESPONSE_CODES.general.Success.code,
    data: response.user,
  };
};

export const signInByApplication = async () => {
  const { url } = EntityAccountAppSignIn.EntityAccountAppSignInRequest;
  return axiosServiceClient.get(url);
};

export const signOutInFirebase = async () => {
  await signOut(firebaseClient);

  return {
    httpStatusCode: 200,
    responseCode: RESPONSE_CODES.general.Success.code,
  };
};

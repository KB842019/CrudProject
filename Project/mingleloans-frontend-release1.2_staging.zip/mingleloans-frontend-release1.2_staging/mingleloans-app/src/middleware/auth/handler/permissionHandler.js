// handler/permissionHandler.js
import usePermissionStore from 'src/store/auth-store/usePermissionStore';

const PermissionHandler = {
  addPermission: (permission) => {
    const { setPermissionState } = usePermissionStore.getState(); // Access the store directly
    setPermissionState(permission);
  },
  // Middleware function to check permissions before executing an action
  withPermissionCheck: (entity, operation, action) => {
    const { hasPermission } = usePermissionStore.getState(); // Access the store directly

    return (...args) => {
      if (hasPermission(entity, operation)) {
        action(...args); // Execute the action if the permission is granted
      } else {
        console.warn(`Permission denied for ${operation} on ${entity}.`);
        alert(`You do not have permission to ${operation} this ${entity}.`);
      }
    };
  },
};

export default PermissionHandler;

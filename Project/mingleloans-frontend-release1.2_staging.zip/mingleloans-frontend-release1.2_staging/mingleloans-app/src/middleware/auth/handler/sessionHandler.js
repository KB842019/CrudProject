import { getNewExpiryTime, convertMinutesToMilliSeconds } from 'src/utils/timeUtil';

import axios from 'src/middleware/axios/axios';
import useAuthStore from 'src/store/auth-store/useAuthStore';
import { SESSION_TIMEOUT_MINS } from 'src/global/GlobalConfig';
import { PUBLIC_ROUTES } from 'src/global/constants/APP_ROUTES';

// [private functions]----------------------------------------------------------------------

const setBrowserSessionTimeout = (timeLeft) => {
  let timer;
  clearTimeout(timer);

  timer = setTimeout(() => {
    alert('Session Timeout! Please login again.');
    window.location.href = PUBLIC_ROUTES.LOGIN;
  }, timeLeft);
};

// ----------------------------------------------------------------------

const SessionHandler = {
  isValidSession: () => {
    const { getTokenState, getExpiryTimeState } = useAuthStore.getState();

    const token = getTokenState();
    const expiry = getExpiryTimeState();

    // Check if token and expiry are not null or undefined and the expiry time is in the future
    if (token && expiry && new Date().getTime() < expiry) {
      // Token is valid and not expired
      return true;
    }

    // Token is invalid or expired
    return false;
  },
  getAccessToken: () => {
    const { getTokenState } = useAuthStore.getState();
    return getTokenState();
  },
  getUser: () => {
    const { getUserState } = useAuthStore.getState();
    return getUserState();
  },
  removeSession: () => {
    const { resetUserState } = useAuthStore.getState();
    return resetUserState();
  },
  setSession: (accessToken) => {
    // Token for header of axios instance WILL BE SET IN AxiosHeader.js

    const { setTokenState, clearTokenState } = useAuthStore.getState();

    if (accessToken) {
      const newExpirationTime = getNewExpiryTime(SESSION_TIMEOUT_MINS || 1);
      setTokenState(accessToken, newExpirationTime);

      // This function below will handle when token is expired
      const timeout = convertMinutesToMilliSeconds(SESSION_TIMEOUT_MINS || 1);

      setBrowserSessionTimeout(timeout);
    } else {
      clearTokenState();
      delete axios.defaults.headers.common.Authorization;
    }
  },
  setUser: (user) => {
    const { setUserState } = useAuthStore.getState();
    setUserState(user);
  },
};

export default SessionHandler;

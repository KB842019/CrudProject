// Import the functions you need from the SDKs you need
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getApp, getApps, initializeApp } from 'firebase/app';

import { FIREBASE_API } from 'src/global/GlobalConfig';

const firebaseConfig = {
  apiKey: FIREBASE_API.apiKey,
  authDomain: FIREBASE_API.authDomain,
  databaseURL: FIREBASE_API.databaseURL,
  projectId: FIREBASE_API.projectId,
  storageBucket: FIREBASE_API.storageBucket,
  messagingSenderId: FIREBASE_API.messagingSenderId,
  appId: FIREBASE_API.appId,
  // measurementId: FIREBASE_API.measurementId,
};

// Initialize Firebase
// const firebaseApp = initializeApp(firebaseConfig);

const firebaseApp = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const firebaseStore = getFirestore(firebaseApp);
const firebaseClient = getAuth(firebaseApp);

export { firebaseStore, firebaseClient };

import PropTypes from 'prop-types';
import { SplashScreen } from '@components/mui-components/loading-screen';

import { AuthContext } from './auth-context';

// ----------------------------------------------------------------------

export const AuthConsumer = ({ children }) => (
  <AuthContext.Consumer>
    {(auth) => (auth.loading ? <SplashScreen /> : children)}
  </AuthContext.Consumer>
);

AuthConsumer.propTypes = {
  children: PropTypes.node,
};

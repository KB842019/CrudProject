import PropTypes from 'prop-types';
import { useMemo, useState, useEffect, useCallback } from 'react';

import { RESPONSE_CODES } from 'src/global/ResponseCodes';
import SessionHandler from 'src/middleware/auth/handler/sessionHandler';
import PermissionHandler from 'src/middleware/auth/handler/permissionHandler';
// Auth APIs
import {
  verifyOTP,
  verifyMobile,
  signInByFirebase,
  signOutInFirebase,
  signInByApplication,
  verifyEntityAccount,
  createNewFirebaseUser,
  createNewEntityAccount,
} from 'src/middleware/auth/handler/authHandlers';

import { AuthContext } from './auth-context';

export function AuthProvider({ children }) {
  const [status, setStatus] = useState('unauthenticated');

  // Set user and permission information
  const setEntityAuthDetails = useCallback(async ({ user, permission }) => {
    SessionHandler.setUser(user);
    PermissionHandler.addPermission(permission);
  }, []);

  // default initialize
  const initialize = useCallback(async () => {
    try {
      setStatus('unauthenticated');

      if (SessionHandler && SessionHandler.isValidSession()) {
        SessionHandler.setSession(SessionHandler.getAccessToken());
      }
    } catch (error) {
      console.error(error);
      alert(`error: ${error}`);
    }
  }, [setStatus]);

  useEffect(() => {
    initialize();
  }, [initialize]);

  // FIREBASE LOGIN
  const sendFirebaseLoginRequest = useCallback(
    async (email, password) => {
      setStatus('loading');

      const response = await signInByFirebase(email, password);
      SessionHandler.setSession(response.data.accessToken);
      return RESPONSE_CODES.general.Success.code;
    },
    [setStatus]
  );

  const sendAppLoginRequest = useCallback(async () => {
    const response = await signInByApplication();

    if (parseInt(response.responseCode, 10) === RESPONSE_CODES.general.Success.code) {
      setStatus('authenticated');

      // Set user information and permission
      // TODO: UPDATE PERMISSION
      setEntityAuthDetails({ user: response.data, permission: response.data });
    } else {
      setStatus('unauthenticated');
    }

    return response;
  }, [setStatus, setEntityAuthDetails]);

  // Memoized function to verify the mobile number
  const sendEntityAccountVerificationRequest = useCallback(
    async (entitytype, email, mobile) => verifyEntityAccount(entitytype, email, mobile),
    []
  );

  const sendMobileVerificationRequest = useCallback(
    async (entitytype, mobile) => verifyMobile(entitytype, mobile),
    []
  );

  // VERIFICATION OF OTP
  const sendOtpVerificationRequest = useCallback(
    async (entitytype, mobile, otp) => verifyOTP(entitytype, mobile, otp),
    []
  );

  // REGISTER
  const sendFirebaseRegistrationRequest = useCallback(
    async (email, mobile) => createNewFirebaseUser(email, mobile),
    []
  );

  const sendApplicantRegistrationRequest = useCallback(
    async (entitytype, identityUid, firstName, lastName, email, mobile) => {
      const response = await createNewEntityAccount(
        entitytype,
        identityUid,
        firstName,
        lastName,
        email,
        mobile
      );
      return response;
    },
    []
  );

  // LOGOUT
  const sendLogoutRequest = useCallback(async () => {
    setStatus('unauthenticated');
    SessionHandler.removeSession();
    return signOutInFirebase();
  }, [setStatus]);

  // Clear session in any accidental scenario
  const clearSession = useCallback(async () => {
    SessionHandler.removeSession();
  }, []);

  // ----------------------------------------------------------------------

  const memoizedValue = useMemo(
    () => ({
      user: SessionHandler.getUser(),
      method: 'jwt',
      loading: status === 'loading',
      authenticated: status === 'authenticated',
      unauthenticated: status === 'unauthenticated',
      //
      sendFirebaseLoginRequest,
      sendAppLoginRequest,
      sendFirebaseRegistrationRequest,
      sendApplicantRegistrationRequest,
      sendLogoutRequest,
      clearSession,
      sendEntityAccountVerificationRequest,
      sendMobileVerificationRequest,
      sendOtpVerificationRequest,
    }),
    [
      sendFirebaseLoginRequest,
      sendAppLoginRequest,
      sendFirebaseRegistrationRequest,
      sendApplicantRegistrationRequest,
      sendLogoutRequest,
      clearSession,
      sendEntityAccountVerificationRequest,
      sendMobileVerificationRequest,
      sendOtpVerificationRequest,
      status,
    ]
  );

  return <AuthContext.Provider value={memoizedValue}>{children}</AuthContext.Provider>;
}

AuthProvider.propTypes = {
  children: PropTypes.node,
};

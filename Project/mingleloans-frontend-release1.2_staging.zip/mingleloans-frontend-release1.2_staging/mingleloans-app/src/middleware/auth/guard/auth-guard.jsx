import PropTypes from 'prop-types';
import { useEffect, useCallback } from 'react';
import { SplashScreen } from '@components/mui-components/loading-screen';

import { useRouter } from 'src/routes/hooks';
import { DefaultRoutes } from 'src/routes/DefaultRoutes';

import SessionHandler from 'src/middleware/auth/handler/sessionHandler';

import { useAuthContext } from '../hooks';

// ----------------------------------------------------------------------

export default function AuthGuard({ children }) {
  const { loading } = useAuthContext();
  return <>{loading ? <SplashScreen /> : <Container> {children}</Container>}</>;
}

AuthGuard.propTypes = {
  children: PropTypes.node,
};

// ----------------------------------------------------------------------

function Container({ children }) {
  const router = useRouter();

  const ValidateUserLogin = useCallback(() => {
    const isValidSession = SessionHandler && SessionHandler.isValidSession();

    if (!isValidSession) {
      const searchParams = new URLSearchParams({
        returnTo: window.location.pathname,
      }).toString();

      const href = `${DefaultRoutes.auth_url.login}?${searchParams}`;
      router.replace(href);
    }
  }, [router]);

  useEffect(() => {
    ValidateUserLogin();
  }, [ValidateUserLogin]);

  return <>{children}</>;
}

Container.propTypes = {
  children: PropTypes.node,
};

# Mingle Loans Frontend
Mingle Loan Application
---

Welcome to our MingleLoans Frontend

## Getting Started

1. **Clone the repository:**

   ```bash
   git clone https://github.com/Mingle-Loans/mingleloans-frontend.git

   cd mingleloans-app
   ```

2. **Install dependencies:**

   ```bash
   npm install or npm i --legacy-peer-deps
   ```
   Purpose: Adding the "--legacy-peer-deps" flag allows npm to use an older, compatible version of the peer dependency, ensuring a successful installation.

3. **Run the development server:**

   ```bash
   npm run dev
   ```

4. **Open your browser:**
   Navigate to `http://localhost:3001` to see your app running.

## Deployment

To deploy your React app, follow these steps:

1. **Build your app:**

   ```bash
   npm run build
   ```

2. **Choose your deployment method:**

   - **Static Hosting:**
     You can deploy the contents of the `dist` directory to static hosting services like Netlify, Vercel, GitHub Pages, or AWS S3.

   - **Server Hosting:**
     If you're deploying to a server, you can deploy the build artifacts along with a Node.js server to serve your app. Configure your server to serve the static files in the `dist` directory.

3. **Deploy:**
   - For static hosting, simply upload the contents of the `dist` directory to your hosting provider.
   - For server hosting, deploy your server code along with the `dist` directory to your server.

## Additional Resources

- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://reactjs.org/docs/getting-started.html)

## Author

- Mingle Loans Team, Copyright @ 2024